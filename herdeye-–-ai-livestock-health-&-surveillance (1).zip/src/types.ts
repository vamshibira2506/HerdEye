export type UserRole = 'farmer' | 'field_worker' | 'veterinarian' | 'government';

export type AnimalSpecies = 'Cattle' | 'Buffalo';

export type HealthStatus = 'Healthy' | 'Under Observation' | 'High Risk / Critical' | 'Deceased';

export type RiskPriority = 'Low' | 'Medium' | 'High' | 'Critical';

export interface LocationInfo {
  farmName: string;
  village: string;
  block: string;
  district: string;
  state: string;
  lat: number;
  lng: number;
}

export interface VaccinationRecord {
  id: string;
  vaccineName: string;
  targetDisease: string;
  batchNumber: string;
  administeredDate: string;
  nextDueDate: string;
  administeredBy: string;
  status: 'Done' | 'Due Soon' | 'Overdue';
}

export interface TreatmentRecord {
  id: string;
  date: string;
  diagnosis: string;
  veterinarianName: string;
  clinic: string;
  medications: string;
  notes: string;
  followUpDate?: string;
  status: 'Active' | 'Completed';
}

export interface LabReferralRecord {
  id: string;
  sampleId: string;
  sampleType: 'Blood' | 'Milk' | 'Nasal Swab' | 'Skin Scraping' | 'Fecal';
  testRequested: string;
  requestedDate: string;
  requestedBy: string;
  labName: string;
  status: 'Pending' | 'In Analysis' | 'Completed';
  resultDate?: string;
  resultSummary?: string;
  urgency: 'Routine' | 'Urgent' | 'Emergency';
}

export interface Animal {
  id: string; // Ear Tag ID e.g., IN-GJ-2024-9182
  name: string;
  species: AnimalSpecies;
  breed: string;
  ageYears: number;
  ageMonths: number;
  sex: 'Female' | 'Male';
  weightKg: number;
  lactationStatus: 'Lactating' | 'Dry' | 'Heifer' | 'Bull' | 'Calf';
  shedNumber: string;
  location: LocationInfo;
  ownerName: string;
  ownerContact: string;
  photoUrl: string;
  healthStatus: HealthStatus;
  riskScore: number; // 0 to 100
  riskPriority: RiskPriority;
  currentSymptoms: string[];
  activityScore: number; // 0 to 100
  ruminationMinutesPerDay: number; // Normal ~400-500 min
  feedIntakeKg: number; // Normal ~18-24 kg
  bodyTemperatureC: number; // Normal 38.2 - 39.2 °C
  postureStatus: string;
  visibleAbnormalities: string[];
  vaccinationRecords: VaccinationRecord[];
  treatmentHistory: TreatmentRecord[];
  labReferrals: LabReferralRecord[];
  mortalityRecord?: {
    date: string;
    suspectedCause: string;
    reportedBy: string;
    postMortemRequested: boolean;
    carcassDisposalStatus: 'Buried with Lime' | 'Incinerated' | 'Pending Verification';
    disposalVerifiedBy?: string;
  };
  lastChecked: string;
  cameraFeedId?: string;
  confidenceAlert?: string;
}

export interface HealthAlert {
  id: string;
  animalId: string;
  animalName: string;
  species: AnimalSpecies;
  breed: string;
  title: string;
  suspectedDisease: string;
  priority: RiskPriority;
  confidenceScore: number;
  detectedAt: string;
  village: string;
  district: string;
  state: string;
  symptoms: string[];
  aiObservations: string;
  recommendedAction: string;
  status: 'New' | 'Under Investigation' | 'Treated' | 'Dismissed';
  evidenceImageUrl?: string;
  evidenceVideoUrl?: string;
}

export interface SymptomReport {
  id: string;
  animalId: string;
  reportedBy: string;
  reporterRole: UserRole;
  reporterPhone: string;
  timestamp: string;
  symptoms: string[];
  severity: 'Mild' | 'Moderate' | 'Severe' | 'Critical';
  onsetDate: string;
  notes: string;
  photoUrl?: string;
  videoUrl?: string;
  videoDurationSeconds?: number;
  videoTitle?: string;
  location: LocationInfo;
  status: 'Submitted' | 'Reviewed' | 'Action Taken';
  veterinarianNotes?: string;
}

export interface OutbreakCluster {
  id: string;
  diseaseName: string;
  riskLevel: RiskPriority;
  state: string;
  district: string;
  block: string;
  farmsAffected: number;
  activeCases: number;
  mortalities: number;
  vaccinationCoveragePercent: number;
  firstReportedDate: string;
  lastUpdated: string;
  coordinates: { lat: number; lng: number };
  alertStatus: 'Active Outbreak' | 'Under Containment' | 'Monitored' | 'Resolved';
}

export interface OfflineSyncItem {
  id: string;
  type: 'symptom_report' | 'animal_register' | 'mortality_report' | 'vet_treatment' | 'lab_referral';
  title: string;
  timestamp: string;
  synced: boolean;
  payload: any;
}
