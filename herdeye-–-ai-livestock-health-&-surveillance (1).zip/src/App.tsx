import React, { useState } from 'react';
import { LivestockProvider, useLivestock } from './context/LivestockContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { FarmerDashboard } from './components/FarmerDashboard';
import { FarmerAnimalHealthPage } from './components/FarmerAnimalHealthPage';
import { FarmerVaccinationView } from './components/FarmerVaccinationView';
import { FarmerBottomNav, FarmerActiveNav } from './components/FarmerBottomNav';
import { FarmerMoreDrawer } from './components/FarmerMoreDrawer';
import { FarmerSymptomReportModal } from './components/FarmerSymptomReportModal';
import { FarmerCameraCheckModal } from './components/FarmerCameraCheckModal';
import { TalkToDoctorModal } from './components/TalkToDoctorModal';
import { VoiceAssistantModal } from './components/VoiceAssistantModal';
import { FarmerEducationModal } from './components/FarmerEducationModal';
import { FieldWorkerDashboard } from './components/FieldWorkerDashboard';
import { VeterinarianDashboard } from './components/VeterinarianDashboard';
import { GovernmentDashboard } from './components/GovernmentDashboard';
import { AiMonitoringView } from './components/AiMonitoringView';
import { VaccinationModule } from './components/VaccinationModule';
import { LabReferralModule } from './components/LabReferralModule';
import { AlertsModule } from './components/AlertsModule';
import { ReportsModule } from './components/ReportsModule';
import { MortalityModule } from './components/MortalityModule';
import { LandingLoginPage } from './components/LandingLoginPage';
import { AnimalDetailModal } from './components/AnimalDetailModal';
import { AnimalRegisterModal } from './components/AnimalRegisterModal';
import { SymptomReportModal } from './components/SymptomReportModal';
import { MortalityReportModal } from './components/MortalityReportModal';
import { OfflineSyncDrawer } from './components/OfflineSyncDrawer';
import { Animal, UserRole } from './types';
import { WifiOff, AlertTriangle, CheckCircle2, Info, X } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const {
    role,
    setRole,
    activeTab,
    setActiveTab,
    isOnline,
    offlineQueue,
    animals,
    alerts,
    toastMessage,
    setToastMessage,
  } = useLivestock();

  const { t } = useLanguage();

  // Navigation view state: landing vs dashboard
  const [showLanding, setShowLanding] = useState(false);

  // Farmer specific bottom nav state
  const [farmerNav, setFarmerNav] = useState<FarmerActiveNav>('home');
  const [selectedFarmerAnimal, setSelectedFarmerAnimal] = useState<Animal | null>(null);

  // Modals state
  const [registerModalOpen, setRegisterModalOpen] = useState(false);
  const [symptomModalOpen, setSymptomModalOpen] = useState(false);
  const [farmerSymptomModalOpen, setFarmerSymptomModalOpen] = useState(false);
  const [farmerReportInitialSymptom, setFarmerReportInitialSymptom] = useState<string | undefined>(undefined);
  const [mortalityModalOpen, setMortalityModalOpen] = useState(false);
  const [offlineDrawerOpen, setOfflineDrawerOpen] = useState(false);
  const [selectedAnimalForDetail, setSelectedAnimalForDetail] = useState<Animal | null>(null);
  const [preSelectedAnimalId, setPreSelectedAnimalId] = useState<string | undefined>(undefined);
  const [isSidebarOpenMobile, setIsSidebarOpenMobile] = useState(false);

  // Farmer specialized modals
  const [talkToDoctorOpen, setTalkToDoctorOpen] = useState(false);
  const [cameraCheckOpen, setCameraCheckOpen] = useState(false);
  const [voiceAssistantOpen, setVoiceAssistantOpen] = useState(false);
  const [educationModalOpen, setEducationModalOpen] = useState(false);
  const [moreDrawerOpen, setMoreDrawerOpen] = useState(false);
  const [showFarmerVaccination, setShowFarmerVaccination] = useState(false);

  // Handlers for modal triggers
  const handleOpenReportModal = (animalId?: string) => {
    if (role === 'farmer') {
      const matched = animals.find(a => a.id === animalId);
      if (matched) setSelectedFarmerAnimal(matched);
      setFarmerSymptomModalOpen(true);
    } else {
      setPreSelectedAnimalId(animalId);
      setSymptomModalOpen(true);
    }
  };

  const handleSelectAnimalById = (id: string) => {
    const animal = animals.find(a => a.id === id);
    if (animal) {
      if (role === 'farmer') {
        setSelectedFarmerAnimal(animal);
      } else {
        setSelectedAnimalForDetail(animal);
      }
    }
  };

  // Farmer Bottom Nav Switching
  const handleFarmerNavChange = (nav: FarmerActiveNav) => {
    setFarmerNav(nav);
    if (nav === 'more') {
      setMoreDrawerOpen(true);
    } else if (nav === 'problems') {
      setFarmerSymptomModalOpen(true);
    } else if (nav === 'alerts') {
      setActiveTab('alerts');
    } else if (nav === 'animals') {
      setSelectedFarmerAnimal(null);
      setShowFarmerVaccination(false);
    } else if (nav === 'home') {
      setSelectedFarmerAnimal(null);
      setShowFarmerVaccination(false);
      setActiveTab('dashboard');
    }
  };

  if (showLanding) {
    return <LandingLoginPage onLoginSuccess={() => setShowLanding(false)} />;
  }

  const isFarmerMode = role === 'farmer';
  const pendingAlertsCount = alerts.filter(a => a.status === 'New').length;

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans text-slate-800">
      {/* Top Offline Alert Banner if network toggled offline */}
      {!isOnline && (
        <div className="bg-amber-600 text-white px-4 py-2 text-xs font-bold flex items-center justify-between shadow-xs sticky top-0 z-50">
          <div className="flex items-center gap-2 max-w-5xl mx-auto w-full justify-between">
            <div className="flex items-center gap-2">
              <WifiOff className="w-4 h-4 text-amber-200" />
              <span>
                {t('status_offline', '📴 ఇంటర్నెట్ లేదు. మీ సమాచారం సురక్షితంగా ఫోన్‌లోనే భద్రపరచబడింది.')}
              </span>
            </div>
            <button
              onClick={() => setOfflineDrawerOpen(true)}
              className="bg-amber-800/80 hover:bg-amber-900 text-amber-100 px-3 py-1 rounded-md text-[11px] underline underline-offset-2 shrink-0"
            >
              Pending ({offlineQueue.length})
            </button>
          </div>
        </div>
      )}

      {/* Main Header with Language & Voice */}
      <Header
        onOpenOfflineDrawer={() => setOfflineDrawerOpen(true)}
        onOpenVoiceAssistant={() => setVoiceAssistantOpen(true)}
      />

      {/* Main App Body */}
      <div className="flex-1 flex w-full">
        {/* Navigation Sidebar: Render ONLY for non-farmer professional modes per Requirement 23 */}
        {!isFarmerMode && (
          <Sidebar
            isOpenMobile={isSidebarOpenMobile}
            setIsOpenMobile={setIsSidebarOpenMobile}
            onOpenRegisterModal={() => setRegisterModalOpen(true)}
            onOpenReportModal={() => handleOpenReportModal()}
          />
        )}

        {/* Main Content Area */}
        <main
          className={`flex-1 p-3 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full overflow-x-hidden ${
            isFarmerMode ? 'pb-24' : ''
          }`}
        >
          {/* Top Switcher Bar */}
          <div className="mb-4 flex items-center justify-between text-xs text-slate-500">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-600">సక్రియ విభాగం (Active Role):</span>
              <span className="font-mono text-[11px] bg-slate-200 px-2.5 py-0.5 rounded-full text-slate-800 font-extrabold">
                {role === 'farmer'
                  ? 'రైతు పోర్టల్ (FARMER SIMPLE)'
                  : role === 'field_worker'
                  ? 'పశు సఖి (COMMUNITY DESK)'
                  : role === 'veterinarian'
                  ? 'పశువైద్యశాల (VETERINARY CLINIC)'
                  : 'ప్రభుత్వ పర్యవేక్షణ (GOVERNMENT)'}
              </span>
            </div>

            <button
              onClick={() => setShowLanding(true)}
              className="text-emerald-800 hover:text-emerald-900 font-extrabold underline underline-offset-2 transition"
              id="switch-role-landing-link"
            >
              మొదటి స్క్రీన్ / పాత్ర మార్చుకోండి ➔
            </button>
          </div>

          {/* FARMER MODE RENDERING */}
          {isFarmerMode ? (
            <>
              {selectedFarmerAnimal ? (
                /* Simple Animal Health Page per Requirement 6 */
                <FarmerAnimalHealthPage
                  animal={selectedFarmerAnimal}
                  onBack={() => setSelectedFarmerAnimal(null)}
                  onOpenReport={(animal) => {
                    setSelectedFarmerAnimal(animal);
                    setFarmerSymptomModalOpen(true);
                  }}
                  onOpenTalkToDoctor={(animal) => {
                    setSelectedFarmerAnimal(animal);
                    setTalkToDoctorOpen(true);
                  }}
                  onOpenCameraCheck={(animal) => {
                    setSelectedFarmerAnimal(animal);
                    setCameraCheckOpen(true);
                  }}
                />
              ) : showFarmerVaccination ? (
                /* Simple Farmer Vaccination View per Requirement 11 */
                <div className="space-y-4">
                  <button
                    onClick={() => setShowFarmerVaccination(false)}
                    className="text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1"
                  >
                    ← ప్రధాన పేజీకి తిరిగి వెళ్లండి
                  </button>
                  <FarmerVaccinationView
                    onSelectAnimal={(animal) => setSelectedFarmerAnimal(animal)}
                  />
                </div>
              ) : activeTab === 'alerts' ? (
                <div className="space-y-4">
                  <button
                    onClick={() => setActiveTab('dashboard')}
                    className="text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1"
                  >
                    ← ప్రధాన పేజీకి తిరిగి వెళ్లండి
                  </button>
                  <AlertsModule onSelectAnimalById={handleSelectAnimalById} />
                </div>
              ) : activeTab === 'reporting' ? (
                <div className="space-y-4">
                  <button
                    onClick={() => setActiveTab('dashboard')}
                    className="text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1"
                  >
                    ← ప్రధాన పేజీకి తిరిగి వెళ్లండి
                  </button>
                  <ReportsModule
                    onOpenNewReport={() => setFarmerSymptomModalOpen(true)}
                    onSelectAnimalById={handleSelectAnimalById}
                  />
                </div>
              ) : (
                /* Main Simplified Farmer Dashboard */
                <FarmerDashboard
                  onSelectAnimal={(a) => setSelectedFarmerAnimal(a)}
                  onOpenRegister={() => setRegisterModalOpen(true)}
                  onOpenReport={(animal, initialSymptom) => {
                    if (animal) setSelectedFarmerAnimal(animal);
                    setFarmerReportInitialSymptom(initialSymptom);
                    setFarmerSymptomModalOpen(true);
                  }}
                  onOpenMortality={() => setMortalityModalOpen(true)}
                  onOpenTalkToDoctor={(animal) => {
                    if (animal) setSelectedFarmerAnimal(animal);
                    setTalkToDoctorOpen(true);
                  }}
                  onOpenCameraCheck={(animal) => {
                    if (animal) setSelectedFarmerAnimal(animal);
                    setCameraCheckOpen(true);
                  }}
                  onOpenVoiceAssistant={() => setVoiceAssistantOpen(true)}
                  onOpenVaccination={() => setShowFarmerVaccination(true)}
                />
              )}
            </>
          ) : (
            /* PROFESSIONAL MODES RENDERING (Field Worker, Vet, Govt) */
            <>
              {activeTab === 'dashboard' && (
                <>
                  {role === 'field_worker' && (
                    <FieldWorkerDashboard
                      onOpenRegister={() => setRegisterModalOpen(true)}
                      onOpenReport={() => handleOpenReportModal()}
                      onSelectAnimal={(a) => setSelectedAnimalForDetail(a)}
                    />
                  )}
                  {role === 'veterinarian' && (
                    <VeterinarianDashboard
                      onSelectAnimal={(a) => setSelectedAnimalForDetail(a)}
                    />
                  )}
                  {role === 'government' && <GovernmentDashboard />}
                </>
              )}

              {activeTab === 'ai-monitoring' && <AiMonitoringView />}

              {activeTab === 'animals' && (
                <FarmerDashboard
                  onSelectAnimal={(a) => setSelectedAnimalForDetail(a)}
                  onOpenRegister={() => setRegisterModalOpen(true)}
                  onOpenReport={() => handleOpenReportModal()}
                  onOpenMortality={() => setMortalityModalOpen(true)}
                  onOpenTalkToDoctor={(animal) => {
                    if (animal) setSelectedFarmerAnimal(animal);
                    setTalkToDoctorOpen(true);
                  }}
                  onOpenCameraCheck={(animal) => {
                    if (animal) setSelectedFarmerAnimal(animal);
                    setCameraCheckOpen(true);
                  }}
                  onOpenVoiceAssistant={() => setVoiceAssistantOpen(true)}
                  onOpenVaccination={() => setShowFarmerVaccination(true)}
                />
              )}

              {activeTab === 'reporting' && (
                <ReportsModule
                  onOpenNewReport={() => handleOpenReportModal()}
                  onSelectAnimalById={handleSelectAnimalById}
                />
              )}

              {activeTab === 'veterinary-cases' && (
                <VeterinarianDashboard onSelectAnimal={(a) => setSelectedAnimalForDetail(a)} />
              )}

              {activeTab === 'vaccination' && <VaccinationModule />}

              {activeTab === 'lab-referrals' && <LabReferralModule />}

              {activeTab === 'mortality' && (
                <MortalityModule
                  onOpenReportMortality={() => setMortalityModalOpen(true)}
                  onSelectAnimalById={handleSelectAnimalById}
                />
              )}

              {activeTab === 'alerts' && (
                <AlertsModule onSelectAnimalById={handleSelectAnimalById} />
              )}

              {activeTab === 'geospatial' && <GovernmentDashboard />}

              {activeTab === 'reports' && (
                <ReportsModule
                  onOpenNewReport={() => handleOpenReportModal()}
                  onSelectAnimalById={handleSelectAnimalById}
                />
              )}

              {activeTab === 'offline-outbox' && (
                <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-lg font-black text-slate-900">
                        Offline Synchronization Control Center
                      </h2>
                      <p className="text-xs text-slate-500">
                        Review and dispatch records cached during network loss in rural sheds.
                      </p>
                    </div>
                    <button
                      onClick={() => setOfflineDrawerOpen(true)}
                      className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold"
                    >
                      Open Outbox Drawer
                    </button>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                    Pending records currently queued: <strong>{offlineQueue.length}</strong>
                  </div>
                </div>
              )}
            </>
          )}
        </main>
      </div>

      {/* FARMER BOTTOM NAVIGATION (Requirement 23) */}
      {isFarmerMode && (
        <FarmerBottomNav
          currentNav={farmerNav}
          onChangeNav={handleFarmerNavChange}
          alertsCount={pendingAlertsCount}
        />
      )}

      {/* FARMER MODALS */}
      <FarmerSymptomReportModal
        isOpen={farmerSymptomModalOpen}
        onClose={() => {
          setFarmerSymptomModalOpen(false);
          setFarmerReportInitialSymptom(undefined);
        }}
        preselectedAnimal={selectedFarmerAnimal || animals[0]}
        initialSymptomKey={farmerReportInitialSymptom}
      />

      <FarmerCameraCheckModal
        isOpen={cameraCheckOpen}
        onClose={() => setCameraCheckOpen(false)}
        selectedAnimal={selectedFarmerAnimal}
        onOpenTalkToDoctor={() => setTalkToDoctorOpen(true)}
      />

      <TalkToDoctorModal
        isOpen={talkToDoctorOpen}
        onClose={() => setTalkToDoctorOpen(false)}
        selectedAnimal={selectedFarmerAnimal}
      />

      <VoiceAssistantModal
        isOpen={voiceAssistantOpen}
        onClose={() => setVoiceAssistantOpen(false)}
        onAction={(action) => {
          setVoiceAssistantOpen(false);
          if (action.type === 'symptom_report') {
            setFarmerReportInitialSymptom(action.initialSymptom);
            setFarmerSymptomModalOpen(true);
          } else if (action.type === 'call_doctor') {
            setTalkToDoctorOpen(true);
          } else if (action.type === 'vaccination') {
            setShowFarmerVaccination(true);
          } else if (action.type === 'camera_check') {
            setCameraCheckOpen(true);
          } else if (action.type === 'view_animals') {
            setSelectedFarmerAnimal(null);
          }
        }}
      />

      <FarmerEducationModal
        isOpen={educationModalOpen}
        onClose={() => setEducationModalOpen(false)}
        onOpenTalkToDoctor={() => setTalkToDoctorOpen(true)}
      />

      <FarmerMoreDrawer
        isOpen={moreDrawerOpen}
        onClose={() => setMoreDrawerOpen(false)}
        onOpenLanguage={() => {}}
        onOpenVoice={() => setVoiceAssistantOpen(true)}
        onOpenDoctor={() => setTalkToDoctorOpen(true)}
        onOpenLearn={() => setEducationModalOpen(true)}
        onOpenVaccination={() => setShowFarmerVaccination(true)}
        onOpenSwitchRole={() => setShowLanding(true)}
      />

      {/* Global Modals & Drawers for Professional & Shared Workflows */}
      <AnimalRegisterModal
        isOpen={registerModalOpen}
        onClose={() => setRegisterModalOpen(false)}
      />

      <SymptomReportModal
        isOpen={symptomModalOpen}
        onClose={() => {
          setSymptomModalOpen(false);
          setPreSelectedAnimalId(undefined);
        }}
        preSelectedAnimalId={preSelectedAnimalId}
      />

      <MortalityReportModal
        isOpen={mortalityModalOpen}
        onClose={() => setMortalityModalOpen(false)}
      />

      <AnimalDetailModal
        animal={selectedAnimalForDetail}
        onClose={() => setSelectedAnimalForDetail(null)}
        onOpenReportSymptom={(id) => handleOpenReportModal(id)}
      />

      <OfflineSyncDrawer
        isOpen={offlineDrawerOpen}
        onClose={() => setOfflineDrawerOpen(false)}
      />

      {/* Toast Notification Popup */}
      {toastMessage && (
        <div className="fixed bottom-20 sm:bottom-5 right-5 z-50 max-w-sm bg-slate-900 text-white p-4 rounded-2xl shadow-2xl border border-slate-700 flex items-start gap-3 animate-fade-in">
          <div className="mt-0.5">
            {toastMessage.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-400" />}
            {toastMessage.type === 'warning' && <AlertTriangle className="w-5 h-5 text-amber-400" />}
            {toastMessage.type === 'info' && <Info className="w-5 h-5 text-sky-400" />}
          </div>
          <div className="flex-1 text-xs">
            <h5 className="font-black text-white">{toastMessage.title}</h5>
            <p className="text-slate-300 mt-0.5 leading-relaxed">{toastMessage.desc}</p>
          </div>
          <button
            onClick={() => setToastMessage(null)}
            className="text-slate-400 hover:text-white p-0.5"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <LivestockProvider>
      <LanguageProvider>
        <MainAppContent />
      </LanguageProvider>
    </LivestockProvider>
  );
}
