import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { SupportedLanguage, SUPPORTED_LANGUAGES, TRANSLATIONS, LanguageMeta } from '../utils/translations';

interface LanguageContextType {
  language: SupportedLanguage;
  setLanguage: (lang: SupportedLanguage) => void;
  languages: LanguageMeta[];
  currentLangMeta: LanguageMeta;
  t: (key: string, defaultText?: string) => string;
  speakText: (text: string, customSpeechCode?: string) => void;
  stopSpeaking: () => void;
  isSpeaking: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<SupportedLanguage>(() => {
    const saved = localStorage.getItem('herdeye_language') as SupportedLanguage;
    if (saved && TRANSLATIONS[saved]) return saved;
    // Default to Telugu for farmer demo as requested in user prompt, or English
    return 'te';
  });

  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  const setLanguage = (lang: SupportedLanguage) => {
    setLanguageState(lang);
    localStorage.setItem('herdeye_language', lang);
  };

  const currentLangMeta = SUPPORTED_LANGUAGES.find(l => l.code === language) || SUPPORTED_LANGUAGES[0];

  const t = useCallback(
    (key: string, defaultText?: string): string => {
      const langDict = TRANSLATIONS[language];
      if (langDict && langDict[key]) {
        return langDict[key];
      }
      // Fallback to Telugu or English
      const teDict = TRANSLATIONS['te'];
      if (teDict && teDict[key]) return teDict[key];
      const enDict = TRANSLATIONS['en'];
      if (enDict && enDict[key]) return enDict[key];
      return defaultText || key;
    },
    [language]
  );

  const stopSpeaking = useCallback(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  }, []);

  const speakText = useCallback(
    (text: string, customSpeechCode?: string) => {
      if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
        console.warn('Speech synthesis not supported in this browser.');
        return;
      }

      window.speechSynthesis.cancel();

      // Clean emojis and symbols for cleaner speech
      const cleanText = text.replace(/[✅💉⚠️👨‍⚕️📴🔄🌾🌻🌴🥥🚩🌸👋👍❤️🍚💧🚶🥛🌡️📷📋📞📹📍🐃🐄]/g, '').trim();
      if (!cleanText) return;

      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.lang = customSpeechCode || currentLangMeta.speechCode;
      utterance.rate = 0.95; // Slightly slower for clarity in rural settings
      utterance.pitch = 1.0;

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      window.speechSynthesis.speak(utterance);
    },
    [currentLangMeta.speechCode]
  );

  // Stop speaking when language changes
  useEffect(() => {
    stopSpeaking();
  }, [language, stopSpeaking]);

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
        languages: SUPPORTED_LANGUAGES,
        currentLangMeta,
        t,
        speakText,
        stopSpeaking,
        isSpeaking,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
