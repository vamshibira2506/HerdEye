import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Animal,
  HealthAlert,
  OutbreakCluster,
  SymptomReport,
  UserRole,
  OfflineSyncItem,
  TreatmentRecord,
  LabReferralRecord,
  VaccinationRecord,
} from '../types';
import {
  INITIAL_ANIMALS,
  INITIAL_ALERTS,
  INITIAL_CLUSTERS,
  INITIAL_SYMPTOM_REPORTS,
} from '../data/mockLivestockData';

export type ActiveTab =
  | 'dashboard'
  | 'ai-monitoring'
  | 'animals'
  | 'reporting'
  | 'veterinary-cases'
  | 'vaccination'
  | 'lab-referrals'
  | 'mortality'
  | 'alerts'
  | 'geospatial'
  | 'reports'
  | 'offline-outbox';

interface LivestockContextType {
  role: UserRole;
  setRole: (role: UserRole) => void;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isOnline: boolean;
  setIsOnline: (online: boolean) => void;
  toggleOnlineStatus: () => void;
  animals: Animal[];
  alerts: HealthAlert[];
  clusters: OutbreakCluster[];
  symptomReports: SymptomReport[];
  offlineQueue: OfflineSyncItem[];
  selectedAnimal: Animal | null;
  setSelectedAnimal: (animal: Animal | null) => void;
  // Filters
  filterState: string;
  setFilterState: (state: string) => void;
  filterDistrict: string;
  setFilterDistrict: (district: string) => void;
  filterSpecies: string;
  setFilterSpecies: (species: string) => void;
  filterRisk: string;
  setFilterRisk: (risk: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  // Actions
  registerAnimal: (animal: Omit<Animal, 'id'>) => string;
  reportSymptoms: (report: Omit<SymptomReport, 'id' | 'timestamp' | 'status'>) => void;
  reportMortality: (data: { animalId: string; cause: string; postMortem: boolean; disposal: 'Buried with Lime' | 'Incinerated' | 'Pending Verification' }) => void;
  addVeterinaryTreatment: (animalId: string, treatment: Omit<TreatmentRecord, 'id'>) => void;
  requestLabReferral: (animalId: string, referral: Omit<LabReferralRecord, 'id'>) => void;
  addVaccination: (animalId: string, vaccination: Omit<VaccinationRecord, 'id'>) => void;
  updateAlertStatus: (alertId: string, status: HealthAlert['status']) => void;
  dismissAlert: (alertId: string) => void;
  updateReportStatus: (reportId: string, status: SymptomReport['status']) => void;
  syncOfflineQueue: () => Promise<void>;
  syncOfflineData: () => Promise<void>;
  clearOfflineQueue: () => void;
  toastMessage: { title: string; desc: string; type: 'success' | 'info' | 'warning' } | null;
  setToastMessage: (msg: { title: string; desc: string; type: 'success' | 'info' | 'warning' } | null) => void;
}

const LivestockContext = createContext<LivestockContextType | undefined>(undefined);

export const LivestockProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [role, setRole] = useState<UserRole>(() => {
    return (localStorage.getItem('herdeye_role') as UserRole) || 'farmer';
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine ?? true);

  // Core state from local storage or defaults
  const [animals, setAnimals] = useState<Animal[]>(() => {
    const saved = localStorage.getItem('herdeye_animals');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return INITIAL_ANIMALS;
  });

  const [alerts, setAlerts] = useState<HealthAlert[]>(() => {
    const saved = localStorage.getItem('herdeye_alerts');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return INITIAL_ALERTS;
  });

  const [clusters, setClusters] = useState<OutbreakCluster[]>(() => {
    const saved = localStorage.getItem('herdeye_clusters');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return INITIAL_CLUSTERS;
  });

  const [symptomReports, setSymptomReports] = useState<SymptomReport[]>(() => {
    const saved = localStorage.getItem('herdeye_reports');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return INITIAL_SYMPTOM_REPORTS;
  });

  const [offlineQueue, setOfflineQueue] = useState<OfflineSyncItem[]>(() => {
    const saved = localStorage.getItem('herdeye_offline_queue');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return [];
  });

  const [selectedAnimal, setSelectedAnimal] = useState<Animal | null>(null);

  // Global filters
  const [filterState, setFilterState] = useState<string>('All');
  const [filterDistrict, setFilterDistrict] = useState<string>('All');
  const [filterSpecies, setFilterSpecies] = useState<string>('All');
  const [filterRisk, setFilterRisk] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [toastMessage, setToastMessage] = useState<{ title: string; desc: string; type: 'success' | 'info' | 'warning' } | null>(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('herdeye_role', role);
  }, [role]);

  useEffect(() => {
    localStorage.setItem('herdeye_animals', JSON.stringify(animals));
  }, [animals]);

  useEffect(() => {
    localStorage.setItem('herdeye_alerts', JSON.stringify(alerts));
  }, [alerts]);

  useEffect(() => {
    localStorage.setItem('herdeye_clusters', JSON.stringify(clusters));
  }, [clusters]);

  useEffect(() => {
    localStorage.setItem('herdeye_reports', JSON.stringify(symptomReports));
  }, [symptomReports]);

  useEffect(() => {
    localStorage.setItem('herdeye_offline_queue', JSON.stringify(offlineQueue));
  }, [offlineQueue]);

  // Network listeners
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      showToast('Network Restored', 'Back online. You can sync cached field reports.', 'info');
    };
    const handleOffline = () => {
      setIsOnline(false);
      showToast('Offline Mode Active', 'Operating offline. Reports will be saved locally in outbox.', 'warning');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const showToast = (title: string, desc: string, type: 'success' | 'info' | 'warning' = 'info') => {
    setToastMessage({ title, desc, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  const toggleOnlineStatus = () => {
    const nextState = !isOnline;
    setIsOnline(nextState);
    if (nextState) {
      showToast('Simulated: Network Online', 'Cloud link active. Synced status enabled.', 'success');
    } else {
      showToast('Simulated: Offline Mode', 'Testing disconnected village/remote field worker mode.', 'warning');
    }
  };

  const registerAnimal = (newAnimalData: Omit<Animal, 'id'>): string => {
    const stateCode = newAnimalData.location.state === 'Gujarat' ? 'GJ' : newAnimalData.location.state === 'Haryana' ? 'HR' : newAnimalData.location.state === 'Punjab' ? 'PB' : 'UP';
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const newId = `IN-${stateCode}-2024-${randomNum}`;

    const newAnimal: Animal = {
      ...newAnimalData,
      id: newId,
    };

    if (!isOnline) {
      const queueItem: OfflineSyncItem = {
        id: 'OFF-' + Date.now(),
        type: 'animal_register',
        title: `Register: ${newAnimal.name} (${newId})`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        synced: false,
        payload: newAnimal,
      };
      setOfflineQueue(prev => [queueItem, ...prev]);
      setAnimals(prev => [newAnimal, ...prev]);
      showToast('Animal Registered (Offline)', `Stored locally. ID: ${newId}. Queued for synchronization.`, 'warning');
      return newId;
    }

    setAnimals(prev => [newAnimal, ...prev]);
    showToast('Animal Successfully Registered', `RFID/Tag: ${newId} verified and added to HerdEye database.`, 'success');
    return newId;
  };

  const reportSymptoms = (reportData: Omit<SymptomReport, 'id' | 'timestamp' | 'status'>) => {
    const newId = `RPT-${Date.now().toString().slice(-6)}`;
    const newReport: SymptomReport = {
      ...reportData,
      id: newId,
      timestamp: new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }),
      status: 'Submitted',
    };

    // Also update the animal's symptoms and risk score
    setAnimals(prev =>
      prev.map(a => {
        if (a.id === reportData.animalId) {
          const highRisk = reportData.severity === 'Critical' || reportData.severity === 'Severe';
          const newScore = highRisk ? Math.max(a.riskScore, 85) : Math.max(a.riskScore, 60);
          return {
            ...a,
            currentSymptoms: Array.from(new Set([...a.currentSymptoms, ...reportData.symptoms])),
            healthStatus: highRisk ? 'High Risk / Critical' : 'Under Observation',
            riskScore: newScore,
            riskPriority: highRisk ? 'High' : 'Medium',
            lastChecked: 'Just now',
          };
        }
        return a;
      })
    );

    // Create an alert automatically
    const targetAnimal = animals.find(a => a.id === reportData.animalId);
    if (targetAnimal && (reportData.severity === 'Severe' || reportData.severity === 'Critical')) {
      const newAlert: HealthAlert = {
        id: `ALT-NEW-${Date.now().toString().slice(-4)}`,
        animalId: targetAnimal.id,
        animalName: targetAnimal.name,
        species: targetAnimal.species,
        breed: targetAnimal.breed,
        title: `Priority Farmer Report: ${reportData.symptoms[0] || 'Severe Symptoms'}`,
        suspectedDisease: 'Syndromic Alert - Field Veterinary Review Required',
        priority: reportData.severity === 'Critical' ? 'Critical' : 'High',
        confidenceScore: 88,
        detectedAt: new Date().toLocaleString(),
        village: targetAnimal.location.village,
        district: targetAnimal.location.district,
        state: targetAnimal.location.state,
        symptoms: reportData.symptoms,
        aiObservations: `Farmer reported ${reportData.severity.toLowerCase()} symptoms (${reportData.symptoms.join(', ')}). Immediate triage assigned to area veterinary officer.`,
        recommendedAction: 'Dispatch field inspection unit or connect with farmer via tele-vet consultation.',
        status: 'New',
        evidenceImageUrl: reportData.photoUrl,
        evidenceVideoUrl: reportData.videoUrl,
      };
      setAlerts(prev => [newAlert, ...prev]);
    }

    if (!isOnline) {
      const queueItem: OfflineSyncItem = {
        id: 'OFF-' + Date.now(),
        type: 'symptom_report',
        title: `Symptom Report: Animal ${reportData.animalId}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        synced: false,
        payload: newReport,
      };
      setOfflineQueue(prev => [queueItem, ...prev]);
      setSymptomReports(prev => [newReport, ...prev]);
      showToast('Report Saved to Offline Queue', 'Saved in device storage. Will auto-sync when network returns.', 'warning');
      return;
    }

    setSymptomReports(prev => [newReport, ...prev]);
    showToast('Symptom Report Logged', 'Submitted to Veterinary Hub and National Surveillance Desk.', 'success');
  };

  const reportMortality = (data: { animalId: string; cause: string; postMortem: boolean; disposal: 'Buried with Lime' | 'Incinerated' | 'Pending Verification' }) => {
    const record = {
      date: new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }),
      suspectedCause: data.cause,
      reportedBy: `${role === 'farmer' ? 'Ramesh Patel (Farmer)' : role === 'field_worker' ? 'Field Worker Anjali' : 'Dr. Sharma MVSc'}`,
      postMortemRequested: data.postMortem,
      carcassDisposalStatus: data.disposal,
      disposalVerifiedBy: role === 'veterinarian' ? 'Dr. Sharma MVSc' : undefined,
    };

    setAnimals(prev =>
      prev.map(a => {
        if (a.id === data.animalId) {
          return {
            ...a,
            healthStatus: 'Deceased',
            riskScore: 100,
            riskPriority: 'Critical',
            mortalityRecord: record,
            lastChecked: 'Mortality Recorded Today',
          };
        }
        return a;
      })
    );

    // Update clusters mortality count
    const targetAnimal = animals.find(a => a.id === data.animalId);
    if (targetAnimal) {
      setClusters(prev =>
        prev.map(c => {
          if (c.district.toLowerCase() === targetAnimal.location.district.toLowerCase()) {
            return {
              ...c,
              mortalities: c.mortalities + 1,
              lastUpdated: 'Today',
            };
          }
          return c;
        })
      );
    }

    if (!isOnline) {
      const queueItem: OfflineSyncItem = {
        id: 'OFF-' + Date.now(),
        type: 'mortality_report',
        title: `Mortality: Animal ${data.animalId}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        synced: false,
        payload: { ...data, record },
      };
      setOfflineQueue(prev => [queueItem, ...prev]);
      showToast('Mortality Report Stored (Offline)', 'Recorded in offline log with bio-disposal guidelines.', 'warning');
      return;
    }

    showToast('Mortality Event Recorded', 'Government epidemiology surveillance and carcass disposal team notified.', 'info');
  };

  const addVeterinaryTreatment = (animalId: string, treatment: Omit<TreatmentRecord, 'id'>) => {
    const newRecord: TreatmentRecord = {
      ...treatment,
      id: `TRT-${Date.now().toString().slice(-4)}`,
    };

    setAnimals(prev =>
      prev.map(a => {
        if (a.id === animalId) {
          return {
            ...a,
            healthStatus: 'Under Observation',
            riskScore: Math.max(20, a.riskScore - 20),
            treatmentHistory: [newRecord, ...a.treatmentHistory],
          };
        }
        return a;
      })
    );

    // Update corresponding alerts
    setAlerts(prev =>
      prev.map(al => (al.animalId === animalId ? { ...al, status: 'Treated' } : al))
    );

    showToast('Treatment Prescription Saved', `Diagnosis & medicine dosage recorded for Animal #${animalId}.`, 'success');
  };

  const requestLabReferral = (animalId: string, referral: Omit<LabReferralRecord, 'id'>) => {
    const newRecord: LabReferralRecord = {
      ...referral,
      id: `LAB-${Date.now().toString().slice(-4)}`,
    };

    setAnimals(prev =>
      prev.map(a => {
        if (a.id === animalId) {
          return {
            ...a,
            labReferrals: [newRecord, ...a.labReferrals],
          };
        }
        return a;
      })
    );

    showToast('Lab Diagnostic Requested', `Sample ${newRecord.sampleId} dispatched to ${newRecord.labName}.`, 'info');
  };

  const addVaccination = (animalId: string, vaccination: Omit<VaccinationRecord, 'id'>) => {
    const newRecord: VaccinationRecord = {
      ...vaccination,
      id: `VAC-${Date.now().toString().slice(-4)}`,
    };

    setAnimals(prev =>
      prev.map(a => {
        if (a.id === animalId) {
          return {
            ...a,
            vaccinationRecords: [newRecord, ...a.vaccinationRecords],
          };
        }
        return a;
      })
    );

    showToast('Vaccination Logged', `Administered ${newRecord.vaccineName} with batch ${newRecord.batchNumber}.`, 'success');
  };

  const updateAlertStatus = (alertId: string, status: HealthAlert['status']) => {
    setAlerts(prev =>
      prev.map(a => (a.id === alertId ? { ...a, status } : a))
    );
    showToast('Alert Status Updated', `Alert marked as ${status}.`, 'info');
  };

  const dismissAlert = (alertId: string) => {
    updateAlertStatus(alertId, 'Dismissed');
  };

  const updateReportStatus = (reportId: string, status: SymptomReport['status']) => {
    setSymptomReports(prev =>
      prev.map(r => (r.id === reportId ? { ...r, status } : r))
    );
    showToast('Report Status Updated', `Report status changed to ${status}.`, 'info');
  };

  const syncOfflineQueue = async () => {
    if (!isOnline) {
      showToast('Cannot Sync in Offline Mode', 'Please toggle online status or reconnect to network.', 'warning');
      return;
    }

    if (offlineQueue.length === 0) {
      showToast('Outbox Empty', 'All records are already synchronized with central cloud registry.', 'info');
      return;
    }

    const count = offlineQueue.length;
    setOfflineQueue([]);
    showToast('Sync Successful', `Successfully uploaded ${count} pending record(s) to National Livestock Portal.`, 'success');
  };

  const syncOfflineData = syncOfflineQueue;

  const clearOfflineQueue = () => {
    setOfflineQueue([]);
    showToast('Queue Cleared', 'Offline outbox items cleared.', 'info');
  };

  return (
    <LivestockContext.Provider
      value={{
        role,
        setRole,
        activeTab,
        setActiveTab,
        isOnline,
        setIsOnline,
        toggleOnlineStatus,
        animals,
        alerts,
        clusters,
        symptomReports,
        offlineQueue,
        selectedAnimal,
        setSelectedAnimal,
        filterState,
        setFilterState,
        filterDistrict,
        setFilterDistrict,
        filterSpecies,
        setFilterSpecies,
        filterRisk,
        setFilterRisk,
        searchQuery,
        setSearchQuery,
        registerAnimal,
        reportSymptoms,
        reportMortality,
        addVeterinaryTreatment,
        requestLabReferral,
        addVaccination,
        updateAlertStatus,
        dismissAlert,
        updateReportStatus,
        syncOfflineQueue,
        syncOfflineData,
        clearOfflineQueue,
        toastMessage,
        setToastMessage,
      }}
    >
      {children}
    </LivestockContext.Provider>
  );
};

export const useLivestock = () => {
  const context = useContext(LivestockContext);
  if (!context) {
    throw new Error('useLivestock must be used within a LivestockProvider');
  }
  return context;
};
