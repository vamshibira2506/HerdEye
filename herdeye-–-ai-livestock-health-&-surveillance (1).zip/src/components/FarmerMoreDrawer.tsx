import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useLivestock } from '../context/LivestockContext';
import {
  User,
  Globe,
  Volume2,
  Stethoscope,
  MapPin,
  FileText,
  Syringe,
  BookOpen,
  PhoneCall,
  Settings,
  X,
  ChevronRight,
  Shield,
  Layers,
} from 'lucide-react';

interface FarmerMoreDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenLanguage: () => void;
  onOpenVoice: () => void;
  onOpenDoctor: () => void;
  onOpenLearn: () => void;
  onOpenVaccination: () => void;
  onOpenSwitchRole: () => void;
}

export const FarmerMoreDrawer: React.FC<FarmerMoreDrawerProps> = ({
  isOpen,
  onClose,
  onOpenLanguage,
  onOpenVoice,
  onOpenDoctor,
  onOpenLearn,
  onOpenVaccination,
  onOpenSwitchRole,
}) => {
  const { t, currentLangMeta } = useLanguage();
  const { setActiveTab } = useLivestock();

  if (!isOpen) return null;

  const menuItems = [
    {
      id: 'profile',
      label: t('menu_profile', 'నా ప్రొఫైల్ (My Profile)'),
      sub: 'రమేష్ పటేల్ • శ్రీ రామ్ డైరీ ఫామ్',
      icon: User,
      color: 'bg-emerald-100 text-emerald-700',
      action: () => {},
    },
    {
      id: 'language',
      label: t('menu_language', 'భాష (Language)'),
      sub: `${currentLangMeta.flag} ${currentLangMeta.nativeName} (${currentLangMeta.name})`,
      icon: Globe,
      color: 'bg-teal-100 text-teal-700',
      action: () => {
        onClose();
        onOpenLanguage();
      },
    },
    {
      id: 'voice',
      label: t('menu_voice', 'వాయిస్ అసిస్టెంట్ (Voice Settings)'),
      sub: 'సహజమైన భాషలో మాట్లాడి చెప్పండి',
      icon: Volume2,
      color: 'bg-amber-100 text-amber-700',
      action: () => {
        onClose();
        onOpenVoice();
      },
    },
    {
      id: 'vet',
      label: t('menu_my_vet', 'నా పశువుల డాక్టర్ (My Veterinarian)'),
      sub: 'డాక్టర్ వి. కే. శర్మ • ఆనంద్ పాలీక్లినిక్',
      icon: Stethoscope,
      color: 'bg-sky-100 text-sky-700',
      action: () => {
        onClose();
        onOpenDoctor();
      },
    },
    {
      id: 'village',
      label: t('menu_village', 'నా గ్రామం (My Village)'),
      sub: 'మోగ్రి, ఆనంద్ జిల్లా, గుజరాత్',
      icon: MapPin,
      color: 'bg-indigo-100 text-indigo-700',
      action: () => {},
    },
    {
      id: 'reports',
      label: t('menu_health_reports', 'ఆరోగ్య నివేదికలు (Health Reports)'),
      sub: 'నమోదైన సమస్యలు & డాక్టర్ పరిశీలనలు',
      icon: FileText,
      color: 'bg-purple-100 text-purple-700',
      action: () => {
        onClose();
        setActiveTab('reporting');
      },
    },
    {
      id: 'vaccine',
      label: t('menu_vaccination', 'టీకాల పట్టిక (Vaccination)'),
      sub: 'వ్యాధి నిరోధక టీకాలు & రిమైండర్లు',
      icon: Syringe,
      color: 'bg-rose-100 text-rose-700',
      action: () => {
        onClose();
        onOpenVaccination();
      },
    },
    {
      id: 'learn',
      label: t('menu_learn', 'రైతు పాఠాలు / విద్య (Learn)'),
      sub: 'పశు సంరక్షణ పద్ధతులు & వ్యాధి నివారణ',
      icon: BookOpen,
      color: 'bg-amber-100 text-amber-700',
      action: () => {
        onClose();
        onOpenLearn();
      },
    },
    {
      id: 'help',
      label: t('menu_help', 'సహాయం / హెల్ప్‌లైన్ 1962 (Help)'),
      sub: '24x7 జాతీయ పశు అంబులెన్స్ సేవ',
      icon: PhoneCall,
      color: 'bg-emerald-100 text-emerald-800',
      action: () => {
        window.open('tel:1962');
      },
    },
    {
      id: 'switch_view',
      label: t('menu_switch_role', 'ఇతర డ్యాష్‌బోర్డ్ చూడండి (Switch View)'),
      sub: 'పశు సఖి, వెటర్నరీ లేదా ప్రభుత్వ డెస్క్',
      icon: Layers,
      color: 'bg-slate-200 text-slate-800',
      action: () => {
        onClose();
        onOpenSwitchRole();
      },
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white w-full max-w-sm h-full shadow-2xl flex flex-col overflow-hidden animate-slide-left">
        {/* Top Header */}
        <div className="bg-gradient-to-r from-emerald-800 to-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="text-xl">☰</span>
            <h3 className="text-base font-black tracking-tight">{t('nav_more', 'మరిన్ని ఎంపికలు')}</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Menu Items list */}
        <div className="p-3.5 overflow-y-auto flex-1 divide-y divide-slate-100 space-y-1">
          {menuItems.map(item => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={item.action}
                className="w-full flex items-center gap-3 p-3 rounded-2xl hover:bg-slate-50 transition text-left group"
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${item.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-black text-slate-900 group-hover:text-emerald-900 truncate">
                    {item.label}
                  </p>
                  <p className="text-[11px] text-slate-400 truncate">{item.sub}</p>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-slate-500" />
              </button>
            );
          })}
        </div>

        {/* Bottom copyright / helpline */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 text-center text-[11px] text-slate-400">
          HerdEye • రైతు మిత్ర వెర్షన్ 2.0 • Digital Livestock Mission
        </div>
      </div>
    </div>
  );
};
