import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Home, AlertTriangle, Bell, Menu } from 'lucide-react';

export type FarmerActiveNav = 'home' | 'animals' | 'problems' | 'alerts' | 'more';

interface FarmerBottomNavProps {
  currentNav: FarmerActiveNav;
  onChangeNav: (nav: FarmerActiveNav) => void;
  alertsCount?: number;
}

export const FarmerBottomNav: React.FC<FarmerBottomNavProps> = ({
  currentNav,
  onChangeNav,
  alertsCount = 0,
}) => {
  const { t } = useLanguage();

  const navItems: Array<{
    id: FarmerActiveNav;
    label: string;
    icon: any;
    isCustomIcon?: boolean;
    customEmoji?: string;
    badge?: number;
  }> = [
    {
      id: 'home',
      label: t('nav_home', 'హోమ్'),
      icon: Home,
    },
    {
      id: 'animals',
      label: t('nav_animals', 'నా పశువులు'),
      icon: null,
      isCustomIcon: true,
      customEmoji: '🐃',
    },
    {
      id: 'problems',
      label: t('nav_problems', 'సమస్యలు'),
      icon: AlertTriangle,
    },
    {
      id: 'alerts',
      label: t('nav_alerts', 'హెచ్చరికలు'),
      icon: Bell,
      badge: alertsCount > 0 ? alertsCount : undefined,
    },
    {
      id: 'more',
      label: t('nav_more', 'మరిన్ని'),
      icon: Menu,
    },
  ];

  return (
    <nav
      id="farmer-bottom-nav"
      className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-lg px-2 py-1.5 safe-area-bottom"
    >
      <div className="max-w-md mx-auto flex items-center justify-around">
        {navItems.map(item => {
          const isActive = currentNav === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => onChangeNav(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition relative active:scale-95 ${
                isActive
                  ? 'text-emerald-700 font-extrabold'
                  : 'text-slate-500 hover:text-slate-800 font-semibold'
              }`}
            >
              <div className="relative">
                {item.isCustomIcon ? (
                  <span className={`text-2xl transition-transform ${isActive ? 'scale-110' : ''}`}>
                    {item.customEmoji}
                  </span>
                ) : (
                  <Icon className={`w-6 h-6 transition-transform ${isActive ? 'scale-110 stroke-[2.5]' : 'stroke-2'}`} />
                )}

                {item.badge && item.badge > 0 && (
                  <span className="absolute -top-1 -right-2 bg-rose-600 text-white text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                    {item.badge}
                  </span>
                )}
              </div>

              <span className={`text-[11px] mt-0.5 tracking-tight ${isActive ? 'font-black' : 'font-semibold'}`}>
                {item.label}
              </span>

              {isActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 mt-0.5 animate-pulse" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
