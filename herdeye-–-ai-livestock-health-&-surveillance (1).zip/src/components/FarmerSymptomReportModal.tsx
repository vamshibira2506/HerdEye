import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { useLanguage } from '../context/LanguageContext';
import { Animal } from '../types';
import { EvidenceVideoRecorder } from './EvidenceVideoRecorder';
import {
  X,
  Volume2,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  AlertTriangle,
  Camera,
  Video,
  PhoneCall,
  MapPin,
  Sparkles,
} from 'lucide-react';

interface FarmerSymptomReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedAnimal?: Animal | null;
  initialSymptomKey?: string;
  onOpenTalkToDoctor?: () => void;
}

export const FarmerSymptomReportModal: React.FC<FarmerSymptomReportModalProps> = ({
  isOpen,
  onClose,
  preselectedAnimal,
  initialSymptomKey,
  onOpenTalkToDoctor,
}) => {
  const { animals, reportSymptoms } = useLivestock();
  const { t, speakText } = useLanguage();

  const farmerAnimals = animals;
  const [selectedAnimalId, setSelectedAnimalId] = useState<string>(
    preselectedAnimal?.id || farmerAnimals[0]?.id || ''
  );

  const [step, setStep] = useState<1 | 2 | 3 | 4 | 5>(1); // Step 5 is Urgent Alert if serious
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>(
    initialSymptomKey ? [initialSymptomKey] : []
  );
  const [duration, setDuration] = useState<string>('today');
  const [evidenceVideo, setEvidenceVideo] = useState<{ url: string; durationSec: number } | null>(null);
  const [showVideoRecorder, setShowVideoRecorder] = useState<boolean>(false);
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);

  // 9 visual problem buttons per Requirement 8
  const symptomOptions = [
    { key: 'not_eating', label: t('sym_not_eating', 'మేత తినడం లేదు'), icon: '🍚', urgent: false },
    { key: 'milk_down', label: t('sym_milk_down', 'పాలు తగ్గాయి'), icon: '🥛', urgent: false },
    { key: 'limping', label: t('sym_limping', 'నడవడానికి ఇబ్బంది / కుంటుతోంది'), icon: '🚶', urgent: true },
    { key: 'eye_problem', label: t('sym_eye_problem', 'కంటి సమస్య / నీరు'), icon: '👁️', urgent: false },
    { key: 'nose_problem', label: t('sym_nose_problem', 'ముక్కు కారడం / లాలాజలం'), icon: '👃', urgent: true },
    { key: 'wound', label: t('sym_wound', 'గాయం లేదా వాపు'), icon: '🩹', urgent: false },
    { key: 'sick_fever', label: t('sym_sick_fever', 'జ్వరం / నీరసం'), icon: '🤒', urgent: true },
    { key: 'digestive', label: t('sym_digestive', 'విరేచనాలు / కడుపు ఉబ్బరం'), icon: '💩', urgent: false },
    { key: 'other', label: t('sym_other', 'ఇతర సమస్య'), icon: '🐄', urgent: false },
  ];

  // Durations
  const durationOptions = [
    { key: 'today', label: t('dur_today', 'ఈరోజే మొదలైంది'), desc: 'Started today', icon: '⏱️' },
    { key: '1_3_days', label: t('dur_1_3_days', '1 నుండి 3 రోజులు'), desc: '1 to 3 days', icon: '📅' },
    { key: 'more_3_days', label: t('dur_more_3_days', '3 రోజుల కంటే ఎక్కువ'), desc: 'More than 3 days', icon: '⚠️' },
    { key: 'unknown', label: t('dur_unknown', 'నాకు తెలియదు'), desc: 'Not sure', icon: '❓' },
  ];

  const toggleSymptom = (key: string) => {
    if (selectedSymptoms.includes(key)) {
      setSelectedSymptoms(selectedSymptoms.filter(s => s !== key));
    } else {
      setSelectedSymptoms([...selectedSymptoms, key]);
    }
  };

  const currentAnimal = farmerAnimals.find(a => a.id === selectedAnimalId) || farmerAnimals[0];

  // Evaluate if symptom combination warrants Requirement 9 "EMERGENCY / URGENT ALERT"
  const isUrgent =
    (selectedSymptoms.includes('sick_fever') && selectedSymptoms.includes('limping')) ||
    (selectedSymptoms.includes('sick_fever') && selectedSymptoms.includes('nose_problem')) ||
    (duration === 'more_3_days' && selectedSymptoms.length >= 2);

  const handleSubmit = (sendToDoctor: boolean) => {
    const symptomLabels = selectedSymptoms.map(sKey => {
      const match = symptomOptions.find(o => o.key === sKey);
      return match ? match.label : sKey;
    });

    reportSymptoms({
      animalId: currentAnimal?.id || 'IN-ANIMAL',
      reportedBy: 'Ramesh Patel (Farmer)',
      reporterRole: 'farmer',
      reporterPhone: '+91 98250 11982',
      symptoms: symptomLabels.length > 0 ? symptomLabels : ['Health Concern Reported'],
      severity: isUrgent ? 'Critical' : duration === 'more_3_days' ? 'Severe' : 'Moderate',
      onsetDate: new Date().toISOString().split('T')[0],
      notes: `Reported via simple farmer flow. Duration: ${duration}. Send to Vet: ${sendToDoctor ? 'Yes' : 'Local Save'}.`,
      location: currentAnimal?.location || {
        farmName: 'Shri Ram Dairy',
        village: 'Mogri',
        block: 'Anand',
        district: 'Anand',
        state: 'Gujarat',
        lat: 22.5645,
        lng: 72.9289,
      },
      videoUrl: evidenceVideo?.url,
      videoDurationSeconds: evidenceVideo?.durationSec,
      photoUrl: photoUrl || undefined,
    });

    if (isUrgent && sendToDoctor) {
      // Show Urgent Alert screen
      setStep(5);
    } else {
      setIsSubmitted(true);
      setTimeout(() => {
        onClose();
        setIsSubmitted(false);
        setStep(1);
        setSelectedSymptoms([]);
        setEvidenceVideo(null);
      }, 1600);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/75 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border-4 border-emerald-500 overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 px-5 py-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <span className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center text-xl shadow-inner">
              📋
            </span>
            <div>
              <h2 className="font-black text-lg sm:text-xl tracking-tight leading-tight">
                {t('btn_report_problem', 'పశువుకు సమస్య ఉందా?')}
              </h2>
              <p className="text-emerald-100 text-xs font-semibold">
                Step {step === 5 ? '⚠️' : step} of 4 • {currentAnimal?.name || 'Animal'} ({currentAnimal?.species})
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                if (step === 1) speakText(t('step1_title', 'ఏ సమస్య కనిపిస్తోంది?'));
                if (step === 2) speakText(t('step2_title', 'ఎన్ని రోజుల నుండి ఈ సమస్య ఉంది?'));
                if (step === 3) speakText(t('step3_title', 'ఫోటో లేదా వీడియో చూపించండి'));
                if (step === 4) speakText(t('step4_title', 'పశువుల డాక్టర్‌కు పంపించాలా?'));
                if (step === 5) speakText(t('urgent_warning_title', 'మీ పశువుకు తక్షణ శ్రద్ధ అవసరం కావచ్చు'));
              }}
              className="p-2 rounded-xl bg-white/20 hover:bg-white/30 text-white transition flex items-center gap-1 text-xs font-bold"
              title="Read aloud"
            >
              <Volume2 className="w-4 h-4" />
              <span className="hidden sm:inline">{t('voice_listen', 'వినండి')}</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-black/20 hover:bg-black/30 text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Animal Selector Strip */}
        <div className="bg-emerald-50 px-5 py-2.5 border-b border-emerald-100 flex items-center justify-between gap-2 overflow-x-auto shrink-0">
          <span className="text-xs font-bold text-emerald-950 shrink-0">
            {t('btn_my_animals', 'పశువును ఎంచుకోండి')}:
          </span>
          <div className="flex items-center gap-2">
            {farmerAnimals.map(a => (
              <button
                key={a.id}
                onClick={() => setSelectedAnimalId(a.id)}
                className={`px-3 py-1 rounded-xl text-xs font-extrabold transition shrink-0 flex items-center gap-1.5 ${
                  selectedAnimalId === a.id
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-white text-slate-700 border border-slate-200 hover:bg-emerald-100'
                }`}
              >
                <span>{a.species === 'Buffalo' ? '🐃' : '🐄'}</span>
                <span>{a.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Step Body */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1">
          {/* STEP 1: What problem do you see? (9 picture buttons) */}
          {step === 1 && (
            <div className="space-y-4">
              <div className="text-center sm:text-left">
                <h3 className="text-lg sm:text-xl font-black text-slate-900 leading-tight">
                  {t('step1_title', 'ఏ సమస్య కనిపిస్తోంది?')}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  ఒకటి లేదా అంతకంటే ఎక్కువ సమస్యలను తాకండి (Touch to select)
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {symptomOptions.map(opt => {
                  const isSelected = selectedSymptoms.includes(opt.key);
                  return (
                    <button
                      key={opt.key}
                      onClick={() => toggleSymptom(opt.key)}
                      className={`flex flex-col items-center justify-center p-3.5 sm:p-4 rounded-2xl border-3 text-center transition active:scale-95 cursor-pointer ${
                        isSelected
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-950 shadow-md ring-2 ring-emerald-300'
                          : 'border-slate-200 bg-slate-50 hover:bg-white hover:border-slate-300 text-slate-800'
                      }`}
                    >
                      <span className="text-3xl sm:text-4xl mb-2">{opt.icon}</span>
                      <span className="text-xs sm:text-sm font-black leading-tight line-clamp-2">
                        {opt.label}
                      </span>
                      {isSelected && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-1.5" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 2: How long? */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="text-center sm:text-left">
                <h3 className="text-lg sm:text-xl font-black text-slate-900 leading-tight">
                  {t('step2_title', 'ఎన్ని రోజుల నుండి ఈ సమస్య ఉంది?')}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  సమస్య మొదలైన సమయాన్ని ఎంచుకోండి
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {durationOptions.map(dur => {
                  const isSelected = duration === dur.key;
                  return (
                    <button
                      key={dur.key}
                      onClick={() => setDuration(dur.key)}
                      className={`flex items-center gap-3.5 p-4 rounded-2xl border-3 text-left transition active:scale-98 ${
                        isSelected
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-950 ring-2 ring-emerald-300'
                          : 'border-slate-200 bg-slate-50 hover:bg-white text-slate-800'
                      }`}
                    >
                      <span className="text-3xl">{dur.icon}</span>
                      <div className="flex-1">
                        <p className="text-sm font-black text-slate-900">{dur.label}</p>
                        <p className="text-xs text-slate-500">{dur.desc}</p>
                      </div>
                      {isSelected && (
                        <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 3: Show us (Photo or 15s Video) */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="text-center sm:text-left">
                <h3 className="text-lg sm:text-xl font-black text-slate-900 leading-tight">
                  {t('step3_title', 'ఫోటో లేదా వీడియో చూపించండి (ఐచ్ఛికం)')}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  డాక్టర్ స్పష్టంగా పరిశీలించడానికి 15 సెకన్ల చిన్న వీడియో తీయండి
                </p>
              </div>

              {/* 15s Video Recording Box */}
              <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Video className="w-5 h-5 text-rose-600" />
                    <span className="text-xs sm:text-sm font-black text-slate-900">
                      15 సెకన్ల క్లినికల్ వీడియో (Evidence Video)
                    </span>
                  </div>
                  {evidenceVideo && (
                    <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Video Ready ({evidenceVideo.durationSec}s)
                    </span>
                  )}
                </div>

                {evidenceVideo ? (
                  <div className="relative rounded-xl overflow-hidden bg-black aspect-video max-h-48 flex items-center justify-center">
                    <video
                      src={evidenceVideo.url}
                      controls
                      className="w-full h-full object-contain"
                    />
                    <button
                      onClick={() => setEvidenceVideo(null)}
                      className="absolute top-2 right-2 bg-rose-600 text-white text-xs px-2.5 py-1 rounded-lg font-bold shadow-md"
                    >
                      Delete / Re-record
                    </button>
                  </div>
                ) : (
                  <div>
                    {!showVideoRecorder ? (
                      <button
                        onClick={() => setShowVideoRecorder(true)}
                        className="w-full py-4 bg-rose-600 hover:bg-rose-500 text-white rounded-2xl font-black text-sm flex items-center justify-center gap-2 shadow-md transition active:scale-98"
                      >
                        <Video className="w-5 h-5" />
                        <span>{t('btn_take_video', '15 సెకన్ల వీడియో రికార్డ్ చేయండి')}</span>
                      </button>
                    ) : (
                      <div className="border border-slate-300 rounded-xl p-2 bg-white">
                        <EvidenceVideoRecorder
                          onVideoSelected={(data) => {
                            setEvidenceVideo({ url: data.videoUrl, durationSec: data.durationSeconds });
                            setShowVideoRecorder(false);
                          }}
                          onClearVideo={() => setShowVideoRecorder(false)}
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Photo Upload Option */}
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    // Quick sample photo trigger or upload
                    setPhotoUrl('https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=600&q=80');
                  }}
                  className={`flex-1 py-3 px-4 rounded-xl border-2 font-extrabold text-xs flex items-center justify-center gap-2 transition ${
                    photoUrl
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-900'
                      : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <Camera className="w-4 h-4 text-emerald-600" />
                  <span>{photoUrl ? 'ఫోటో జతచేయబడింది (Photo Added)' : t('btn_take_photo', 'ఫోటో తీయండి')}</span>
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: Send to veterinarian? */}
          {step === 4 && (
            <div className="space-y-4">
              <div className="text-center">
                <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center text-2xl mx-auto mb-2">
                  👨‍⚕️
                </div>
                <h3 className="text-lg sm:text-xl font-black text-slate-900 leading-tight">
                  {t('step4_title', 'పశువుల డాక్టర్‌కు పంపించాలా?')}
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                  డాక్టర్ వి. కె. శర్మ (ఆనంద్ పశువైద్యశాల) కు పశువు వివరాలు, ఫోటో/వీడియో వెంటనే వెళ్తాయి.
                </p>
              </div>

              {/* Summary Card */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2 text-xs">
                <div className="flex justify-between pb-1 border-b border-slate-200">
                  <span className="text-slate-500">పశువు (Animal):</span>
                  <span className="font-extrabold text-slate-800">{currentAnimal.name} ({currentAnimal.id})</span>
                </div>
                <div className="flex justify-between pb-1 border-b border-slate-200">
                  <span className="text-slate-500">సమస్యలు (Symptoms):</span>
                  <span className="font-extrabold text-slate-800">
                    {selectedSymptoms.map(k => symptomOptions.find(o => o.key === k)?.label).join(', ') || 'General Concern'}
                  </span>
                </div>
                <div className="flex justify-between pb-1 border-b border-slate-200">
                  <span className="text-slate-500">వ్యవధి (Duration):</span>
                  <span className="font-extrabold text-slate-800">
                    {durationOptions.find(d => d.key === duration)?.label}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">వీడియో సాక్ష్యం (15s Video):</span>
                  <span className="font-extrabold text-slate-800">
                    {evidenceVideo ? `✅ ${evidenceVideo.durationSec}s Video Attached` : 'లేదు (None)'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <button
                  onClick={() => handleSubmit(true)}
                  className="py-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-700/20 active:scale-95"
                >
                  <CheckCircle2 className="w-5 h-5" />
                  <span>{t('btn_send_yes', 'అవును, డాక్టర్‌కు పంపండి')}</span>
                </button>
                <button
                  onClick={() => handleSubmit(false)}
                  className="py-4 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-2xl font-black text-sm flex items-center justify-center gap-2 active:scale-95"
                >
                  <span>{t('btn_send_no', 'ఇప్పుడే వద్దు, సేవ్ చేయండి')}</span>
                </button>
              </div>
            </div>
          )}

          {/* STEP 5: EMERGENCY / URGENT ALERT (Per Requirement 9) */}
          {step === 5 && (
            <div className="space-y-4 text-center py-2">
              <div className="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center text-3xl mx-auto ring-8 ring-rose-50 animate-pulse">
                🔴
              </div>
              <div>
                <h3 className="text-xl sm:text-2xl font-black text-rose-700 leading-tight">
                  {t('urgent_warning_title', 'మీ పశువుకు తక్షణ శ్రద్ధ అవసరం కావచ్చు')}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto mt-2 leading-relaxed">
                  {t('urgent_warning_desc', 'ఈ లక్షణాలు తీవ్రమైనవి కావచ్చు. దయచేసి వెంటనే పశువుల డాక్టర్‌ను సంప్రదించండి.')}
                </p>
              </div>

              <div className="space-y-2.5 pt-2 max-w-sm mx-auto">
                <a
                  href="tel:+919825011982"
                  className="w-full py-4 bg-rose-600 hover:bg-rose-500 text-white rounded-2xl font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-rose-900/30 active:scale-95"
                >
                  <PhoneCall className="w-5 h-5" />
                  <span>{t('btn_emergency_call', 'వెంటనే డాక్టర్‌కు కాల్ చేయండి')}</span>
                </a>

                {onOpenTalkToDoctor && (
                  <button
                    onClick={() => {
                      onClose();
                      onOpenTalkToDoctor();
                    }}
                    className="w-full py-3.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-2xl font-black text-xs flex items-center justify-center gap-2 active:scale-95"
                  >
                    <Video className="w-4 h-4" />
                    <span>{t('btn_send_video_doc', '15 సెకన్ల వీడియో పంపండి')}</span>
                  </button>
                )}

                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-left flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                  <div className="text-[11px] text-amber-900">
                    <span className="font-bold">సమీప పశువైద్యశాల:</span> ఆనంద్ పాలీక్లినిక్ (3.2 km) • డాక్టర్ వి. కే. శర్మ అందుబాటులో ఉన్నారు.
                  </div>
                </div>
              </div>

              <button
                onClick={onClose}
                className="text-xs text-slate-400 hover:text-slate-600 font-bold underline mt-2"
              >
                పూర్తయింది, మూసివేయండి
              </button>
            </div>
          )}

          {isSubmitted && (
            <div className="p-6 text-center space-y-3">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-3xl animate-bounce">
                ✅
              </div>
              <h3 className="text-xl font-black text-emerald-800">
                నివేదిక విజయవంతంగా నమోదు చేయబడింది!
              </h3>
              <p className="text-xs text-slate-500">
                సమాచారం భద్రపరచబడింది. డాక్టర్ పరిశీలిస్తారు.
              </p>
            </div>
          )}
        </div>

        {/* Footer Navigation (Next / Back) */}
        {step < 5 && !isSubmitted && (
          <div className="bg-slate-50 px-5 py-3.5 border-t border-slate-200 flex items-center justify-between shrink-0">
            {step > 1 ? (
              <button
                onClick={() => setStep((step - 1) as any)}
                className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs flex items-center gap-1.5 hover:bg-slate-100"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>వెనుకకు (Back)</span>
              </button>
            ) : (
              <div />
            )}

            {step < 4 ? (
              <button
                onClick={() => setStep((step + 1) as any)}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-700/20 active:scale-95"
              >
                <span>తదుపరి (Next)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : null}
          </div>
        )}
      </div>
    </div>
  );
};
