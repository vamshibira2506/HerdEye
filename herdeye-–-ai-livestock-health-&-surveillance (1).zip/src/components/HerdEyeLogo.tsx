import React from 'react';

interface HerdEyeLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export const HerdEyeLogo: React.FC<HerdEyeLogoProps> = ({
  className = '',
  size = 'md',
  showText = true,
}) => {
  const iconDimensions = {
    sm: { w: 32, h: 32 },
    md: { w: 42, h: 42 },
    lg: { w: 56, h: 56 },
  }[size];

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`} id="herdeye-logo-brand">
      {/* Visual Tech Icon */}
      <div
        style={{ width: iconDimensions.w, height: iconDimensions.h }}
        className="relative flex-shrink-0 bg-emerald-950 rounded-xl p-1.5 shadow-md shadow-emerald-950/20 border border-emerald-800/40 flex items-center justify-center overflow-hidden group"
      >
        <svg
          viewBox="0 0 56 56"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full"
        >
          {/* Outer radar scanning ring */}
          <circle
            cx="28"
            cy="28"
            r="24"
            stroke="#10B981"
            strokeWidth="1.5"
            strokeDasharray="4 3"
            className="animate-[spin_12s_linear_infinite] origin-center opacity-70"
          />
          <circle cx="28" cy="28" r="18" stroke="#38BDF8" strokeWidth="1.2" opacity="0.6" />

          {/* Bovine Horns & Brow */}
          <path
            d="M14 18C10 13 8 12 4 14C3 15 6 19 11 21"
            stroke="#F59E0B"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
          <path
            d="M42 18C46 13 48 12 52 14C53 15 50 19 45 21"
            stroke="#F59E0B"
            strokeWidth="2.2"
            strokeLinecap="round"
          />

          {/* Stylized Eye & Cow Contour */}
          <path
            d="M13 26C17 19 23 18 28 18C33 18 39 19 43 26C45 29 42 39 28 44C14 39 11 29 13 26Z"
            fill="#064E3B"
            stroke="#34D399"
            strokeWidth="1.8"
          />

          {/* AI Pupil & Lens Target */}
          <circle cx="28" cy="30" r="7" fill="#0284C7" />
          <circle cx="28" cy="30" r="3.5" fill="#FFFFFF" />
          <circle cx="29.5" cy="28.5" r="1.5" fill="#38BDF8" />

          {/* Crosshair pulse */}
          <line x1="15" y1="30" x2="41" y2="30" stroke="#38BDF8" strokeWidth="1.2" strokeDasharray="3 2" />
          <circle cx="43" cy="13" r="3" fill="#10B981" className="animate-ping opacity-75" />
          <circle cx="43" cy="13" r="2.5" fill="#10B981" />
        </svg>
      </div>

      {/* Brand Text */}
      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center tracking-tight leading-none font-extrabold text-slate-900">
            <span className="text-xl md:text-2xl text-emerald-900 font-black">Herd</span>
            <span className="text-xl md:text-2xl text-sky-600 font-black">Eye</span>
            <span className="ml-1.5 text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-300/60 px-1.5 py-0.5 rounded">
              AI-VET
            </span>
          </div>
          <span className="text-[9px] md:text-[10px] tracking-wider uppercase font-semibold text-slate-500 mt-0.5">
            Livestock Health Surveillance
          </span>
        </div>
      )}
    </div>
  );
};
