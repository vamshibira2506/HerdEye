import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { Syringe, Plus, Calendar, ShieldCheck, Search, Filter } from 'lucide-react';

interface VaccinationModuleProps {
  onOpenQuickVaccine?: () => void;
}

export const VaccinationModule: React.FC<VaccinationModuleProps> = () => {
  const { animals, addVaccination } = useLivestock();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Done' | 'Due Soon' | 'Overdue'>('All');

  // Flatten all vaccinations with animal reference
  const allVaccinations = animals.flatMap(animal =>
    animal.vaccinationRecords.map(vac => ({
      ...vac,
      animalName: animal.name,
      animalId: animal.id,
      breed: animal.breed,
      owner: animal.ownerName,
    }))
  );

  const filtered = allVaccinations.filter(vac => {
    if (statusFilter !== 'All' && vac.status !== statusFilter) return false;
    if (
      searchTerm &&
      !vac.animalId.toLowerCase().includes(searchTerm.toLowerCase()) &&
      !vac.vaccineName.toLowerCase().includes(searchTerm.toLowerCase()) &&
      !vac.targetDisease.toLowerCase().includes(searchTerm.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  return (
    <div className="space-y-6" id="vaccination-module-root">
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-emerald-100 text-emerald-800 text-[11px] font-bold px-2 py-0.5 rounded uppercase tracking-wider border border-emerald-300">
                NADCP National Immunization Desk
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">
              Livestock Vaccination & Prophylaxis Registry
            </h1>
            <p className="text-xs text-slate-600 mt-0.5">
              Track vaccination batches, cold-chain integrity, upcoming booster schedules, and eradication milestones.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-emerald-50 border border-emerald-200 px-3.5 py-2 rounded-xl text-center">
              <span className="text-[10px] text-emerald-800 font-bold block uppercase">
                Completed Shots
              </span>
              <span className="text-xl font-black text-emerald-700">
                {allVaccinations.filter(v => v.status === 'Done').length}
              </span>
            </div>
            <div className="bg-amber-50 border border-amber-200 px-3.5 py-2 rounded-xl text-center">
              <span className="text-[10px] text-amber-800 font-bold block uppercase">
                Due Soon
              </span>
              <span className="text-xl font-black text-amber-700">
                {allVaccinations.filter(v => v.status === 'Due Soon').length}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by Animal ID, Vaccine, or Disease..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/30"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto">
          {(['All', 'Done', 'Due Soon', 'Overdue'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setStatusFilter(tab)}
              className={`px-3 py-1.5 rounded-lg font-bold transition whitespace-nowrap ${
                statusFilter === tab
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Records Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase text-[10px] font-bold">
                <th className="p-3">Animal ID & Name</th>
                <th className="p-3">Vaccine Name</th>
                <th className="p-3">Target Disease</th>
                <th className="p-3">Batch Number</th>
                <th className="p-3">Administered Date</th>
                <th className="p-3">Next Due Date</th>
                <th className="p-3">Administered By</th>
                <th className="p-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filtered.map(vac => (
                <tr key={vac.id} className="hover:bg-slate-50 transition">
                  <td className="p-3">
                    <span className="font-mono font-bold text-slate-900 block">{vac.animalId}</span>
                    <span className="text-slate-500 text-[11px]">{vac.animalName} ({vac.breed})</span>
                  </td>
                  <td className="p-3 font-semibold text-slate-800">{vac.vaccineName}</td>
                  <td className="p-3 text-slate-700">{vac.targetDisease}</td>
                  <td className="p-3 font-mono text-[11px] text-slate-600">{vac.batchNumber}</td>
                  <td className="p-3 text-slate-600">{vac.administeredDate}</td>
                  <td className="p-3 font-semibold text-slate-800">{vac.nextDueDate}</td>
                  <td className="p-3 text-slate-500 text-[11px]">{vac.administeredBy}</td>
                  <td className="p-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                        vac.status === 'Done'
                          ? 'bg-emerald-100 text-emerald-800'
                          : vac.status === 'Due Soon'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {vac.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
