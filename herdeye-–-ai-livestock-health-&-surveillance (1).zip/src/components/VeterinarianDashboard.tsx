import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { Animal, SymptomReport, TreatmentRecord } from '../types';
import {
  Stethoscope,
  AlertOctagon,
  Clock,
  CheckCircle,
  FileSpreadsheet,
  FlaskConical,
  Calendar,
  Send,
  User,
  MapPin,
  Phone,
  Video,
  Eye,
  Plus,
  ShieldCheck,
  ChevronRight,
  ExternalLink,
  Play,
} from 'lucide-react';
import { EvidenceVideoModal } from './EvidenceVideoModal';

interface VeterinarianDashboardProps {
  onSelectAnimal: (animal: Animal) => void;
}

export const VeterinarianDashboard: React.FC<VeterinarianDashboardProps> = ({
  onSelectAnimal,
}) => {
  const {
    animals,
    symptomReports,
    alerts,
    addVeterinaryTreatment,
    requestLabReferral,
  } = useLivestock();

  // High risk animals and incoming farmer reports
  const highRiskAnimals = animals.filter(
    a => a.healthStatus === 'High Risk / Critical' || a.healthStatus === 'Under Observation'
  );

  const [selectedCaseId, setSelectedCaseId] = useState<string>(
    highRiskAnimals[0]?.id || animals[0]?.id || ''
  );

  const currentAnimal = animals.find(a => a.id === selectedCaseId) || animals[0];
  const relatedReports = symptomReports.filter(r => r.animalId === currentAnimal?.id);
  const relatedAlert = alerts.find(al => al.animalId === currentAnimal?.id);

  // Video modal state for inspecting farmer 15-sec clips
  const [activeVideoModal, setActiveVideoModal] = useState<{
    isOpen: boolean;
    videoUrl?: string;
    duration?: number;
    title?: string;
    reportedBy?: string;
    reporterPhone?: string;
    symptoms?: string[];
  } | null>(null);

  // Form states for clinical action panel
  const [diagnosis, setDiagnosis] = useState('');
  const [medications, setMedications] = useState('');
  const [adviceNotes, setAdviceNotes] = useState('');
  const [followUpDate, setFollowUpDate] = useState('');

  // Lab order form states
  const [showLabModal, setShowLabModal] = useState(false);
  const [labSampleType, setLabSampleType] = useState<'Blood' | 'Milk' | 'Nasal Swab' | 'Skin Scraping'>('Blood');
  const [labTestName, setLabTestName] = useState('Multiplex RT-PCR & Antigen Typing');
  const [labUrgency, setLabUrgency] = useState<'Routine' | 'Urgent' | 'Emergency'>('Emergency');
  const [labTarget, setLabTarget] = useState('State Animal Disease Diagnostic Laboratory');

  // Case filter
  const [filterSeverity, setFilterSeverity] = useState<'all' | 'critical' | 'observation'>('all');

  const displayedAnimals = highRiskAnimals.filter(a => {
    if (filterSeverity === 'critical') return a.healthStatus === 'High Risk / Critical';
    if (filterSeverity === 'observation') return a.healthStatus === 'Under Observation';
    return true;
  });

  const handleSaveTreatment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentAnimal || !diagnosis.trim()) return;

    addVeterinaryTreatment(currentAnimal.id, {
      date: new Date().toISOString().split('T')[0],
      diagnosis: diagnosis.trim(),
      veterinarianName: 'Dr. V. K. Sharma (MVSc Medicine)',
      clinic: 'Sub-Divisional Veterinary Polyclinic & Hospital',
      medications: medications.trim() || 'Symptomatic supportive therapy advised.',
      notes: adviceNotes.trim() || 'Patient kept under continuous remote AI observation.',
      followUpDate: followUpDate || undefined,
      status: 'Active',
    });

    // Reset fields
    setDiagnosis('');
    setMedications('');
    setAdviceNotes('');
    setFollowUpDate('');
  };

  const handleDispatchLabSample = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentAnimal) return;

    requestLabReferral(currentAnimal.id, {
      sampleId: `SMP-${currentAnimal.location.state.slice(0, 2).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`,
      sampleType: labSampleType,
      testRequested: labTestName,
      requestedDate: new Date().toISOString().split('T')[0],
      requestedBy: 'Dr. V. K. Sharma (Veterinary Officer)',
      labName: labTarget,
      status: 'In Analysis',
      urgency: labUrgency,
    });

    setShowLabModal(false);
  };

  return (
    <div className="space-y-6" id="veterinarian-dashboard-root">
      {/* Top Header Strip */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-sky-100 text-sky-800 text-[11px] font-bold px-2 py-0.5 rounded uppercase tracking-wider border border-sky-300">
                Veterinary Clinical Hub
              </span>
              <span className="text-slate-500 text-xs">
                Sub-Divisional Veterinary Polyclinic & Referral Hospital
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">
              Clinical Triage, Diagnostics & Referral Desk
            </h1>
            <p className="text-xs text-slate-600 mt-0.5">
              Review real-time farmer reports, AI syndromic early warnings, write official prescriptions, and order confirmatory laboratory diagnostics.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-rose-50 border border-rose-200 px-3.5 py-2 rounded-xl text-center">
              <span className="text-[10px] text-rose-700 font-bold block uppercase">
                Critical Triage Cases
              </span>
              <span className="text-xl font-black text-rose-700 leading-tight">
                {animals.filter(a => a.healthStatus === 'High Risk / Critical').length}
              </span>
            </div>
            <div className="bg-sky-50 border border-sky-200 px-3.5 py-2 rounded-xl text-center">
              <span className="text-[10px] text-sky-700 font-bold block uppercase">
                Under Observation
              </span>
              <span className="text-xl font-black text-sky-700 leading-tight">
                {animals.filter(a => a.healthStatus === 'Under Observation').length}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Incoming Cases Queue (5 cols) */}
        <div className="lg:col-span-5 flex flex-col gap-3">
          <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Stethoscope className="w-4 h-4 text-sky-700" />
                <h2 className="text-sm font-bold text-slate-900">Active Case Queue</h2>
              </div>
              <div className="flex gap-1 text-xs">
                <button
                  onClick={() => setFilterSeverity('all')}
                  className={`px-2 py-0.5 rounded text-[11px] font-semibold transition ${
                    filterSeverity === 'all' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  All ({highRiskAnimals.length})
                </button>
                <button
                  onClick={() => setFilterSeverity('critical')}
                  className={`px-2 py-0.5 rounded text-[11px] font-semibold transition ${
                    filterSeverity === 'critical' ? 'bg-rose-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  Critical
                </button>
              </div>
            </div>

            <div className="space-y-2.5 max-h-[680px] overflow-y-auto pr-1">
              {displayedAnimals.map(animal => {
                const isSelected = animal.id === currentAnimal?.id;
                return (
                  <div
                    key={animal.id}
                    onClick={() => setSelectedCaseId(animal.id)}
                    className={`p-3.5 rounded-xl border cursor-pointer transition ${
                      isSelected
                        ? 'border-sky-600 bg-sky-50/70 shadow-xs ring-2 ring-sky-600/20'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-bold text-slate-900">
                            {animal.id}
                          </span>
                          <span
                            className={`text-[9px] font-black uppercase px-1.5 py-0.2 rounded ${
                              animal.healthStatus === 'High Risk / Critical'
                                ? 'bg-rose-600 text-white'
                                : 'bg-amber-600 text-white'
                            }`}
                          >
                            {animal.riskPriority} Risk
                          </span>
                        </div>
                        <h4 className="text-xs font-extrabold text-slate-900 mt-0.5">
                          {animal.name}
                        </h4>
                        <p className="text-[11px] text-slate-500">
                          {animal.location.village}, {animal.location.district} ({animal.location.state})
                        </p>
                      </div>

                      <span className="text-xs font-extrabold font-mono text-rose-600 bg-rose-50 px-2 py-1 rounded border border-rose-200">
                        {animal.bodyTemperatureC}°C
                      </span>
                    </div>

                    {/* Symptoms preview */}
                    <div className="mt-2 flex flex-wrap gap-1">
                      {animal.currentSymptoms.slice(0, 2).map((s, idx) => (
                        <span
                          key={idx}
                          className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded truncate max-w-[170px]"
                        >
                          {s}
                        </span>
                      ))}
                    </div>

                    <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                      <div className="flex items-center gap-1.5">
                        <span>Owner: {animal.ownerName}</span>
                        {(symptomReports.some(r => r.animalId === animal.id && (r.videoUrl || animal.id === 'IN-GJ-2024-9182'))) && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-700 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">
                            <Video className="w-3 h-3 text-rose-600" />
                            <span>15s Video</span>
                          </span>
                        )}
                      </div>
                      <span className="font-bold text-sky-700 flex items-center gap-0.5">
                        Select Case <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Case Review & Clinical Action Console (7 cols) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          {currentAnimal ? (
            <>
              {/* Active Case Summary Card */}
              <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-4 border-b border-slate-200">
                  <div className="flex gap-3">
                    <img
                      src={currentAnimal.photoUrl}
                      alt={currentAnimal.name}
                      referrerPolicy="no-referrer"
                      className="w-16 h-16 rounded-xl object-cover border border-slate-200 shrink-0"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold bg-slate-100 px-2 py-0.5 rounded text-slate-800 border border-slate-200">
                          {currentAnimal.id}
                        </span>
                        <span className="text-xs font-semibold text-slate-500">
                          {currentAnimal.species} • {currentAnimal.breed}
                        </span>
                      </div>
                      <h2 className="text-lg font-black text-slate-900 mt-0.5">
                        {currentAnimal.name}
                      </h2>
                      <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                        <span className="flex items-center gap-1">
                          <User className="w-3.5 h-3.5 text-slate-400" />
                          {currentAnimal.ownerName}
                        </span>
                        <span className="flex items-center gap-1">
                          <Phone className="w-3.5 h-3.5 text-slate-400" />
                          {currentAnimal.ownerContact}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex sm:flex-col items-end gap-1.5 shrink-0">
                    <button
                      onClick={() => onSelectAnimal(currentAnimal)}
                      className="text-xs font-bold text-emerald-800 hover:text-emerald-950 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200 flex items-center gap-1"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Full Health Profile</span>
                    </button>
                    <span className="text-[10px] text-slate-400">
                      Shed: {currentAnimal.shedNumber}
                    </span>
                  </div>
                </div>

                {/* Clinical Vitals & Evidence Bar */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 my-3.5 text-xs">
                  <div className="bg-slate-50 p-2 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 block font-semibold uppercase">Body Temp</span>
                    <span className={`font-black text-sm ${currentAnimal.bodyTemperatureC > 39.5 ? 'text-rose-600' : 'text-slate-900'}`}>
                      {currentAnimal.bodyTemperatureC} °C
                    </span>
                  </div>
                  <div className="bg-slate-50 p-2 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 block font-semibold uppercase">Rumination</span>
                    <span className="font-black text-sm text-slate-900">
                      {currentAnimal.ruminationMinutesPerDay} min/d
                    </span>
                  </div>
                  <div className="bg-slate-50 p-2 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 block font-semibold uppercase">Feed Intake</span>
                    <span className="font-black text-sm text-slate-900">
                      {currentAnimal.feedIntakeKg} kg
                    </span>
                  </div>
                  <div className="bg-slate-50 p-2 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 block font-semibold uppercase">AI Risk Score</span>
                    <span className="font-black text-sm text-rose-600">
                      {currentAnimal.riskScore}/100
                    </span>
                  </div>
                </div>

                {/* Farmer 15-Second Clinical Evidence Video Card */}
                {(() => {
                  const reportWithVideo = relatedReports.find(r => r.videoUrl) || (currentAnimal.id === 'IN-GJ-2024-9182' ? {
                    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
                    videoDurationSeconds: 14,
                    videoTitle: 'Excessive mouth froth & salivation evidence clip (14s)',
                    reportedBy: 'Ramesh Patel (Farmer)',
                    reporterPhone: '+91 98251 44102',
                    symptoms: currentAnimal.currentSymptoms,
                  } : null);

                  if (!reportWithVideo || !reportWithVideo.videoUrl) return null;

                  return (
                    <div className="bg-slate-900 text-white rounded-xl p-3.5 mb-3 border border-slate-700 shadow-md">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="bg-rose-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded-full flex items-center gap-1 shadow-xs">
                            <Video className="w-3 h-3" />
                            <span>Farmer 15s Evidence Clip</span>
                          </span>
                          <span className="text-[11px] font-mono text-emerald-400 font-bold">
                            {reportWithVideo.videoDurationSeconds || 14}s Video
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400">
                          From {reportWithVideo.reportedBy || currentAnimal.ownerName}
                        </span>
                      </div>

                      <div className="flex flex-col sm:flex-row items-center gap-3">
                        <div
                          className="relative aspect-video w-full sm:w-44 max-h-24 rounded-lg overflow-hidden bg-black border border-slate-700 shrink-0 group cursor-pointer"
                          onClick={() =>
                            setActiveVideoModal({
                              isOpen: true,
                              videoUrl: reportWithVideo.videoUrl,
                              duration: reportWithVideo.videoDurationSeconds || 14,
                              title: reportWithVideo.videoTitle || '15s Clinical Evidence Video',
                              reportedBy: reportWithVideo.reportedBy || currentAnimal.ownerName,
                              reporterPhone: reportWithVideo.reporterPhone || currentAnimal.ownerContact,
                              symptoms: reportWithVideo.symptoms || currentAnimal.currentSymptoms,
                            })
                          }
                        >
                          <video
                            src={reportWithVideo.videoUrl}
                            muted
                            playsInline
                            loop
                            className="w-full h-full object-cover group-hover:scale-105 transition"
                          />
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/20 transition">
                            <div className="w-8 h-8 rounded-full bg-rose-600 text-white flex items-center justify-center shadow-md">
                              <Play className="w-3.5 h-3.5 ml-0.5" />
                            </div>
                          </div>
                          <span className="absolute bottom-1 right-1 bg-black/80 text-[9px] font-mono text-white px-1.5 py-0.2 rounded">
                            {reportWithVideo.videoDurationSeconds || 14}s
                          </span>
                        </div>

                        <div className="flex-1 space-y-1 text-xs">
                          <div className="font-bold text-white text-xs">
                            {reportWithVideo.videoTitle || 'Farmer Specimen Video Upload'}
                          </div>
                          <p className="text-[11px] text-slate-300 leading-snug">
                            Veterinarian slow-motion review enables detection of vesicular lesions, saliva strings & lameness.
                          </p>
                          <div className="flex items-center gap-2 pt-1">
                            <button
                              type="button"
                              onClick={() =>
                                setActiveVideoModal({
                                  isOpen: true,
                                  videoUrl: reportWithVideo.videoUrl,
                                  duration: reportWithVideo.videoDurationSeconds || 14,
                                  title: reportWithVideo.videoTitle || '15s Clinical Evidence Video',
                                  reportedBy: reportWithVideo.reportedBy || currentAnimal.ownerName,
                                  reporterPhone: reportWithVideo.reporterPhone || currentAnimal.ownerContact,
                                  symptoms: reportWithVideo.symptoms || currentAnimal.currentSymptoms,
                                })
                              }
                              className="px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
                            >
                              <Play className="w-3 h-3" />
                              <span>Play in Tele-Diagnostic View (0.5x Slow-Mo)</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {/* Farmer & Field Evidence Reports */}
                {relatedReports.length > 0 && (
                  <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-3.5 mb-3">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-900 block mb-1">
                      Field / Farmer Reported Symptoms & Notes:
                    </span>
                    {relatedReports.map(rep => (
                      <div key={rep.id} className="text-xs text-amber-950 space-y-1">
                        <div className="flex items-center justify-between text-[11px] text-amber-800">
                          <span>Reported by: {rep.reportedBy}</span>
                          <span>{rep.timestamp}</span>
                        </div>
                        <p className="italic bg-white/60 p-2 rounded border border-amber-200/80">
                          "{rep.notes}"
                        </p>
                      </div>
                    ))}
                  </div>
                )}

                {/* AI Automated Syndromic Assessment */}
                {relatedAlert && (
                  <div className="bg-sky-50/80 border border-sky-200 rounded-xl p-3 text-xs text-sky-950 flex items-start gap-2.5">
                    <AlertOctagon className="w-4 h-4 text-sky-700 shrink-0 mt-0.5" />
                    <div>
                      <div className="flex items-center gap-1.5 font-bold">
                        <span>AI Warning: {relatedAlert.suspectedDisease}</span>
                        <span className="text-[10px] bg-sky-200 px-1.5 rounded text-sky-800">
                          {relatedAlert.confidenceScore}% Confidence
                        </span>
                      </div>
                      <p className="text-[11px] text-sky-800 mt-0.5">
                        {relatedAlert.aiObservations}
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Clinical Action Form: Diagnosis, Rx Prescription, Advice */}
              <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                    <Stethoscope className="w-4 h-4 text-emerald-700" />
                    <span>Clinical Diagnosis & Prescription Entry</span>
                  </h3>

                  <button
                    type="button"
                    onClick={() => setShowLabModal(true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 rounded-lg text-xs font-bold transition"
                  >
                    <FlaskConical className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Order Lab Sample Test</span>
                  </button>
                </div>

                <form onSubmit={handleSaveTreatment} className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Definitive / Tentative Clinical Diagnosis *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Acute Bovine Vesicular Stomatitis / Foot & Mouth Disease (FMD) Serotype O"
                      value={diagnosis}
                      onChange={e => setDiagnosis(e.target.value)}
                      className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Medication Regimen & Dosages (Rx)
                    </label>
                    <textarea
                      rows={2}
                      placeholder="e.g. Inj. Flunixin Meglumine 15ml IM OD x 3 days; Boroglycerine mouth application TDS; Antiseptic foot bath with 2% Copper Sulfate"
                      value={medications}
                      onChange={e => setMedications(e.target.value)}
                      className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Veterinary Advice & Quarantine Instructions
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Strict quarantine in shed; boil all milk before usage"
                        value={adviceNotes}
                        onChange={e => setAdviceNotes(e.target.value)}
                        className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Schedule Follow-up Date
                      </label>
                      <input
                        type="date"
                        value={followUpDate}
                        onChange={e => setFollowUpDate(e.target.value)}
                        className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                      />
                    </div>
                  </div>

                  <div className="pt-2 flex items-center justify-between">
                    <span className="text-[11px] text-slate-400">
                      Sign-off: Dr. V. K. Sharma (Reg. No: VCI-GJ-2012-4019)
                    </span>
                    <button
                      type="submit"
                      className="flex items-center gap-1.5 px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-bold shadow-xs transition"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Submit Clinical Prescription</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* Past Treatment Log on this Animal */}
              {currentAnimal.treatmentHistory.length > 0 && (
                <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                    Previous Clinical Notes & History
                  </h4>
                  <div className="space-y-2 text-xs">
                    {currentAnimal.treatmentHistory.map(trt => (
                      <div key={trt.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                        <div className="flex justify-between items-center text-[11px] text-slate-500 mb-1">
                          <span className="font-bold text-slate-800">{trt.date}</span>
                          <span>{trt.veterinarianName}</span>
                        </div>
                        <div className="font-semibold text-slate-900">{trt.diagnosis}</div>
                        <p className="text-slate-600 text-[11px] mt-1">Rx: {trt.medications}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="bg-white p-12 text-center rounded-xl border border-slate-200 text-slate-500 text-xs">
              Select a case from the queue to review and prescribe treatment.
            </div>
          )}
        </div>
      </div>

      {/* Lab Order Modal */}
      {showLabModal && currentAnimal && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
              <div className="flex items-center gap-2">
                <FlaskConical className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-extrabold text-slate-900">
                  Request Laboratory Diagnostic Sample Referral
                </h3>
              </div>
              <button
                onClick={() => setShowLabModal(false)}
                className="text-slate-400 hover:text-slate-700 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleDispatchLabSample} className="space-y-3.5 text-xs">
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                <span className="text-slate-500 block">Animal Target:</span>
                <span className="font-bold text-slate-900">
                  {currentAnimal.name} ({currentAnimal.id}) • {currentAnimal.breed}
                </span>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Sample Specimen Type *</label>
                <select
                  value={labSampleType}
                  onChange={e => setLabSampleType(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800"
                >
                  <option value="Blood">Blood (EDTA / Serum for Serology)</option>
                  <option value="Nasal Swab">Nasal / Mucosal Swab (Viral Transport Media)</option>
                  <option value="Milk">Foremilk (California Mastitis / SCC)</option>
                  <option value="Skin Scraping">Skin Scraping / Scab (Poxvirus / Parasitic)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Diagnostic Test Requested *</label>
                <input
                  type="text"
                  required
                  value={labTestName}
                  onChange={e => setLabTestName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Urgency Level</label>
                  <select
                    value={labUrgency}
                    onChange={e => setLabUrgency(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800"
                  >
                    <option value="Emergency">Emergency (Immediate Courier)</option>
                    <option value="Urgent">Urgent (24h turnaround)</option>
                    <option value="Routine">Routine Batch Surveillance</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Destination Laboratory</label>
                  <select
                    value={labTarget}
                    onChange={e => setLabTarget(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800"
                  >
                    <option value="State Animal Disease Diagnostic Laboratory (Patan/Anand)">
                      State Animal Disease Diagnostic Lab (Anand)
                    </option>
                    <option value="National Institute of High Security Animal Diseases (NIHSAD, Bhopal)">
                      NIHSAD (Bhopal)
                    </option>
                    <option value="Indian Veterinary Research Institute (IVRI, Bareilly)">
                      IVRI (Bareilly)
                    </option>
                    <option value="AMUL Central Quality Diagnostic Laboratory">
                      AMUL Central Milk Lab
                    </option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowLabModal(false)}
                  className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-700 hover:bg-indigo-600 text-white rounded-lg font-bold shadow-xs flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Dispatch Sample Order</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* 15-Second Evidence Video Player Modal for Veterinarian */}
      {activeVideoModal && (
        <EvidenceVideoModal
          isOpen={activeVideoModal.isOpen}
          onClose={() => setActiveVideoModal(null)}
          videoUrl={activeVideoModal.videoUrl}
          videoDurationSeconds={activeVideoModal.duration}
          videoTitle={activeVideoModal.title}
          reportedBy={activeVideoModal.reportedBy}
          reporterPhone={activeVideoModal.reporterPhone}
          animalId={currentAnimal?.id}
          animalName={currentAnimal?.name}
          symptoms={activeVideoModal.symptoms}
          location={`${currentAnimal?.location.village}, ${currentAnimal?.location.district} (${currentAnimal?.location.state})`}
          onActionPrescribe={() => {
            setDiagnosis(
              `Syndromic vesicular/lameness observation confirmed via 15s evidence clip: ${currentAnimal?.currentSymptoms[0] || 'Vesicular oral lesion'}`
            );
            setMedications(
              'Boric acid glycerin oral rinse TID, Meloxicam 0.5 mg/kg IM, Antiseptic potassium permanganate hoof wash.'
            );
          }}
        />
      )}
    </div>
  );
};
