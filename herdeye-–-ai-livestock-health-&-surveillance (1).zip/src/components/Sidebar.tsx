import React from 'react';
import { useLivestock, ActiveTab } from '../context/LivestockContext';
import {
  LayoutDashboard,
  Video,
  FileHeart,
  AlertTriangle,
  Stethoscope,
  Syringe,
  FlaskConical,
  Skull,
  MapPin,
  FileBarChart,
  CloudOff,
  PlusCircle,
  ShieldCheck,
  Activity,
} from 'lucide-react';

interface SidebarProps {
  onOpenRegisterModal: () => void;
  onOpenReportModal: () => void;
  isOpenMobile: boolean;
  setIsOpenMobile: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  onOpenRegisterModal,
  onOpenReportModal,
  isOpenMobile,
  setIsOpenMobile,
}) => {
  const { role, activeTab, setActiveTab, alerts, offlineQueue } = useLivestock();

  const newAlertsCount = alerts.filter(a => a.status === 'New').length;
  const offlineCount = offlineQueue.length;

  const navItems: Array<{
    id: ActiveTab;
    label: string;
    icon: React.ElementType;
    badge?: number;
    badgeColor?: string;
    roles?: string[];
  }> = [
    {
      id: 'dashboard',
      label: `${role === 'farmer' ? 'Farmer' : role === 'field_worker' ? 'Field Worker' : role === 'veterinarian' ? 'Veterinarian' : 'Government'} Hub`,
      icon: LayoutDashboard,
    },
    {
      id: 'ai-monitoring',
      label: 'AI Surveillance & CCTV',
      icon: Video,
      badge: 3, // 3 live barn cameras
      badgeColor: 'bg-emerald-600 text-white',
    },
    {
      id: 'animals',
      label: 'Livestock Health Records',
      icon: FileHeart,
    },
    {
      id: 'reporting',
      label: 'Symptom & Case Reports',
      icon: AlertTriangle,
    },
    {
      id: 'veterinary-cases',
      label: 'Veterinary Clinical Desk',
      icon: Stethoscope,
      badge: role === 'veterinarian' ? 2 : undefined,
      badgeColor: 'bg-sky-600 text-white',
    },
    {
      id: 'vaccination',
      label: 'Vaccination Schedules',
      icon: Syringe,
    },
    {
      id: 'lab-referrals',
      label: 'Laboratory Referrals',
      icon: FlaskConical,
    },
    {
      id: 'mortality',
      label: 'Mortality & Bio-Disposal',
      icon: Skull,
    },
    {
      id: 'alerts',
      label: 'Risk Alerts & Triage',
      icon: Activity,
      badge: newAlertsCount > 0 ? newAlertsCount : undefined,
      badgeColor: 'bg-rose-600 text-white',
    },
    {
      id: 'geospatial',
      label: 'Geospatial Surveillance',
      icon: MapPin,
    },
    {
      id: 'reports',
      label: 'Epidemiological Reports',
      icon: FileBarChart,
    },
    {
      id: 'offline-outbox',
      label: 'Offline Sync Outbox',
      icon: CloudOff,
      badge: offlineCount > 0 ? offlineCount : undefined,
      badgeColor: 'bg-amber-600 text-white',
    },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 bg-slate-900/50 z-30 lg:hidden backdrop-blur-xs"
          onClick={() => setIsOpenMobile(false)}
        />
      )}

      <aside
        id="herdeye-main-sidebar"
        className={`fixed lg:sticky top-0 lg:top-[85px] left-0 h-screen lg:h-[calc(100vh-85px)] w-64 bg-slate-900 text-slate-200 border-r border-slate-800 flex flex-col z-30 transition-transform duration-300 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Quick Actions Header */}
        <div className="p-3.5 border-b border-slate-800/80 bg-slate-950/40">
          <div className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold mb-2 flex items-center justify-between">
            <span>Direct Field Actions</span>
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                onOpenRegisterModal();
                setIsOpenMobile(false);
              }}
              className="flex items-center justify-center gap-1.5 py-1.5 px-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-semibold shadow-xs transition"
              id="sidebar-quick-register-btn"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Register</span>
            </button>
            <button
              onClick={() => {
                onOpenReportModal();
                setIsOpenMobile(false);
              }}
              className="flex items-center justify-center gap-1.5 py-1.5 px-2 bg-sky-700 hover:bg-sky-600 text-white rounded-lg text-xs font-semibold shadow-xs transition"
              id="sidebar-quick-report-btn"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Report</span>
            </button>
          </div>
        </div>

        {/* Navigation List */}
        <nav className="flex-1 overflow-y-auto px-2 py-3 space-y-1">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsOpenMobile(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition group ${
                  isActive
                    ? 'bg-emerald-800/80 text-white font-bold shadow-xs border-l-4 border-emerald-400'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
                id={`nav-${item.id}`}
              >
                <div className="flex items-center gap-3 truncate">
                  <Icon
                    className={`w-4 h-4 shrink-0 transition ${
                      isActive ? 'text-emerald-300' : 'text-slate-400 group-hover:text-emerald-400'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                </div>

                {item.badge !== undefined && (
                  <span
                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${
                      item.badgeColor || 'bg-slate-700 text-white'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Footer info in sidebar */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/70 text-[11px] text-slate-400 flex flex-col gap-1">
          <div className="flex items-center justify-between">
            <span className="font-medium text-slate-300">NDLM / NADCP Synced</span>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          </div>
          <p className="text-[10px] text-slate-500">
            India Livestock Health & Disease Control Programme (LHDCP)
          </p>
        </div>
      </aside>
    </>
  );
};
