import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import {
  BookOpen,
  Volume2,
  X,
  Sparkles,
  ShieldCheck,
  Video,
  CheckCircle2,
  Droplets,
  HeartPulse,
  Home,
  AlertCircle,
  PhoneCall,
} from 'lucide-react';

interface FarmerEducationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenTalkToDoctor?: () => void;
}

export const FarmerEducationModal: React.FC<FarmerEducationModalProps> = ({
  isOpen,
  onClose,
  onOpenTalkToDoctor,
}) => {
  const { t, speakText } = useLanguage();
  const [selectedTopic, setSelectedTopic] = useState<number | null>(0);

  if (!isOpen) return null;

  const topics = [
    {
      id: 0,
      title: t('edu_topic_1', 'అనారోగ్య పశువును ఎలా గుర్తించాలి?'),
      desc: t('edu_desc_1', 'మేత సరిగా తినకపోవడం, నెమరు వేయడం ఆగిపోవడం, చెవులు క్రిందికి వాల్చడం, ముక్కు పొడిగా ఉండటం గమనించాలి.'),
      icon: '🐄',
      image: 'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=600&q=80',
      tips: [
        'రోజుకు పశువు 7-8 గంటలు నెమరు వేయాలి. ఆగిపోతే కడుపు ఉబ్బరం లేదా జ్వరం ఉండవచ్చు.',
        'కళ్లలో నీరు కారడం, ముక్కు పొడిగా మారడం ప్రాథమిక అనారోగ్య సూచికలు.',
        'పాలు హఠాత్తుగా తగ్గితే వెంటనే ఉష్ణోగ్రత తనిఖీ చేయాలి.',
      ],
    },
    {
      id: 1,
      title: t('edu_topic_2', 'సకాలంలో టీకాలు వేయించడం ఎందుకు ముఖ్యం?'),
      desc: t('edu_desc_2', 'గాలికుంటు (FMD), ముద్ద చర్మ వ్యాధి (Lumpy Skin) వంటి ప్రాణాంతక వ్యాధుల నుండి టీకాలు పశువులను కాపాడతాయి.'),
      icon: '💉',
      image: 'https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?auto=format&fit=crop&w=600&q=80',
      tips: [
        'ప్రభుత్వం ఉచితంగా నిర్వహించే ఎఫ్.ఎమ్.డి (FMD) టీకా డ్రైవ్‌లో తప్పక పాల్గొనండి.',
        'గర్భధారణ సమయంలో వైద్యుల సలహా మేరకు మాత్రమే టీకాలు వేయించాలి.',
        'టీకా వేసిన తర్వాత పశువుకు 1-2 రోజులు విశ్రాంతి ఇవ్వాలి.',
      ],
    },
    {
      id: 2,
      title: t('edu_topic_3', 'పరిశుభ్రమైన తాగునీరు & పాక నిర్వహణ'),
      desc: t('edu_desc_3', 'ప్రతిరోజూ స్వచ్ఛమైన నీరు అందించాలి. పేడ మరియు మూత్రం ఎప్పటికప్పుడు తొలగించి పాకను పొడిగా ఉంచాలి.'),
      icon: '💧',
      image: 'https://images.unsplash.com/photo-1596733430284-f7437764b1a9?auto=format&fit=crop&w=600&q=80',
      tips: [
        'ఒక పాడి పశువుకు రోజుకు 50-70 లీటర్ల శుభ్రమైన చల్లని తాగునీరు అవసరం.',
        'పాకలో నిలిచిన నీటిని తీసివేసి నిమ్మకాయ రసం లేదా సున్నం చల్లి ఈగలు, దోమలను అరికట్టండి.',
        'బాగా గాలి మరియు వెలుతురు ఉండేలా పాకను నిర్మించాలి.',
      ],
    },
    {
      id: 3,
      title: t('edu_topic_4', '15 సెకన్ల మంచి వీడియో ఎలా తీయాలి?'),
      desc: t('edu_desc_4', 'వెలుతురు ఉన్న చోట పశువు ముఖం, కాలు నడక లేదా సమస్య ఉన్న భాగాన్ని స్పష్టంగా 15 సెకన్లు రికార్డ్ చేయాలి.'),
      icon: '📹',
      image: 'https://images.unsplash.com/photo-1527153857715-3908f2ae5e81?auto=format&fit=crop&w=600&q=80',
      tips: [
        'కెమెరాను కదపకుండా స్థిరంగా పట్టుకోండి.',
        'పశువు నడుస్తున్నప్పుడు 5 అడుగుల దూరం నుండి పాదాలు కనిపించేలా తీయండి.',
        'నోట్లో లాలాజలం లేదా బొబ్బలు ఉంటే దగ్గరగా ఫోకస్ చేయండి.',
      ],
    },
  ];

  const current = topics[selectedTopic ?? 0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/75 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border-4 border-amber-500 overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-600 via-amber-700 to-emerald-800 p-5 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-2xl shadow-inner">
              📖
            </div>
            <div>
              <h3 className="font-extrabold text-lg sm:text-xl tracking-tight leading-tight">
                {t('menu_learn', 'రైతు పాఠాలు / విద్య (Farmer Education)')}
              </h3>
              <p className="text-amber-100 text-xs font-semibold">
                పశు సంరక్షణ పద్ధతులు • వ్యాధి నివారణ చిట్కాలు
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => speakText(`${current.title}. ${current.desc}`)}
              className="p-2 rounded-xl bg-white/20 hover:bg-white/30 text-white transition flex items-center gap-1 text-xs font-bold"
              title="Listen"
            >
              <Volume2 className="w-4 h-4" />
              <span className="hidden sm:inline">{t('voice_listen', 'వినండి')}</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-black/20 hover:bg-black/30 text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Topic Selector Chips */}
        <div className="bg-amber-50/70 p-3 border-b border-amber-200 flex items-center gap-2 overflow-x-auto shrink-0">
          {topics.map(tItem => (
            <button
              key={tItem.id}
              onClick={() => setSelectedTopic(tItem.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-black transition shrink-0 flex items-center gap-2 ${
                selectedTopic === tItem.id
                  ? 'bg-amber-700 text-white shadow-xs'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-amber-100'
              }`}
            >
              <span>{tItem.icon}</span>
              <span>{tItem.title.split('?')[0].slice(0, 18)}...</span>
            </button>
          ))}
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4">
          <div className="relative rounded-2xl overflow-hidden aspect-video max-h-48 border border-slate-200 shadow-xs">
            <img
              src={current.image}
              alt={current.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-4 text-white">
              <h4 className="text-base sm:text-lg font-black">{current.title}</h4>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-slate-700 font-bold leading-relaxed bg-amber-50/60 p-3.5 rounded-2xl border border-amber-200">
            {current.desc}
          </p>

          <div className="space-y-2">
            <h5 className="text-xs font-black uppercase tracking-wider text-slate-500">
              ముఖ్యమైన సూచనలు (Key Farmer Tips):
            </h5>
            <div className="space-y-2">
              {current.tips.map((tip, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 font-semibold"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{tip}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs shrink-0">
          <span className="text-slate-500 font-medium">
            హెల్ప్‌లైన్: 1962 (24x7 ఉచిత సేవ)
          </span>
          <button
            onClick={onClose}
            className="text-slate-800 font-bold hover:underline"
          >
            పూర్తయింది (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
