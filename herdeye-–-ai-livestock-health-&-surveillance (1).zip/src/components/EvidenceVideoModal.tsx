import React, { useState, useRef } from 'react';
import {
  X,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  FastForward,
  Clock,
  User,
  Phone,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  FileSpreadsheet,
  Stethoscope,
  Maximize2,
  ZoomIn,
} from 'lucide-react';

interface EvidenceVideoModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoUrl?: string;
  videoDurationSeconds?: number;
  videoTitle?: string;
  reportedBy?: string;
  reporterPhone?: string;
  animalId?: string;
  animalName?: string;
  symptoms?: string[];
  location?: string;
  timestamp?: string;
  onActionPrescribe?: () => void;
}

export const EvidenceVideoModal: React.FC<EvidenceVideoModalProps> = ({
  isOpen,
  onClose,
  videoUrl,
  videoDurationSeconds = 14,
  videoTitle = 'Farmer 15-Second Clinical Evidence Video',
  reportedBy = 'Ramesh Patel (Farmer)',
  reporterPhone = '+91 98251 44102',
  animalId = 'IN-GJ-2024-9182',
  animalName = 'Gauri (Murrah Buffalo)',
  symptoms = ['High fever', 'Stringy saliva dripping', 'Reluctance to stand'],
  location = 'Mogri, Anand (Gujarat)',
  timestamp = 'Just now',
  onActionPrescribe,
}) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(videoDurationSeconds);

  const videoRef = useRef<HTMLVideoElement | null>(null);

  if (!isOpen || !videoUrl) return null;

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const handleSpeedChange = (speed: number) => {
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
      setPlaybackSpeed(speed);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
      if (videoRef.current.duration) {
        setDuration(Math.round(videoRef.current.duration));
      }
    }
  };

  const handleRestart = () => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 z-50 flex items-center justify-center p-3 sm:p-5 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-slate-900 text-white rounded-2xl max-w-3xl w-full flex flex-col shadow-2xl border border-slate-700 overflow-hidden my-auto">
        {/* Header Strip */}
        <div className="p-4 bg-slate-800 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full">
              Field Tele-Consult Clip (≤15s)
            </span>
            <div>
              <h3 className="text-sm sm:text-base font-extrabold text-white">
                Veterinary Tele-Diagnostic Video Player
              </h3>
              <p className="text-[11px] text-slate-400">
                Patient: <span className="font-mono text-emerald-400">{animalId}</span> — {animalName}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Main Video Viewport */}
        <div className="relative aspect-video max-h-96 w-full bg-black flex items-center justify-center group">
          <video
            ref={videoRef}
            src={videoUrl}
            autoPlay
            playsInline
            loop
            muted={isMuted}
            onTimeUpdate={handleTimeUpdate}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            className="w-full h-full object-contain"
          />

          {/* Top Overlays */}
          <div className="absolute top-3 left-3 flex items-center gap-2">
            <div className="bg-black/75 backdrop-blur-xs text-white text-xs font-mono px-2.5 py-1 rounded-lg border border-white/20 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-rose-400" />
              <span>
                {Math.floor(currentTime)}s / {duration}s
              </span>
            </div>
            {playbackSpeed !== 1.0 && (
              <span className="bg-amber-500/90 text-black text-[10px] font-black px-2 py-0.5 rounded uppercase">
                Diagnostic {playbackSpeed}x Slow-Motion
              </span>
            )}
          </div>

          {/* Bottom Custom Playbar */}
          <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-3 pt-6 flex flex-col gap-2">
            {/* Scrubber track */}
            <div className="w-full bg-slate-700/80 h-1.5 rounded-full overflow-hidden cursor-pointer">
              <div
                className="bg-rose-500 h-full transition-all duration-100"
                style={{ width: `${(currentTime / (duration || 1)) * 100}%` }}
              />
            </div>

            {/* Controls Bar */}
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={togglePlay}
                  className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition"
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                </button>

                <button
                  type="button"
                  onClick={handleRestart}
                  className="p-1.5 text-slate-300 hover:text-white transition"
                  title="Replay Clip"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>

                {/* Slow Motion (0.5x) for lameness and oral lesion inspection */}
                <div className="flex items-center bg-slate-800 rounded-lg p-0.5 border border-slate-700 text-[10px]">
                  <button
                    type="button"
                    onClick={() => handleSpeedChange(0.5)}
                    className={`px-2 py-0.5 rounded font-bold transition ${
                      playbackSpeed === 0.5 ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    0.5x Slow-Mo
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSpeedChange(1.0)}
                    className={`px-2 py-0.5 rounded font-bold transition ${
                      playbackSpeed === 1.0 ? 'bg-slate-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    1.0x Normal
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsMuted(!isMuted)}
                  className="p-1.5 text-slate-300 hover:text-white transition"
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Clinical Case Summary Footer */}
        <div className="p-4 bg-slate-800/90 border-t border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
          <div>
            <div className="flex items-center gap-2 text-slate-300 mb-1">
              <User className="w-3.5 h-3.5 text-slate-400" />
              <span className="font-bold text-white">{reportedBy}</span>
              <span className="text-slate-500">•</span>
              <Phone className="w-3.5 h-3.5 text-slate-400" />
              <span className="font-mono text-emerald-400">{reporterPhone}</span>
              <span className="text-slate-500">•</span>
              <MapPin className="w-3.5 h-3.5 text-slate-400" />
              <span>{location}</span>
            </div>
            <div className="flex flex-wrap gap-1 mt-1.5">
              {symptoms.map((s, i) => (
                <span
                  key={i}
                  className="bg-rose-950/80 text-rose-300 border border-rose-800/50 px-2 py-0.2 rounded text-[10px] font-bold"
                >
                  {s}
                </span>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {onActionPrescribe && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onActionPrescribe();
                }}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-md"
              >
                <Stethoscope className="w-4 h-4" />
                <span>Prescribe Rx Treatment</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-xl text-xs font-bold transition"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
