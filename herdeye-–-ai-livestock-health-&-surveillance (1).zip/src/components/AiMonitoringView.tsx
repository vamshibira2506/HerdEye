import React, { useState, useEffect } from 'react';
import { useLivestock } from '../context/LivestockContext';
import {
  Video,
  Scan,
  AlertTriangle,
  Activity,
  CheckCircle,
  Clock,
  Maximize2,
  RefreshCw,
  Sparkles,
  Thermometer,
  Eye,
  Info,
  Layers,
  ChevronRight,
} from 'lucide-react';

export const AiMonitoringView: React.FC = () => {
  const { animals, setSelectedAnimal, setActiveTab } = useLivestock();
  const [selectedCam, setSelectedCam] = useState<'cam1' | 'cam2' | 'cam3'>('cam1');
  const [isScanning, setIsScanning] = useState(false);
  const [showOverlays, setShowOverlays] = useState(true);
  const [fps, setFps] = useState(28);

  const cameras = [
    {
      id: 'cam1',
      name: 'Barn CAM 01 - Shed A (Murrah Lactation Wing)',
      location: 'Mogri Farm, Anand',
      status: 'Online',
      detectedCount: 4,
      primaryAnimalId: 'IN-GJ-2024-9182',
      feedUrl: 'https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?auto=format&fit=crop&w=1200&q=80',
    },
    {
      id: 'cam2',
      name: 'Barn CAM 02 - Isolation & Calving Pen',
      location: 'Daurala, Meerut',
      status: 'Online',
      detectedCount: 2,
      primaryAnimalId: 'IN-UP-2024-5501',
      feedUrl: 'https://images.unsplash.com/photo-1596733430284-f7437764b1a9?auto=format&fit=crop&w=1200&q=80',
    },
    {
      id: 'cam3',
      name: 'Barn CAM 03 - Breeding Bull Pen',
      location: 'Hisar ICAR Station',
      status: 'Online',
      detectedCount: 1,
      primaryAnimalId: 'IN-HR-2024-1109',
      feedUrl: 'https://images.unsplash.com/photo-1527153857715-3908f2ae5e81?auto=format&fit=crop&w=1200&q=80',
    },
  ];

  const currentCam = cameras.find(c => c.id === selectedCam) || cameras[0];
  const primaryAnimal = animals.find(a => a.id === currentCam.primaryAnimalId) || animals[0];

  const triggerRescan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
    }, 1600);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setFps(Math.floor(27 + Math.random() * 4));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6" id="ai-monitoring-view">
      {/* Top Banner & Mandatory Regulatory Disclaimer */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-sky-100 text-sky-800 text-[11px] font-extrabold px-2.5 py-0.5 rounded border border-sky-300 uppercase tracking-wider">
                Computer Vision & Behavior Surveillance
              </span>
              <span className="text-emerald-700 text-xs font-bold flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                Neural Pipeline Active ({fps} FPS)
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">
              AI Livestock Posture, Rumination & Anomaly Stream
            </h1>
            <p className="text-xs text-slate-600 mt-1 max-w-3xl">
              High-throughput video stream analysis evaluating rumination chewing cycles, feed trough dwell time, recumbency duration, and early syndromic markers.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={triggerRescan}
              disabled={isScanning}
              className="flex items-center gap-1.5 px-3 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-bold transition shadow-xs disabled:opacity-50"
              id="ai-trigger-rescan-btn"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
              <span>{isScanning ? 'Analyzing Neural Frames...' : 'Re-Run Frame Analysis'}</span>
            </button>
            <button
              onClick={() => setShowOverlays(!showOverlays)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold border transition ${
                showOverlays
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-700 border-slate-300'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{showOverlays ? 'Bounding Boxes: ON' : 'Bounding Boxes: OFF'}</span>
            </button>
          </div>
        </div>

        {/* AI Early Warning Regulatory Disclaimer */}
        <div className="mt-4 p-3.5 bg-amber-50 rounded-xl border border-amber-200 flex items-start gap-3">
          <Info className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
          <div className="text-xs text-amber-900">
            <span className="font-bold uppercase tracking-wide text-amber-950">
              Veterinary Surveillance Protocol Notice:
            </span>{' '}
            HerdEye AI algorithms provide <strong>early behavioral anomaly warning</strong> and syndromic risk scoring to assist rapid triage. It does <strong>not constitute a definitive veterinary medical diagnosis</strong>. All flagged alerts require on-ground clinical verification by an authorized veterinary officer.
          </div>
        </div>
      </div>

      {/* Main Grid: Camera Live Stage + Real-Time Telemetry Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left: Video Stage (7 cols) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          {/* Camera Selector Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {cameras.map(cam => (
              <button
                key={cam.id}
                onClick={() => setSelectedCam(cam.id as any)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition border ${
                  selectedCam === cam.id
                    ? 'bg-emerald-900 text-white border-emerald-950 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                <Video className={`w-3.5 h-3.5 ${selectedCam === cam.id ? 'text-emerald-300' : 'text-slate-400'}`} />
                <span>{cam.name.split('-')[0]}</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              </button>
            ))}
          </div>

          {/* Interactive Video Viewport with CV Overlays */}
          <div className="relative bg-slate-950 rounded-2xl overflow-hidden border-2 border-slate-800 shadow-lg aspect-video flex items-center justify-center group">
            <img
              src={currentCam.feedUrl}
              alt="Live Livestock Barn Feed"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover opacity-90 filter brightness-95 contrast-105"
            />

            {/* Scanning Laser Line Effect during Rescan */}
            {isScanning && (
              <div className="absolute inset-0 bg-gradient-to-b from-sky-500/20 via-transparent to-transparent pointer-events-none animate-pulse border-b-2 border-sky-400" />
            )}

            {/* Camera Header HUD */}
            <div className="absolute top-3 left-3 right-3 flex items-center justify-between text-xs text-white bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 pointer-events-none">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                <span className="font-mono font-bold uppercase tracking-wider text-rose-300">
                  LIVE CCTV FEED
                </span>
                <span className="text-white/60">|</span>
                <span className="font-medium text-[11px] text-white/90">{currentCam.name}</span>
              </div>
              <div className="flex items-center gap-3 font-mono text-[11px]">
                <span>{fps} FPS</span>
                <span>RES: 1080p AI-HDR</span>
                <span className="text-emerald-400">LATENCY: 42ms</span>
              </div>
            </div>

            {/* Computer Vision Bounding Boxes & Tags */}
            {showOverlays && (
              <>
                {/* Primary Detected Bounding Box */}
                <div className="absolute inset-[15%_20%_15%_20%] border-2 border-emerald-400 rounded-lg pointer-events-none transition-all shadow-[0_0_15px_rgba(52,211,153,0.3)]">
                  {/* Top Tag */}
                  <div className="absolute -top-7 left-0 bg-emerald-900/90 text-white text-[10px] font-mono px-2 py-0.5 rounded border border-emerald-400 flex items-center gap-1.5 backdrop-blur-xs">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span className="font-bold">TAG: {primaryAnimal.id}</span>
                    <span className="text-emerald-300 font-semibold">({primaryAnimal.breed})</span>
                  </div>

                  {/* Corner Reticles */}
                  <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-white"></div>
                  <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-white"></div>
                  <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-white"></div>
                  <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-white"></div>

                  {/* Bottom AI Diagnostic Tag */}
                  <div className="absolute -bottom-7 left-0 right-0 flex items-center justify-between text-[10px] bg-slate-950/80 text-white px-2 py-0.5 rounded border border-slate-700">
                    <span className="truncate">
                      Posture: <strong className="text-sky-300">{primaryAnimal.postureStatus.split('&')[0]}</strong>
                    </span>
                    <span className="font-mono text-emerald-400">
                      Rumination: {primaryAnimal.ruminationMinutesPerDay} min/d
                    </span>
                  </div>
                </div>

                {/* Secondary Anomaly Bounding Box if animal is high risk */}
                {primaryAnimal.healthStatus === 'High Risk / Critical' && (
                  <div className="absolute top-[30%] left-[24%] w-24 h-20 border-2 border-rose-500 rounded border-dashed bg-rose-500/10 pointer-events-none">
                    <span className="absolute -top-5 left-0 bg-rose-700 text-white text-[9px] font-bold px-1.5 py-0.2 rounded uppercase">
                      ⚠️ Anomaly: Saliva / Froth
                    </span>
                  </div>
                )}
              </>
            )}

            {/* Bottom Controls on Video */}
            <div className="absolute bottom-3 right-3 flex items-center gap-2">
              <button
                onClick={() => setSelectedAnimal(primaryAnimal)}
                className="bg-emerald-600/90 hover:bg-emerald-500 text-white text-xs font-bold px-3 py-1.5 rounded-lg backdrop-blur-md transition shadow-md flex items-center gap-1"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Open Animal Profile</span>
              </button>
            </div>
          </div>

          {/* Quick Camera Technical Specs */}
          <div className="grid grid-cols-3 gap-2.5 text-center text-xs">
            <div className="bg-white p-2.5 rounded-xl border border-slate-200">
              <span className="text-[10px] uppercase text-slate-400 block font-semibold">Motion Index</span>
              <span className="font-extrabold text-slate-800">{primaryAnimal.activityScore}% Activity</span>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-slate-200">
              <span className="text-[10px] uppercase text-slate-400 block font-semibold">Chewing Index</span>
              <span className="font-extrabold text-slate-800">46 chews/min</span>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-slate-200">
              <span className="text-[10px] uppercase text-slate-400 block font-semibold">Thermal Estimation</span>
              <span className={`font-extrabold ${primaryAnimal.bodyTemperatureC > 39.5 ? 'text-rose-600' : 'text-emerald-700'}`}>
                {primaryAnimal.bodyTemperatureC} °C
              </span>
            </div>
          </div>
        </div>

        {/* Right: AI Telemetry & Behavior Analytics (5 cols) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          {/* Risk Score Gauge Card */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                AI Early-Warning Risk Score
              </span>
              <span
                className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${
                  primaryAnimal.riskPriority === 'Critical'
                    ? 'bg-rose-600 text-white'
                    : primaryAnimal.riskPriority === 'High'
                    ? 'bg-amber-600 text-white'
                    : 'bg-emerald-700 text-white'
                }`}
              >
                {primaryAnimal.riskPriority} Priority
              </span>
            </div>

            <div className="flex items-center gap-4 mb-4">
              <div className="relative w-20 h-20 shrink-0 flex items-center justify-center">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                  <path
                    className="text-slate-100"
                    strokeWidth="3.5"
                    stroke="currentColor"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                  <path
                    className={
                      primaryAnimal.riskScore > 75
                        ? 'text-rose-600'
                        : primaryAnimal.riskScore > 40
                        ? 'text-amber-500'
                        : 'text-emerald-600'
                    }
                    strokeDasharray={`${primaryAnimal.riskScore}, 100`}
                    strokeWidth="3.5"
                    strokeLinecap="round"
                    stroke="currentColor"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                </svg>
                <div className="absolute flex flex-col items-center justify-center text-center">
                  <span className="text-xl font-black text-slate-900 leading-none">
                    {primaryAnimal.riskScore}
                  </span>
                  <span className="text-[9px] text-slate-400 font-semibold">/100</span>
                </div>
              </div>

              <div className="flex-1">
                <h3 className="text-xs font-bold text-slate-900">
                  {primaryAnimal.confidenceAlert || 'Behavior Consistent with Normal Health Baseline'}
                </h3>
                <p className="text-[11px] text-slate-500 mt-1">
                  Evaluated across 24h rumination drops, posture recumbency, feed intake velocity, and optical mouth/claw segmentation.
                </p>
              </div>
            </div>

            {/* Multi-parameter Sub-Scores */}
            <div className="space-y-2 pt-3 border-t border-slate-100 text-xs">
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-slate-600 font-medium">Rumination Deficit</span>
                  <span className="font-bold text-slate-800">
                    {primaryAnimal.ruminationMinutesPerDay < 200 ? 'Severe (72% Drop)' : 'Normal (485 min)'}
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${
                      primaryAnimal.ruminationMinutesPerDay < 200 ? 'bg-rose-500 w-4/5' : 'bg-emerald-500 w-1/5'
                    }`}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-slate-600 font-medium">Posture & Stride Cadence</span>
                  <span className="font-bold text-slate-800">
                    {primaryAnimal.postureStatus.includes('Lameness') ? 'Lameness Detected' : 'Normal Gait'}
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${
                      primaryAnimal.postureStatus.includes('Lameness') ? 'bg-amber-500 w-3/4' : 'bg-emerald-500 w-1/6'
                    }`}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-slate-600 font-medium">Visible Anomaly Segmentation</span>
                  <span className="font-bold text-slate-800">
                    {primaryAnimal.visibleAbnormalities.length > 0
                      ? `${primaryAnimal.visibleAbnormalities.length} Markers Found`
                      : 'Zero Abnormalities'}
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${
                      primaryAnimal.visibleAbnormalities.length > 0 ? 'bg-rose-600 w-5/6' : 'bg-emerald-500 w-1/12'
                    }`}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Detected Visible Abnormalities List */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2.5 flex items-center justify-between">
              <span>Visible Abnormalities (Computer Vision)</span>
              <Scan className="w-3.5 h-3.5 text-slate-400" />
            </h3>

            {primaryAnimal.visibleAbnormalities.length > 0 ? (
              <ul className="space-y-2 text-xs">
                {primaryAnimal.visibleAbnormalities.map((abn, i) => (
                  <li
                    key={i}
                    className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-rose-900 flex items-start gap-2"
                  >
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                    <span>{abn}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-900 text-xs flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>No mucosal lesions, swelling, or lameness detected in current camera frame.</span>
              </div>
            )}
          </div>

          {/* Rapid Action CTA */}
          <div className="bg-emerald-900 text-white rounded-xl p-4 shadow-sm flex items-center justify-between">
            <div>
              <h4 className="text-xs font-extrabold text-white">Need Clinical Tele-Review?</h4>
              <p className="text-[11px] text-emerald-200">
                Forward this live camera snippet directly to District Veterinarian.
              </p>
            </div>
            <button
              onClick={() => setActiveTab('reporting')}
              className="px-3 py-1.5 bg-white text-emerald-950 font-bold text-xs rounded-lg shadow-xs hover:bg-emerald-50 transition shrink-0"
            >
              Report Case
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
