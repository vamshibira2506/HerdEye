import React from 'react';
import { useLivestock } from '../context/LivestockContext';
import {
  CloudUpload,
  Wifi,
  WifiOff,
  CheckCircle2,
  Clock,
  Trash2,
  X,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';

interface OfflineSyncDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const OfflineSyncDrawer: React.FC<OfflineSyncDrawerProps> = ({
  isOpen,
  onClose,
}) => {
  const { offlineQueue, isOnline, syncOfflineData, clearOfflineQueue } = useLivestock();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-end backdrop-blur-xs">
      <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col justify-between border-l border-slate-200">
        {/* Top Header */}
        <div className="p-5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-lg ${isOnline ? 'bg-emerald-600/30 text-emerald-400' : 'bg-amber-600/30 text-amber-400'}`}>
              {isOnline ? <Wifi className="w-5 h-5" /> : <WifiOff className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-white">
                Offline Outbox & Cloud Sync
              </h3>
              <p className="text-[11px] text-slate-400">
                {isOnline ? 'Network Connected (Ready to Sync)' : 'No Connection (Storing Locally)'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Queue Items List */}
        <div className="flex-1 p-5 overflow-y-auto space-y-3 text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="font-bold text-slate-700 uppercase tracking-wider text-[10px]">
              Pending Outbox Queue ({offlineQueue.length})
            </span>
            {offlineQueue.length > 0 && (
              <button
                onClick={clearOfflineQueue}
                className="text-rose-600 hover:text-rose-700 text-[11px] font-bold flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear</span>
              </button>
            )}
          </div>

          {offlineQueue.length === 0 ? (
            <div className="py-12 text-center text-slate-400 space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto opacity-70" />
              <p className="font-bold text-slate-700">All data synchronized!</p>
              <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                No offline records pending. Any registrations, vaccinations, or symptom logs created while offline will appear here.
              </p>
            </div>
          ) : (
            offlineQueue.map(item => (
              <div
                key={item.id}
                className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5"
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-black text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded uppercase">
                    {item.type.replace('_', ' ')}
                  </span>
                  <span className="text-slate-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <div className="text-slate-800 font-medium">
                  {item.type === 'animal_register' && (
                    <span>Registration: {item.payload.name} ({item.payload.breed})</span>
                  )}
                  {item.type === 'symptom_report' && (
                    <span>Symptom Log: Animal {item.payload.animalId} ({item.payload.severity})</span>
                  )}
                  {item.type === 'vet_treatment' && (
                    <span>Clinical Rx: {item.payload.diagnosis || 'Treatment'} for {item.payload.animalId}</span>
                  )}
                  {item.type === 'mortality_report' && (
                    <span>Mortality: Animal {item.payload.animalId}</span>
                  )}
                  {item.type === 'lab_referral' && (
                    <span>Lab Sample: {item.payload.testRequested || 'Specimen test'}</span>
                  )}
                </div>
                <span className="text-[10px] text-slate-400 block font-mono">
                  Payload ID: {item.id}
                </span>
              </div>
            ))
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 space-y-2">
          <button
            onClick={syncOfflineData}
            disabled={offlineQueue.length === 0}
            className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-600 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-md flex items-center justify-center gap-2 transition"
          >
            <CloudUpload className="w-4 h-4" />
            <span>Synchronize Outbox Now ({offlineQueue.length})</span>
          </button>
          <p className="text-[10px] text-center text-slate-400">
            Automatically synchronizes in the background when connectivity returns.
          </p>
        </div>
      </div>
    </div>
  );
};
