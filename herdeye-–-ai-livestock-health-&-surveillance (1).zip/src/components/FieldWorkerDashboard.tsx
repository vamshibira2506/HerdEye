import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { Animal } from '../types';
import {
  ClipboardCheck,
  QrCode,
  ScanLine,
  Syringe,
  AlertTriangle,
  CheckCircle2,
  Search,
  Plus,
  Wifi,
  WifiOff,
  Clock,
  ArrowRight,
} from 'lucide-react';

interface FieldWorkerDashboardProps {
  onOpenReport: () => void;
  onOpenRegister: () => void;
  onSelectAnimal: (animal: Animal) => void;
}

export const FieldWorkerDashboard: React.FC<FieldWorkerDashboardProps> = ({
  onOpenReport,
  onOpenRegister,
  onSelectAnimal,
}) => {
  const { animals, addVaccination, isOnline, offlineQueue } = useLivestock();
  const [tagSearch, setTagSearch] = useState('');
  const [selectedForVaccine, setSelectedForVaccine] = useState<string>(animals[0]?.id || '');
  const [vaccineName, setVaccineName] = useState('Raksha-Ovac (FMD Inactivated)');
  const [targetDisease, setTargetDisease] = useState('Foot and Mouth Disease (FMD)');
  const [batchNo, setBatchNo] = useState(`RO-2024-${Math.floor(100 + Math.random() * 900)}`);

  const [scanSimulated, setScanSimulated] = useState(false);

  const searchedAnimal = tagSearch
    ? animals.find(a => a.id.toLowerCase().includes(tagSearch.toLowerCase()))
    : null;

  const handleSimulateScan = () => {
    setScanSimulated(true);
    const randomAnimal = animals[Math.floor(Math.random() * animals.length)];
    setTagSearch(randomAnimal.id);
    setTimeout(() => {
      setScanSimulated(false);
    }, 800);
  };

  const handleQuickVaccine = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedForVaccine) return;

    addVaccination(selectedForVaccine, {
      vaccineName,
      targetDisease,
      batchNumber: batchNo,
      administeredDate: new Date().toISOString().split('T')[0],
      nextDueDate: new Date(Date.now() + 180 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      administeredBy: 'Anjali Patel (Pashu Sakhi / Paravet)',
      status: 'Done',
    });

    setBatchNo(`RO-2024-${Math.floor(100 + Math.random() * 900)}`);
  };

  return (
    <div className="space-y-6" id="fieldworker-dashboard-root">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-amber-900 via-amber-950 to-slate-900 text-white p-5 sm:p-6 rounded-2xl border border-amber-800/40 shadow-sm relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                Pashu Sakhi / Paravet Field Desk
              </span>
              <span className="text-slate-300 text-xs flex items-center gap-1">
                {isOnline ? (
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <Wifi className="w-3.5 h-3.5" /> Online Mode
                  </span>
                ) : (
                  <span className="text-amber-400 font-semibold flex items-center gap-1">
                    <WifiOff className="w-3.5 h-3.5" /> Offline Field Cache Active ({offlineQueue.length} pending)
                  </span>
                )}
              </span>
            </div>
            <h1 className="text-2xl font-black text-white">
              Door-to-Door Livestock Census & Health Survey
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
              Equipped for low-connectivity rural field tours. Scan RFID ear tags, record field symptoms, log vaccinations, and queue data for auto-sync.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={handleSimulateScan}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-amber-950 rounded-xl text-xs font-black shadow-md transition"
              id="fieldworker-scan-rfid-btn"
            >
              <QrCode className="w-4 h-4" />
              <span>{scanSimulated ? 'Reading Tag...' : 'Scan RFID / QR Tag'}</span>
            </button>
            <button
              onClick={onOpenReport}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold shadow-md transition"
            >
              <AlertTriangle className="w-4 h-4" />
              <span>Log Field Symptom</span>
            </button>
          </div>
        </div>
      </div>

      {/* Field Inspection & Quick Tag Lookup */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Tag Scanner & Animal Quick Check (7 cols) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3 flex items-center justify-between">
              <span>Livestock Ear-Tag Lookup & Triage</span>
              <ScanLine className="w-4 h-4 text-slate-400" />
            </h2>

            <div className="flex gap-2 mb-4">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Enter Tag ID e.g. IN-GJ-2024-9182 or click Scan RFID..."
                  value={tagSearch}
                  onChange={e => setTagSearch(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500"
                />
              </div>
              <button
                onClick={handleSimulateScan}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-bold border border-slate-200 flex items-center gap-1 shrink-0"
              >
                <QrCode className="w-3.5 h-3.5" />
                <span>Simulate Scan</span>
              </button>
            </div>

            {searchedAnimal ? (
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row gap-4 items-start">
                <img
                  src={searchedAnimal.photoUrl}
                  alt={searchedAnimal.name}
                  referrerPolicy="no-referrer"
                  className="w-20 h-20 rounded-xl object-cover border border-slate-200 shrink-0"
                />
                <div className="flex-1 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded text-[11px]">
                      {searchedAnimal.id}
                    </span>
                    <span
                      className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${
                        searchedAnimal.healthStatus === 'Healthy'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {searchedAnimal.healthStatus}
                    </span>
                  </div>

                  <h3 className="font-extrabold text-sm text-slate-900 mt-1">
                    {searchedAnimal.name} ({searchedAnimal.breed})
                  </h3>
                  <p className="text-slate-500 mt-0.5">
                    Farmer: {searchedAnimal.ownerName} • {searchedAnimal.location.village} ({searchedAnimal.location.district})
                  </p>

                  <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-slate-200 text-[11px]">
                    <div>
                      <span className="text-slate-400 block text-[10px]">Temp:</span>
                      <strong className={searchedAnimal.bodyTemperatureC > 39.5 ? 'text-rose-600' : 'text-slate-800'}>
                        {searchedAnimal.bodyTemperatureC}°C
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">Vaccinations:</span>
                      <strong>{searchedAnimal.vaccinationRecords.length} logged</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">Risk Score:</span>
                      <strong className="text-rose-600">{searchedAnimal.riskScore}/100</strong>
                    </div>
                  </div>

                  <div className="mt-3 flex items-center gap-2">
                    <button
                      onClick={() => onSelectAnimal(searchedAnimal)}
                      className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-bold"
                    >
                      Open Full Profile
                    </button>
                    <button
                      onClick={() => setSelectedForVaccine(searchedAnimal.id)}
                      className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-bold"
                    >
                      Administer Vaccine
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center text-slate-400 text-xs border border-dashed border-slate-200 rounded-xl">
                Scan or enter an animal tag ID above to view owner details and triage status.
              </div>
            )}
          </div>

          {/* Door to Door Inspection Schedule */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3">
              Village Mogri Survey Checklist (Today's Route)
            </h2>
            <div className="space-y-2 text-xs">
              {[
                { house: 'Farm House #01 - Shri Ram Dairy (Ramesh Patel)', count: '4 Animals', status: 'In Progress' },
                { house: 'Farm House #02 - Gokul Dairy (Virendra Yadav)', count: '6 Animals', status: 'Pending' },
                { house: 'Farm House #03 - Kisan Seva Gaushala', count: '12 Animals', status: 'Pending' },
              ].map((item, idx) => (
                <div key={idx} className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-900 block">{item.house}</span>
                    <span className="text-slate-500 text-[11px]">{item.count}</span>
                  </div>
                  <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded">
                    {item.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Rapid Vaccination Log (5 cols) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
            <div className="flex items-center gap-2 mb-3">
              <Syringe className="w-4 h-4 text-emerald-700" />
              <h2 className="text-sm font-bold text-slate-900">
                Quick Field Vaccine Administrator
              </h2>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Log national vaccination campaign shots (NADCP / FMD Mukt Bharat) directly into the registry.
            </p>

            <form onSubmit={handleQuickVaccine} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Target Animal *</label>
                <select
                  value={selectedForVaccine}
                  onChange={e => setSelectedForVaccine(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800 font-medium"
                >
                  {animals.map(a => (
                    <option key={a.id} value={a.id}>
                      {a.id} - {a.name} ({a.breed})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Vaccine Name *</label>
                <select
                  value={vaccineName}
                  onChange={e => {
                    setVaccineName(e.target.value);
                    if (e.target.value.includes('FMD')) setTargetDisease('Foot and Mouth Disease (FMD)');
                    else if (e.target.value.includes('LSD') || e.target.value.includes('Pox')) setTargetDisease('Lumpy Skin Disease (LSD)');
                    else if (e.target.value.includes('Brucellosis')) setTargetDisease('Bovine Brucellosis');
                    else setTargetDisease('Hemorrhagic Septicemia (HS)');
                  }}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800 font-medium"
                >
                  <option value="Raksha-Ovac (FMD Inactivated)">Raksha-Ovac (FMD Inactivated)</option>
                  <option value="Lumpy Shield-M / Goat Pox">Lumpy Shield-M (LSD Prophylaxis)</option>
                  <option value="Bruvax S19 (Bovine Brucellosis)">Bruvax S19 (Calfhood)</option>
                  <option value="HS-BQ Combined Adjuvant">HS-BQ Combined Vaccine</option>
                  <option value="Anthrax Spore Vaccine">Anthrax Spore Vaccine (Sterne strain)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Cold-Chain Batch Number *</label>
                <input
                  type="text"
                  required
                  value={batchNo}
                  onChange={e => setBatchNo(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg font-bold shadow-xs flex items-center justify-center gap-1.5 transition"
                >
                  <Syringe className="w-4 h-4" />
                  <span>Log Vaccination in Registry</span>
                </button>
              </div>
            </form>
          </div>

          {/* Quick Offline Tips */}
          <div className="bg-amber-50 rounded-xl border border-amber-200 p-4 text-xs text-amber-900">
            <span className="font-bold block mb-1">Offline Tour Note:</span>
            When visiting deep rural sheds without 4G/5G, click the top Network button to toggle "Offline Mode". Your registrations and vaccination records will safely store on your mobile tablet and sync automatically when entering cellular coverage.
          </div>
        </div>
      </div>
    </div>
  );
};
