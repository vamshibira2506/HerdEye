import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { OutbreakCluster } from '../types';
import { IndiaSurveillanceMap } from './IndiaSurveillanceMap';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  ShieldAlert,
  Download,
  Filter,
  Layers,
  MapPin,
  TrendingUp,
  AlertTriangle,
  FileCheck,
  CheckCircle2,
  Syringe,
  Skull,
  Calendar,
} from 'lucide-react';

export const GovernmentDashboard: React.FC = () => {
  const {
    clusters,
    animals,
    filterState,
    setFilterState,
    filterDistrict,
    setFilterDistrict,
    filterSpecies,
    setFilterSpecies,
    filterRisk,
    setFilterRisk,
  } = useLivestock();

  const [dateRange, setDateRange] = useState<'7d' | '30d' | '90d'>('30d');
  const [selectedClusterDetail, setSelectedClusterDetail] = useState<OutbreakCluster | null>(clusters[0]);

  // Aggregate stats
  const totalBovinesMonitored = 184520;
  const activeCasesTotal = clusters.reduce((acc, c) => acc + c.activeCases, 0);
  const totalMortalities = clusters.reduce((acc, c) => acc + c.mortalities, 0);
  const avgVaccineCoverage = Math.round(
    clusters.reduce((acc, c) => acc + c.vaccinationCoveragePercent, 0) / (clusters.length || 1)
  );

  // Filter clusters based on state and risk level
  const filteredClusters = clusters.filter(c => {
    if (filterState !== 'All' && c.state !== filterState) return false;
    if (filterRisk !== 'All' && c.riskLevel !== filterRisk) return false;
    return true;
  });

  // Chart data: Epidemiological Trends (Last 6 Months / Weeks)
  const diseaseTrendData = [
    { period: 'W1 Aug', FMD: 12, LSD: 45, Mastitis: 28, HS: 4 },
    { period: 'W2 Aug', FMD: 18, LSD: 58, Mastitis: 31, HS: 6 },
    { period: 'W3 Aug', FMD: 24, LSD: 72, Mastitis: 26, HS: 9 },
    { period: 'W4 Aug', FMD: 31, LSD: 85, Mastitis: 30, HS: 14 },
    { period: 'W1 Sep', FMD: 38, LSD: 94, Mastitis: 34, HS: 12 },
    { period: 'W2 Sep (Now)', FMD: 42, LSD: 87, Mastitis: 29, HS: 11 },
  ];

  // Chart data: Vaccination Target vs Achievement by District
  const vaccinationChartData = [
    { district: 'Anand (GJ)', Target: 90, Achieved: 72 },
    { district: 'Meerut (UP)', Target: 90, Achieved: 55 },
    { district: 'Hisar (HR)', Target: 90, Achieved: 88 },
    { district: 'Ludhiana (PB)', Target: 90, Achieved: 92 },
    { district: 'Jodhpur (RJ)', Target: 90, Achieved: 68 },
    { district: 'Karnal (HR)', Target: 90, Achieved: 84 },
  ];

  // Export CSV generator for government reports
  const handleExportCSV = () => {
    const headers = 'Cluster ID,Disease Name,Risk Level,State,District,Block,Active Cases,Mortalities,Vaccination Coverage %\n';
    const rows = clusters.map(c =>
      `"${c.id}","${c.diseaseName}","${c.riskLevel}","${c.state}","${c.district}","${c.block}",${c.activeCases},${c.mortalities},${c.vaccinationCoveragePercent}%`
    ).join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `HerdEye_Epidemic_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6" id="government-dashboard-root">
      {/* Top Header Strip with Official Emblems */}
      <div className="bg-slate-900 text-white p-5 sm:p-6 rounded-2xl border border-slate-800 shadow-sm relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 text-[11px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                Directorate of Animal Husbandry & Dairying
              </span>
              <span className="text-slate-400 text-xs">
                National Epidemic Disease Surveillance & Early Response Command
              </span>
            </div>
            <h1 className="text-2xl font-black text-white">
              National Livestock Disease Surveillance Dashboard
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Centralized AI syndromic early-warning network integrating IoT barn vision, field paravet reports, and laboratory diagnostic confirmations.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold transition shadow-xs"
              id="govt-export-csv-btn"
            >
              <Download className="w-4 h-4" />
              <span>Export Surveillance CSV</span>
            </button>
          </div>
        </div>
      </div>

      {/* Multi-Parameter Filter Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider mb-2.5">
          <Filter className="w-3.5 h-3.5 text-emerald-700" />
          <span>Surveillance Filters & Aggregation</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 text-xs">
          {/* State Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">State</label>
            <select
              value={filterState}
              onChange={e => setFilterState(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800"
            >
              <option value="All">All States (India)</option>
              <option value="Gujarat">Gujarat</option>
              <option value="Uttar Pradesh">Uttar Pradesh</option>
              <option value="Haryana">Haryana</option>
              <option value="Punjab">Punjab</option>
              <option value="Rajasthan">Rajasthan</option>
            </select>
          </div>

          {/* District Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">District</label>
            <select
              value={filterDistrict}
              onChange={e => setFilterDistrict(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800"
            >
              <option value="All">All Districts</option>
              <option value="Anand">Anand (GJ)</option>
              <option value="Meerut">Meerut (UP)</option>
              <option value="Hisar">Hisar (HR)</option>
              <option value="Ludhiana">Ludhiana (PB)</option>
              <option value="Jodhpur">Jodhpur (RJ)</option>
            </select>
          </div>

          {/* Species */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">Animal Type</label>
            <select
              value={filterSpecies}
              onChange={e => setFilterSpecies(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800"
            >
              <option value="All">All Species (Bovine)</option>
              <option value="Buffalo">Buffaloes (Murrah, Jaffarabadi)</option>
              <option value="Cattle">Cattle (Gir, Sahiwal, Kankrej)</option>
            </select>
          </div>

          {/* Risk Level */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">Risk Level</label>
            <select
              value={filterRisk}
              onChange={e => setFilterRisk(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800"
            >
              <option value="All">All Risk Levels</option>
              <option value="Critical">Critical Outbreaks</option>
              <option value="High">High Risk</option>
              <option value="Medium">Medium Risk</option>
              <option value="Low">Low Risk</option>
            </select>
          </div>

          {/* Date Range */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">Surveillance Window</label>
            <select
              value={dateRange}
              onChange={e => setDateRange(e.target.value as any)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800"
            >
              <option value="7d">Last 7 Days (Rapid)</option>
              <option value="30d">Last 30 Days (Epidemic)</option>
              <option value="90d">Last 90 Days (Quarterly)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Key National Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase">Bovines Monitored</span>
            <span className="text-emerald-700 font-extrabold text-xs">National Registry</span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-slate-900">
            {totalBovinesMonitored.toLocaleString('en-IN')}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Across 1,420 monitored dairy clusters</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-rose-200 bg-rose-50/20 shadow-2xs">
          <div className="flex items-center justify-between text-rose-800 mb-1">
            <span className="text-[11px] font-bold uppercase">Active Disease Cases</span>
            <ShieldAlert className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-rose-600">
            {activeCasesTotal}
          </div>
          <p className="text-[11px] text-rose-700 mt-1">LSD & FMD leading contributors</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase">Vaccination Coverage</span>
            <Syringe className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-700">
            {avgVaccineCoverage}%
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Target 90% (NADCP Phase II)</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase">Cumulative Mortality</span>
            <Skull className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-slate-800">
            {totalMortalities}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Bio-disposal verified by vet officers</p>
        </div>
      </div>

      {/* Geospatial Map + Active Outbreak Clusters Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Map (7 cols) */}
        <div className="lg:col-span-7">
          <IndiaSurveillanceMap
            clusters={filteredClusters}
            selectedState={filterState}
            onSelectCluster={cluster => setSelectedClusterDetail(cluster)}
          />
        </div>

        {/* Selected Cluster Details & Active Outbreak List (5 cols) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          {/* Active Outbreaks Priority Cards */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-2xs flex-1">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Reported High-Risk Outbreak Clusters ({filteredClusters.length})
              </h3>
              <span className="text-[10px] bg-rose-100 text-rose-800 font-bold px-2 py-0.5 rounded">
                Live Feed
              </span>
            </div>

            <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
              {filteredClusters.map(cluster => (
                <div
                  key={cluster.id}
                  onClick={() => setSelectedClusterDetail(cluster)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition ${
                    selectedClusterDetail?.id === cluster.id
                      ? 'border-emerald-600 bg-emerald-50/50 shadow-xs'
                      : 'border-slate-200 bg-slate-50/60 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-slate-900">{cluster.diseaseName}</span>
                        <span
                          className={`text-[9px] font-black uppercase px-1.5 py-0.2 rounded ${
                            cluster.riskLevel === 'Critical'
                              ? 'bg-rose-600 text-white'
                              : cluster.riskLevel === 'High'
                              ? 'bg-amber-600 text-white'
                              : 'bg-emerald-700 text-white'
                          }`}
                        >
                          {cluster.riskLevel}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-0.5">
                        {cluster.block}, {cluster.district} ({cluster.state})
                      </p>
                    </div>

                    <span className="text-[11px] font-bold text-slate-500">
                      {cluster.farmsAffected} Farms
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-slate-200/80 text-[11px]">
                    <div>
                      <span className="text-slate-400 block text-[10px]">Active Cases:</span>
                      <strong className="text-rose-600">{cluster.activeCases}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">Deaths:</span>
                      <strong className="text-slate-800">{cluster.mortalities}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">Vaccine Cov:</span>
                      <strong className="text-emerald-700">{cluster.vaccinationCoveragePercent}%</strong>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Recharts: Epidemiological Disease & Symptom Trends + Vaccination Targets */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Chart 1: Disease Trend Over Weeks */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Syndromic Disease Prevalence Velocity
              </h3>
              <p className="text-[11px] text-slate-500">
                Weekly reported cases by etiology (FMD, LSD, Mastitis, HS)
              </p>
            </div>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              National Trend
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={diseaseTrendData} margin={{ top: 5, right: 20, left: -15, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="period" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Line type="monotone" dataKey="LSD" stroke="#ef4444" strokeWidth={2.5} />
                <Line type="monotone" dataKey="FMD" stroke="#f97316" strokeWidth={2.5} />
                <Line type="monotone" dataKey="Mastitis" stroke="#0284c7" strokeWidth={2} />
                <Line type="monotone" dataKey="HS" stroke="#8b5cf6" strokeWidth={1.8} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Vaccination Coverage by District vs Target */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                NADCP Vaccination Coverage vs 90% Target
              </h3>
              <p className="text-[11px] text-slate-500">
                District-wise comparative immunization completion percentage
              </p>
            </div>
            <span className="text-xs font-bold text-sky-800 bg-sky-50 px-2 py-0.5 rounded border border-sky-200">
              Goal: 90%
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={vaccinationChartData} margin={{ top: 5, right: 20, left: -15, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="district" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} unit="%" />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Bar dataKey="Achieved" fill="#059669" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Target" fill="#cbd5e1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* District-wise Statistics Table */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs overflow-hidden">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              District-Level Livestock Surveillance Registry
            </h3>
            <p className="text-xs text-slate-500">
              Aggregated epidemiology metrics across blocks and veterinary sub-divisions
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-y border-slate-200 text-slate-600 uppercase text-[10px] font-bold">
                <th className="p-3">District & State</th>
                <th className="p-3">Primary Epidemic Alert</th>
                <th className="p-3">Risk Category</th>
                <th className="p-3">Active Cases</th>
                <th className="p-3">Mortality</th>
                <th className="p-3">Vaccine Coverage</th>
                <th className="p-3">Containment Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {clusters.map(cl => (
                <tr key={cl.id} className="hover:bg-slate-50/80 transition">
                  <td className="p-3 font-bold text-slate-900">
                    {cl.district}, <span className="text-slate-500 font-normal">{cl.state}</span>
                  </td>
                  <td className="p-3 text-slate-800 font-semibold">{cl.diseaseName}</td>
                  <td className="p-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                        cl.riskLevel === 'Critical'
                          ? 'bg-rose-100 text-rose-800'
                          : cl.riskLevel === 'High'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {cl.riskLevel}
                    </span>
                  </td>
                  <td className="p-3 font-bold text-rose-600">{cl.activeCases}</td>
                  <td className="p-3 text-slate-700">{cl.mortalities}</td>
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-slate-200 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-600 h-full rounded-full"
                          style={{ width: `${cl.vaccinationCoveragePercent}%` }}
                        />
                      </div>
                      <span className="font-bold text-slate-800 text-[11px]">
                        {cl.vaccinationCoveragePercent}%
                      </span>
                    </div>
                  </td>
                  <td className="p-3">
                    <span className="font-medium text-[11px] text-slate-600">
                      {cl.alertStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
