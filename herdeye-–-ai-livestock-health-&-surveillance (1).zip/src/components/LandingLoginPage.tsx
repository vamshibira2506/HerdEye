import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { useLanguage } from '../context/LanguageContext';
import { UserRole } from '../types';
import { HerdEyeLogo } from './HerdEyeLogo';
import { SupportedLanguage, SUPPORTED_LANGUAGES } from '../utils/translations';
import {
  ShieldCheck,
  Stethoscope,
  Building2,
  Users,
  Tractor,
  ArrowRight,
  CheckCircle2,
  Globe,
  Volume2,
  Sparkles,
} from 'lucide-react';

interface LandingLoginPageProps {
  onLoginSuccess: () => void;
}

export const LandingLoginPage: React.FC<LandingLoginPageProps> = ({ onLoginSuccess }) => {
  const { role, setRole } = useLivestock();
  const { t, language, setLanguage, speakText } = useLanguage();
  const [selectedRole, setSelectedRole] = useState<UserRole>(role || 'farmer');

  const roleProfiles: {
    role: UserRole;
    title: string;
    subTitle: string;
    person: string;
    iconText: string;
    badge: string;
    color: string;
    borderColor: string;
    bgColor: string;
    description: string;
  }[] = [
    {
      role: 'farmer',
      title: t('role_farmer', 'రైతు / పశువుల యజమాని'),
      subTitle: t('role_farmer_sub', 'నా పశువుల ఆరోగ్యం • My Animals'),
      person: 'రమేష్ పటేల్ (Ramesh Patel)',
      iconText: '🐄',
      badge: 'సులభమైన బొమ్మలతో కూడిన వ్యవస్థ (Farmer Simple Mode)',
      color: 'from-emerald-700 to-teal-800 text-white',
      borderColor: 'border-emerald-500 hover:border-emerald-600',
      bgColor: 'bg-emerald-50/70',
      description: 'నా పశువుల ఆరోగ్యం, 15 సెకన్ల వీడియో పంపడం, టీకాలు, డాక్టర్‌తో మాట్లాడటం.',
    },
    {
      role: 'field_worker',
      title: t('role_field_worker', 'పశు సఖి / ఫీల్డ్ వర్కర్'),
      subTitle: t('role_field_worker_sub', 'గ్రామ పశు సేవా కేంద్రం • ASHA / Paravet'),
      person: 'అంజలి పటేల్ (Anjali Patel)',
      iconText: '👩‍🌾',
      badge: 'గ్రామ సర్వే & ఆఫ్‌లైన్ రికార్డులు (Offline First)',
      color: 'from-amber-600 to-amber-800 text-white',
      borderColor: 'border-amber-400 hover:border-amber-500',
      bgColor: 'bg-amber-50/70',
      description: 'డోర్-టు-డోర్ పశు సర్వే, RFID ట్యాగింగ్, టీకాలు వేయడం మరియు ఆఫ్‌లైన్ సమన్వయం.',
    },
    {
      role: 'veterinarian',
      title: t('role_veterinarian', 'పశువుల డాక్టర్ (Veterinarian)'),
      subTitle: t('role_veterinarian_sub', 'పశువైద్యశాల • Clinical Desk'),
      person: 'డాక్టర్ వి. కే. శర్మ (Dr. V. K. Sharma MVSc)',
      iconText: '👨‍⚕️',
      badge: 'టెలి-డయాగ్నోసిస్ & వీడియో పరిశీలన (Clinical)',
      color: 'from-sky-700 to-indigo-800 text-white',
      borderColor: 'border-sky-400 hover:border-sky-500',
      bgColor: 'bg-sky-50/70',
      description: 'రైతులు పంపిన 15 సెకన్ల వీడియోల పరిశీలన (Slow-Mo), డిజిటల్ ప్రిస్క్రిప్షన్లు & ల్యాబ్ రిఫరల్స్.',
    },
    {
      role: 'government',
      title: t('role_government', 'ప్రభుత్వ అధికారి (Government Officer)'),
      subTitle: t('role_government_sub', 'రాష్ట్ర పశుసంవర్ధక శాఖ • Surveillance'),
      person: 'డాక్టర్ ఎస్. కె. నాయర్ (Dr. S. K. Nair IAS)',
      iconText: '🏛️',
      badge: 'రాష్ట్ర & జిల్లా వ్యాధి పర్యవేక్షణ (Surveillance)',
      color: 'from-indigo-800 to-slate-900 text-white',
      borderColor: 'border-indigo-400 hover:border-indigo-500',
      bgColor: 'bg-indigo-50/70',
      description: 'భారతదేశ వ్యాప్తి మ్యాప్, ఎఫ్‌ఎండీ మరియు లంపీ స్కిన్ క్లస్టర్ల గుర్తింపు, నిర్బంధ ఉత్తర్వులు.',
    },
  ];

  const handleSelectAndProceed = (targetRole: UserRole) => {
    setSelectedRole(targetRole);
    setRole(targetRole);
    localStorage.setItem('herdeye_role', targetRole);
    localStorage.setItem('herdeye_onboarded', 'true');
    if (targetRole === 'farmer') {
      speakText('నమస్కారం, మీ పశువుల ఆరోగ్య కేంద్రానికి స్వాగతం');
    }
    onLoginSuccess();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-emerald-50/20 to-slate-100 flex flex-col justify-between" id="landing-login-root">
      {/* Top Header with Logo & Language Selector */}
      <nav className="bg-white border-b border-slate-200 px-4 sm:px-8 py-3 flex items-center justify-between sticky top-0 z-30 shadow-2xs">
        <HerdEyeLogo size="md" />

        {/* Multilingual Selector */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-1.5 bg-slate-100 border border-slate-300 rounded-2xl px-3 py-1.5 shadow-2xs">
            <Globe className="w-4 h-4 text-emerald-700" />
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as SupportedLanguage)}
              className="bg-transparent text-xs sm:text-sm font-extrabold text-slate-800 focus:outline-hidden cursor-pointer"
            >
              {SUPPORTED_LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.flag} {l.nativeName} ({l.name})
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => handleSelectAndProceed(selectedRole)}
            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-2xl text-xs font-black shadow-xs transition flex items-center gap-1.5"
          >
            <span>ప్రవేశించండి (Enter)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </nav>

      {/* Main Section */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 sm:py-10 flex-1 flex flex-col justify-center">
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-8">
          <div className="inline-flex items-center gap-2 bg-emerald-900 text-white text-xs font-bold px-3 py-1 rounded-full mb-3 shadow-2xs">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>{t('app_tagline', 'రైతు మిత్ర – పశువుల ఆరోగ్య రక్షణ మరియు వ్యాధి హెచ్చరికల వ్యవస్థ')}</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-black text-slate-950 tracking-tight leading-tight">
            {t('select_role_title', 'మీరు ఎవరో ఎంచుకోండి')}
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-2">
            {t('select_role_desc', 'రైతులకు చాలా సులభమైన బొమ్మలతో కూడిన వ్యవస్థ. డాక్టర్లు మరియు అధికారులకు పూర్తి సమాచారం.')}
          </p>
        </div>

        {/* 4 Large Role Cards per Requirement 1 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
          {roleProfiles.map((profile) => {
            const isSelected = selectedRole === profile.role;
            const isFarmer = profile.role === 'farmer';

            return (
              <div
                key={profile.role}
                onClick={() => handleSelectAndProceed(profile.role)}
                className={`relative rounded-3xl p-5 sm:p-6 border-3 transition-all cursor-pointer shadow-sm hover:shadow-xl active:scale-98 flex flex-col justify-between ${
                  profile.bgColor
                } ${profile.borderColor} ${isSelected ? 'ring-4 ring-emerald-400/40 shadow-md' : ''}`}
              >
                {isFarmer && (
                  <div className="absolute -top-3 right-5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-[11px] font-black px-3 py-1 rounded-full shadow-md uppercase tracking-wider flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    <span>రైతులకు ప్రత్యేకం (Farmer Friendly)</span>
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between gap-3 mb-3">
                    <div className="w-14 h-14 rounded-2xl bg-white shadow-md border border-slate-200 flex items-center justify-center text-3xl">
                      {profile.iconText}
                    </div>
                    <span className="text-[11px] font-extrabold px-2.5 py-1 rounded-xl bg-white/90 border border-slate-200 text-slate-700 shadow-2xs">
                      {profile.badge}
                    </span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight leading-snug">
                    {profile.title}
                  </h3>

                  <p className="text-xs sm:text-sm font-extrabold text-emerald-800 mt-0.5">
                    {profile.subTitle}
                  </p>

                  <p className="text-xs text-slate-600 mt-2.5 leading-relaxed">
                    {profile.description}
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-200/80 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-500">
                    లాగిన్: <strong className="text-slate-800">{profile.person}</strong>
                  </span>

                  <div className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 hover:bg-emerald-700 text-white font-black text-xs transition shadow-2xs">
                    <span>ప్రారంభించండి</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-3 text-center text-xs text-slate-500">
        HerdEye • రైతు మిత్ర • Smart India Hackathon & National Livestock Mission
      </footer>
    </div>
  );
};
