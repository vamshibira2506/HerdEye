import React, { useState, useRef, useEffect } from 'react';
import {
  Video,
  Camera,
  Play,
  Pause,
  RotateCcw,
  Upload,
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
  Volume2,
  VolumeX,
  StopCircle,
} from 'lucide-react';

export interface RecordedVideoData {
  videoUrl: string;
  durationSeconds: number;
  title: string;
  source: 'live_camera' | 'upload' | 'preset';
}

interface EvidenceVideoRecorderProps {
  onVideoSelected: (data: RecordedVideoData) => void;
  initialVideoUrl?: string;
  initialDuration?: number;
  initialTitle?: string;
  onClearVideo?: () => void;
}

const PRESET_CLINICAL_CLIPS: {
  title: string;
  duration: number;
  url: string;
  thumbnail: string;
  condition: string;
}[] = [
  {
    title: 'Oral Frothing & Stringy Salivation (14s)',
    duration: 14,
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    thumbnail: 'https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?auto=format&fit=crop&w=400&q=80',
    condition: 'Suspected Foot & Mouth Disease (FMD) vesicle rupture',
  },
  {
    title: 'Gait Lameness & Hoof Reluctance (12s)',
    duration: 12,
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    thumbnail: 'https://images.unsplash.com/photo-1527153857715-3908f2ae5e81?auto=format&fit=crop&w=400&q=80',
    condition: 'Interdigital hoof erosions / acute lameness',
  },
  {
    title: 'Severe Skin Nodules & Neck Edema (15s)',
    duration: 15,
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    thumbnail: 'https://images.unsplash.com/photo-1596733430284-f7437764b1a9?auto=format&fit=crop&w=400&q=80',
    condition: 'Lumpy Skin Disease (LSD) nodular eruptive phase',
  },
];

export const EvidenceVideoRecorder: React.FC<EvidenceVideoRecorderProps> = ({
  onVideoSelected,
  initialVideoUrl,
  initialDuration = 14,
  initialTitle = 'Field Evidence Clip (14s)',
  onClearVideo,
}) => {
  const [mode, setMode] = useState<'preview' | 'recording' | 'presets' | 'upload'>(
    initialVideoUrl ? 'preview' : 'presets'
  );

  // Video state
  const [videoUrl, setVideoUrl] = useState<string | null>(initialVideoUrl || null);
  const [duration, setDuration] = useState<number>(initialDuration);
  const [videoTitle, setVideoTitle] = useState<string>(initialTitle);

  // Live recording states
  const [isRecording, setIsRecording] = useState(false);
  const [recordedSeconds, setRecordedSeconds] = useState(0);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isCameraReady, setIsCameraReady] = useState(false);

  // Playback state
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);

  // Refs
  const liveVideoRef = useRef<HTMLVideoElement | null>(null);
  const playbackVideoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<any>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const MAX_RECORD_SECONDS = 15;

  // Cleanup stream on unmount or mode exit
  useEffect(() => {
    return () => {
      stopCameraStream();
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, []);

  const stopCameraStream = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }
    setIsCameraReady(false);
  };

  // Start live camera stream
  const startCamera = async () => {
    setCameraError(null);
    setMode('recording');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'environment' },
        audio: true,
      });
      mediaStreamRef.current = stream;
      if (liveVideoRef.current) {
        liveVideoRef.current.srcObject = stream;
        liveVideoRef.current.play();
      }
      setIsCameraReady(true);
    } catch (err: any) {
      console.warn('Camera access denied or unavailable in current frame:', err);
      setCameraError(
        'Camera or microphone is unavailable in this environment. You can upload a recorded video file or choose a realistic clinical preset clip.'
      );
      stopCameraStream();
    }
  };

  // Start recording 15s clip
  const startRecording = () => {
    if (!mediaStreamRef.current) return;
    recordedChunksRef.current = [];
    setRecordedSeconds(0);
    setIsRecording(true);

    try {
      const recorder = new MediaRecorder(mediaStreamRef.current);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (e: BlobEvent) => {
        if (e.data && e.data.size > 0) {
          recordedChunksRef.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        const finalDuration = Math.min(recordedSeconds || 1, MAX_RECORD_SECONDS);
        const finalTitle = `Live Camera Evidence (${finalDuration}s clip)`;

        setVideoUrl(url);
        setDuration(finalDuration);
        setVideoTitle(finalTitle);
        setMode('preview');
        stopCameraStream();

        onVideoSelected({
          videoUrl: url,
          durationSeconds: finalDuration,
          title: finalTitle,
          source: 'live_camera',
        });
      };

      recorder.start(250); // collect every 250ms

      // Countdown timer up to 15s
      let elapsed = 0;
      timerIntervalRef.current = setInterval(() => {
        elapsed += 1;
        setRecordedSeconds(elapsed);
        if (elapsed >= MAX_RECORD_SECONDS) {
          stopRecording();
        }
      }, 1000);
    } catch (err: any) {
      console.error('Error starting MediaRecorder:', err);
      setIsRecording(false);
      setCameraError('Failed to initialize video recorder. Please try file upload instead.');
    }
  };

  // Stop recording
  const stopRecording = () => {
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
  };

  // Handle file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Create object URL
    const url = URL.createObjectURL(file);

    // Read metadata to check duration
    const tempVideo = document.createElement('video');
    tempVideo.preload = 'metadata';
    tempVideo.src = url;

    tempVideo.onloadedmetadata = () => {
      let dur = Math.round(tempVideo.duration) || 10;
      if (dur > MAX_RECORD_SECONDS) {
        dur = MAX_RECORD_SECONDS; // Capped for tele-consultation bandwidth
      }
      const title = `${file.name.slice(0, 24)} (${dur}s clip)`;

      setVideoUrl(url);
      setDuration(dur);
      setVideoTitle(title);
      setMode('preview');

      onVideoSelected({
        videoUrl: url,
        durationSeconds: dur,
        title,
        source: 'upload',
      });
    };
  };

  // Select Preset Clip
  const handleSelectPreset = (preset: typeof PRESET_CLINICAL_CLIPS[0]) => {
    setVideoUrl(preset.url);
    setDuration(preset.duration);
    setVideoTitle(preset.title);
    setMode('preview');

    onVideoSelected({
      videoUrl: preset.url,
      durationSeconds: preset.duration,
      title: preset.title,
      source: 'preset',
    });
  };

  // Clear current video
  const handleReset = () => {
    stopCameraStream();
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    setIsRecording(false);
    setVideoUrl(null);
    setMode('presets');
    if (onClearVideo) onClearVideo();
  };

  // Playback control
  const togglePlay = () => {
    if (!playbackVideoRef.current) return;
    if (isPlaying) {
      playbackVideoRef.current.pause();
      setIsPlaying(false);
    } else {
      playbackVideoRef.current.play();
      setIsPlaying(true);
    }
  };

  return (
    <div className="bg-slate-900 text-white rounded-2xl p-4 border border-slate-700 shadow-md space-y-3" id="evidence-video-recorder">
      {/* Module Title & 15-second mandate banner */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-rose-600/20 text-rose-400 border border-rose-500/30 flex items-center justify-center">
            <Video className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black text-white">
                Tele-Veterinary Evidence Video
              </span>
              <span className="bg-rose-500 text-white text-[10px] font-black px-2 py-0.2 rounded-full uppercase tracking-wider">
                Max 15s Clip
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Farmers can record or attach up to a 15-second video clip for Dr. Sharma's tele-diagnosis.
            </p>
          </div>
        </div>

        {videoUrl && (
          <button
            type="button"
            onClick={handleReset}
            className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded-lg transition"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Retake / Change</span>
          </button>
        )}
      </div>

      {/* MODE: PREVIEW (Video Attached & Ready to Send to Doctor) */}
      {mode === 'preview' && videoUrl && (
        <div className="space-y-3">
          <div className="relative aspect-video max-h-56 w-full rounded-xl overflow-hidden bg-black border border-slate-700 flex items-center justify-center group">
            <video
              ref={playbackVideoRef}
              src={videoUrl}
              playsInline
              loop
              muted={isMuted}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              className="w-full h-full object-contain"
            />

            {/* Overlaid duration badge */}
            <div className="absolute top-2.5 left-2.5 bg-black/75 backdrop-blur-xs text-white text-[10px] font-mono px-2 py-0.5 rounded border border-white/20 flex items-center gap-1.5">
              <Clock className="w-3 h-3 text-rose-400" />
              <span>{duration}s / 15s max</span>
            </div>

            {/* Transmit Target */}
            <div className="absolute top-2.5 right-2.5 bg-emerald-950/80 backdrop-blur-xs text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-500/30 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              <span>Doctor Tele-Consult Ready</span>
            </div>

            {/* Center Play/Pause button */}
            <button
              type="button"
              onClick={togglePlay}
              className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-slate-900/80 hover:bg-slate-800 text-white flex items-center justify-center backdrop-blur-xs border border-white/30 transition transform hover:scale-105"
            >
              {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
            </button>

            {/* Audio Toggle */}
            <button
              type="button"
              onClick={() => setIsMuted(!isMuted)}
              className="absolute bottom-2.5 right-2.5 p-1.5 rounded-lg bg-black/60 text-white hover:bg-black/80 transition"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>

          <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700/80 flex items-center justify-between text-xs">
            <div>
              <span className="font-bold text-emerald-400 block flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                15-Second Evidence Clip Attached
              </span>
              <p className="text-[11px] text-slate-300 mt-0.5">{videoTitle}</p>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block font-mono">Telemetry verified</span>
              <span className="text-[11px] font-bold text-sky-400">Routes to Dr. Sharma</span>
            </div>
          </div>
        </div>
      )}

      {/* MODE: LIVE CAMERA RECORDING */}
      {mode === 'recording' && (
        <div className="space-y-3">
          <div className="relative aspect-video max-h-60 w-full rounded-xl overflow-hidden bg-black border border-slate-700 flex items-center justify-center">
            <video
              ref={liveVideoRef}
              playsInline
              muted
              autoPlay
              className="w-full h-full object-cover"
            />

            {/* Live Progress Bar for 15 Seconds */}
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-slate-800">
              <div
                className="h-full bg-rose-500 transition-all duration-1000 ease-linear"
                style={{ width: `${(recordedSeconds / MAX_RECORD_SECONDS) * 100}%` }}
              />
            </div>

            {/* Recording badge */}
            {isRecording && (
              <div className="absolute top-3 left-3 bg-rose-600/90 text-white px-2.5 py-1 rounded-full text-[11px] font-black flex items-center gap-1.5 animate-pulse shadow-lg">
                <span className="w-2 h-2 rounded-full bg-white"></span>
                <span>REC 00:{recordedSeconds < 10 ? `0${recordedSeconds}` : recordedSeconds} / 00:15</span>
              </div>
            )}

            {!isRecording && isCameraReady && (
              <div className="absolute top-3 left-3 bg-black/70 text-white px-2.5 py-1 rounded-full text-[10px] font-bold">
                Camera Live Viewfinder
              </div>
            )}

            {/* Camera Error / Fallback message */}
            {cameraError && (
              <div className="absolute inset-0 bg-slate-950/90 p-4 flex flex-col items-center justify-center text-center">
                <AlertCircle className="w-8 h-8 text-amber-400 mb-2" />
                <p className="text-xs text-slate-200 max-w-sm mb-3 leading-relaxed">
                  {cameraError}
                </p>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setMode('presets')}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold"
                  >
                    Use Clinical Presets
                  </button>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-xs font-bold"
                  >
                    Upload Video File
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Controls below camera */}
          {!cameraError && (
            <div className="flex items-center justify-between p-2 bg-slate-800 rounded-xl">
              <button
                type="button"
                onClick={() => {
                  stopCameraStream();
                  setMode('presets');
                }}
                className="px-3 py-1.5 text-slate-400 hover:text-white text-xs font-bold"
              >
                Cancel Live Cam
              </button>

              {!isRecording ? (
                <button
                  type="button"
                  onClick={startRecording}
                  disabled={!isCameraReady}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white rounded-xl text-xs font-black shadow-lg flex items-center gap-1.5"
                >
                  <span className="w-2.5 h-2.5 rounded-full bg-white animate-ping"></span>
                  <span>Record 15s Evidence Clip</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={stopRecording}
                  className="px-4 py-2 bg-slate-200 hover:bg-white text-slate-900 rounded-xl text-xs font-black flex items-center gap-1.5"
                >
                  <StopCircle className="w-4 h-4 text-rose-600" />
                  <span>Stop & Attach ({recordedSeconds}s)</span>
                </button>
              )}

              <span className="text-[11px] text-slate-400 font-mono">
                Auto-stops @ 15s
              </span>
            </div>
          )}
        </div>
      )}

      {/* MODE: PRESET SELECTOR / ATTACH OPTIONS */}
      {(mode === 'presets' || mode === 'upload') && !videoUrl && (
        <div className="space-y-3">
          {/* Action Row: Live Camera, File Upload, Preset selector */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              type="button"
              onClick={startCamera}
              className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 flex flex-col items-center justify-center gap-1.5 text-center transition group"
            >
              <div className="w-8 h-8 rounded-full bg-rose-500/20 text-rose-400 group-hover:bg-rose-500 group-hover:text-white flex items-center justify-center transition">
                <Camera className="w-4 h-4" />
              </div>
              <span className="font-bold text-white">Record Live (15s)</span>
              <span className="text-[10px] text-slate-400">Uses device camera</span>
            </button>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 flex flex-col items-center justify-center gap-1.5 text-center transition group"
            >
              <div className="w-8 h-8 rounded-full bg-sky-500/20 text-sky-400 group-hover:bg-sky-500 group-hover:text-white flex items-center justify-center transition">
                <Upload className="w-4 h-4" />
              </div>
              <span className="font-bold text-white">Upload Gallery Video</span>
              <span className="text-[10px] text-slate-400">Auto-capped to ≤15s</span>
            </button>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="video/*"
            className="hidden"
            onChange={handleFileUpload}
          />

          {/* Quick Realistic Clinical Field Presets (Great for immediate evaluation & demonstration) */}
          <div className="pt-2 border-t border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-slate-300 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Or pick a 10-15s Clinical Field Clip (Fast Demo):
              </span>
              <span className="text-[10px] text-slate-500">1-Click Tele-Evidence</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {PRESET_CLINICAL_CLIPS.map((preset, idx) => (
                <div
                  key={idx}
                  onClick={() => handleSelectPreset(preset)}
                  className="p-2 bg-slate-800/60 hover:bg-slate-800 rounded-xl border border-slate-700 cursor-pointer transition flex items-start gap-2.5 group"
                >
                  <img
                    src={preset.thumbnail}
                    alt={preset.title}
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 rounded-lg object-cover border border-slate-600 shrink-0"
                  />
                  <div className="min-w-0 flex-1 text-left">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-rose-400 font-mono">
                        {preset.duration}s
                      </span>
                      <Play className="w-3 h-3 text-slate-400 group-hover:text-emerald-400 transition" />
                    </div>
                    <p className="text-[11px] font-bold text-white truncate">{preset.title}</p>
                    <p className="text-[9px] text-slate-400 line-clamp-1 mt-0.5">{preset.condition}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
