import React from 'react';
import { useLivestock } from '../context/LivestockContext';
import { Skull, AlertOctagon, ShieldCheck, Plus, ExternalLink } from 'lucide-react';

interface MortalityModuleProps {
  onOpenReportMortality: () => void;
  onSelectAnimalById?: (id: string) => void;
}

export const MortalityModule: React.FC<MortalityModuleProps> = ({
  onOpenReportMortality,
  onSelectAnimalById,
}) => {
  const { animals } = useLivestock();

  const deceasedAnimals = animals.filter(
    a => a.healthStatus === 'Deceased' || a.mortalityRecord !== undefined
  );

  return (
    <div className="space-y-6" id="mortality-module-root">
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-slate-100 text-slate-800 text-[11px] font-bold px-2 py-0.5 rounded uppercase tracking-wider border border-slate-300">
                Bio-Safety & Disease Containment
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">
              Mortality Reporting & Carcass Disposal Protocol
            </h1>
            <p className="text-xs text-slate-600 mt-0.5">
              Strict bio-security tracking to prevent secondary disease propagation (Anthrax, HS, FMD) via mandatory certified deep-burial or incineration.
            </p>
          </div>

          <button
            onClick={onOpenReportMortality}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-rose-700 hover:bg-rose-600 text-white rounded-xl text-xs font-bold shadow-xs transition shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Report Mortality Event</span>
          </button>
        </div>
      </div>

      {/* Bio-Disposal Standard Guidelines Banner */}
      <div className="bg-amber-50 rounded-2xl border border-amber-200 p-4 sm:p-5 text-xs text-amber-950 flex flex-col sm:flex-row items-start gap-3">
        <AlertOctagon className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
        <div>
          <h4 className="font-extrabold text-sm text-amber-900">
            National Bio-Security Disposal Guidelines (Anthrax & HS Prevention)
          </h4>
          <p className="text-[11px] text-amber-800 mt-1 leading-relaxed">
            In cases of sudden bovine mortality with suspected Anthrax, DO NOT open the carcass. Immediate notification to the Veterinary Officer is mandatory. Carcasses must be buried at least 6 feet deep with a generous layer of quicklime (calcium oxide) and fenced off from stray dogs and scavengers.
          </p>
        </div>
      </div>

      {/* Recorded Events Table */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
        <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3">
          Recorded Mortality Log & Bio-Disposal Registry
        </h3>

        {deceasedAnimals.length > 0 ? (
          <div className="space-y-3">
            {deceasedAnimals.map(animal => (
              <div
                key={animal.id}
                className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-rose-700">{animal.id}</span>
                    <span className="font-bold text-slate-900">{animal.name} ({animal.breed})</span>
                    <span className="bg-rose-100 text-rose-800 text-[9px] font-black uppercase px-2 py-0.5 rounded">
                      Deceased
                    </span>
                  </div>
                  <p className="text-slate-600 text-[11px] mt-1">
                    Suspected Etiology: <strong>{animal.mortalityRecord?.suspectedCause || 'Peracute HS Outbreak'}</strong>
                  </p>
                  <p className="text-slate-500 text-[11px]">
                    Location: {animal.location.village}, {animal.location.district} ({animal.location.state}) • Owner: {animal.ownerName}
                  </p>
                </div>

                <div className="flex sm:flex-col items-end gap-1 shrink-0 text-right">
                  <span className="text-[11px] font-bold text-slate-700 bg-white px-2.5 py-1 rounded border border-slate-200">
                    Disposal: {animal.mortalityRecord?.carcassDisposalStatus || 'Buried with Lime'}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    Date: {animal.mortalityRecord?.date || '2024-09-12'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-8 text-center text-slate-400 text-xs">
            No mortality events currently registered in this local cluster.
          </div>
        )}
      </div>
    </div>
  );
};
