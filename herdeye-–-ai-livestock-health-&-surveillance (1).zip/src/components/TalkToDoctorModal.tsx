import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { useLanguage } from '../context/LanguageContext';
import { Animal } from '../types';
import { EvidenceVideoRecorder } from './EvidenceVideoRecorder';
import {
  PhoneCall,
  MessageSquare,
  Video,
  FileText,
  X,
  CheckCircle2,
  Clock,
  MapPin,
  ShieldCheck,
  Stethoscope,
  ChevronRight,
  Volume2,
} from 'lucide-react';

interface TalkToDoctorModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedAnimal?: Animal | null;
}

export const TalkToDoctorModal: React.FC<TalkToDoctorModalProps> = ({
  isOpen,
  onClose,
  selectedAnimal,
}) => {
  const { animals, addVeterinaryTreatment, reportSymptoms } = useLivestock();
  const { t, speakText } = useLanguage();

  const targetAnimal = selectedAnimal || animals[0];
  const [activeTab, setActiveTab] = useState<'overview' | 'send_video' | 'send_report'>('overview');
  const [videoSent, setVideoSent] = useState(false);
  const [reportSent, setReportSent] = useState(false);
  const [customNote, setCustomNote] = useState('');

  if (!isOpen) return null;

  const doctor = {
    name: t('doctor_name', 'డాక్టర్ వి. కే. శర్మ (MVSc Medicine)'),
    role: 'Senior Veterinary Polyclinic Surgeon',
    clinic: t('doctor_clinic', 'ప్రభుత్వ పశు వైద్యశాల, ఆనంద్ (Sub-Divisional Polyclinic)'),
    phone: '+91 98250 11982',
    status: 'Available On Duty • 08:00 AM - 06:00 PM',
    distance: '3.2 km from your farm (Mogri)',
  };

  const handleSendVideo = (videoUrl: string, durationSec: number) => {
    reportSymptoms({
      animalId: targetAnimal.id,
      reportedBy: 'Ramesh Patel (Farmer Direct)',
      reporterRole: 'farmer',
      reporterPhone: '+91 98250 11982',
      symptoms: ['15-Second Clinical Evidence Video Sent to Doctor'],
      severity: 'Moderate',
      onsetDate: new Date().toISOString().split('T')[0],
      notes: customNote || 'Farmer submitted 15s video for tele-triage diagnosis.',
      location: targetAnimal.location || {
        farmName: 'Shri Ram Dairy',
        village: 'Mogri',
        block: 'Anand',
        district: 'Anand',
        state: 'Gujarat',
        lat: 22.5645,
        lng: 72.9289,
      },
      videoUrl: videoUrl,
      videoDurationSeconds: durationSec,
    });
    setVideoSent(true);
    setTimeout(() => {
      setVideoSent(false);
      setActiveTab('overview');
    }, 2000);
  };

  const handleSendReport = () => {
    setReportSent(true);
    setTimeout(() => {
      setReportSent(false);
      setActiveTab('overview');
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/75 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border-4 border-sky-500 overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-sky-700 via-sky-600 to-indigo-700 p-5 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-2xl shadow-inner">
              👨‍⚕️
            </div>
            <div>
              <h3 className="font-extrabold text-lg sm:text-xl tracking-tight leading-tight">
                {t('btn_call_doctor', 'పశువుల డాక్టర్‌తో మాట్లాడండి')}
              </h3>
              <p className="text-sky-100 text-xs font-semibold">
                Veterinary Tele-Triage & Emergency Assistance
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => speakText(`${doctor.name}, ${doctor.clinic}`)}
              className="p-2 rounded-xl bg-white/20 hover:bg-white/30 text-white transition"
              title="Listen"
            >
              <Volume2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-black/20 hover:bg-black/30 text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Doctor Identity Card */}
        <div className="p-5 bg-sky-50/60 border-b border-sky-100 shrink-0">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  డ్యూటీలో ఉన్నారు (On Duty)
                </span>
                <span className="text-slate-400 text-xs flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-sky-600" />
                  {doctor.distance}
                </span>
              </div>
              <h4 className="text-base font-black text-slate-900">{doctor.name}</h4>
              <p className="text-xs text-slate-600">{doctor.clinic}</p>
            </div>
            <div className="w-12 h-12 rounded-full border-2 border-sky-300 overflow-hidden shrink-0 shadow-sm">
              <img
                src="https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=256&q=80"
                alt="Veterinarian"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Animal context badge */}
          {targetAnimal && (
            <div className="mt-3 bg-white p-2.5 rounded-xl border border-sky-200 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="text-lg">{targetAnimal.species === 'Buffalo' ? '🐃' : '🐄'}</span>
                <div>
                  <span className="font-bold text-slate-900">{targetAnimal.name}</span>
                  <span className="text-slate-400 ml-1.5">({targetAnimal.id})</span>
                </div>
              </div>
              <span className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${
                targetAnimal.healthStatus === 'Healthy'
                  ? 'bg-emerald-50 text-emerald-700'
                  : 'bg-rose-50 text-rose-700'
              }`}>
                {targetAnimal.healthStatus}
              </span>
            </div>
          )}
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4">
          {activeTab === 'overview' && (
            <>
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                సంప్రదింపు మార్గాలు (Direct Contact Methods):
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* 1. Direct Phone Call */}
                <a
                  href={`tel:${doctor.phone}`}
                  className="flex items-center gap-3.5 p-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-900/20 active:scale-95 transition"
                >
                  <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-xl shrink-0">
                    <PhoneCall className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <span className="text-sm font-black block">{t('btn_call', 'ఫోన్ చేయండి')}</span>
                    <span className="text-emerald-100 text-xs font-mono">{doctor.phone}</span>
                  </div>
                </a>

                {/* 2. WhatsApp Message */}
                <a
                  href={`https://wa.me/919825011982?text=${encodeURIComponent(
                    `Namaste Dr. Sharma, I am farmer Ramesh Patel from Mogri. I need assistance for my animal ${targetAnimal?.name} (${targetAnimal?.id}). Please advise.`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3.5 p-4 rounded-2xl bg-teal-700 hover:bg-teal-600 text-white shadow-md active:scale-95 transition"
                >
                  <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-xl shrink-0">
                    <MessageSquare className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <span className="text-sm font-black block">{t('btn_whatsapp', 'వాట్సాప్ సందేశం')}</span>
                    <span className="text-teal-100 text-xs">WhatsApp Chat</span>
                  </div>
                </a>

                {/* 3. Send 15s Evidence Video */}
                <button
                  onClick={() => setActiveTab('send_video')}
                  className="flex items-center gap-3.5 p-4 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white shadow-md shadow-rose-900/20 active:scale-95 transition text-left"
                >
                  <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-xl shrink-0">
                    <Video className="w-5 h-5 text-white animate-pulse" />
                  </div>
                  <div>
                    <span className="text-sm font-black block">{t('btn_send_video_doc', '15 సెకన్ల వీడియో పంపండి')}</span>
                    <span className="text-rose-100 text-xs">Doctor Video Review</span>
                  </div>
                </button>

                {/* 4. Send Health Report Summary */}
                <button
                  onClick={() => setActiveTab('send_report')}
                  className="flex items-center gap-3.5 p-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white shadow-md active:scale-95 transition text-left"
                >
                  <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-xl shrink-0">
                    <FileText className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <span className="text-sm font-black block">{t('btn_send_health_summary', 'ఆరోగ్య నివేదిక పంపండి')}</span>
                    <span className="text-slate-300 text-xs">Full Medical History</span>
                  </div>
                </button>
              </div>

              {/* National Animal Ambulance 1962 Box */}
              <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🚑</span>
                  <div>
                    <p className="text-xs font-black text-amber-950">
                      జాతీయ పశు అంబులెన్స్ హెల్ప్‌లైన్: 1962
                    </p>
                    <p className="text-[11px] text-amber-800">
                      టోల్ ఫ్రీ అత్యవసర సేవ (24x7 National Toll-Free)
                    </p>
                  </div>
                </div>
                <a
                  href="tel:1962"
                  className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold shrink-0"
                >
                  Call 1962
                </a>
              </div>
            </>
          )}

          {/* TAB: Send 15s Video */}
          {activeTab === 'send_video' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                  <Video className="w-4 h-4 text-rose-600" />
                  <span>డాక్టర్‌కు 15 సెకన్ల వీడియో పంపండి</span>
                </h4>
                <button
                  onClick={() => setActiveTab('overview')}
                  className="text-xs text-sky-700 font-bold hover:underline"
                >
                  వెనుకకు
                </button>
              </div>

              {videoSent ? (
                <div className="p-8 text-center bg-emerald-50 rounded-2xl border border-emerald-200">
                  <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center text-2xl mx-auto mb-2">
                    ✅
                  </div>
                  <h4 className="font-black text-emerald-900 text-base">వీడియో డాక్టర్‌కు పంపబడింది!</h4>
                  <p className="text-xs text-emerald-700 mt-1">
                    డాక్టర్ వి. కె. శర్మ పరిశీలించి సూచనలు అందిస్తారు.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <EvidenceVideoRecorder
                    onVideoSelected={(data) => {
                      handleSendVideo(data.videoUrl, data.durationSeconds);
                    }}
                    onClearVideo={() => setActiveTab('overview')}
                  />
                </div>
              )}
            </div>
          )}

          {/* TAB: Send Health Report */}
          {activeTab === 'send_report' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-slate-800" />
                  <span>పశువు ఆరోగ్య చరిత్రను డాక్టర్‌కు పంపండి</span>
                </h4>
                <button
                  onClick={() => setActiveTab('overview')}
                  className="text-xs text-sky-700 font-bold hover:underline"
                >
                  వెనుకకు
                </button>
              </div>

              {reportSent ? (
                <div className="p-8 text-center bg-emerald-50 rounded-2xl border border-emerald-200">
                  <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center text-2xl mx-auto mb-2">
                    ✅
                  </div>
                  <h4 className="font-black text-emerald-900 text-base">పూర్తి నివేదిక డాక్టర్‌కు చేరింది!</h4>
                  <p className="text-xs text-emerald-700 mt-1">
                    టీకాలు, ఉష్ణోగ్రత మరియు మునుపటి చికిత్స వివరాలు డాక్టర్ క్లినికల్ డెస్క్‌కు చేరాయి.
                  </p>
                </div>
              ) : (
                <div className="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs">
                  <div className="space-y-1.5">
                    <p className="font-bold text-slate-800">చేర్చబడే వివరాలు:</p>
                    <ul className="list-disc list-inside text-slate-600 space-y-1">
                      <li>పశువు గుర్తింపు: {targetAnimal.name} ({targetAnimal.id})</li>
                      <li>యాజమాన్యం: రమేష్ పటేల్, మోగ్రి, ఆనంద్</li>
                      <li>ప్రస్తుత పరిస్థితి: {targetAnimal.healthStatus}</li>
                      <li>టీకా పరిస్థితి: {targetAnimal.vaccinationRecords?.length || 0} టీకాలు నమోదయ్యాయి</li>
                      <li>చివరి పరీక్ష: {targetAnimal.lastChecked}</li>
                    </ul>
                  </div>

                  <button
                    onClick={handleSendReport}
                    className="w-full py-3 bg-sky-700 hover:bg-sky-600 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 active:scale-95 shadow-md"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>డాక్టర్ డెస్క్‌కు సమర్పించండి</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            సురక్షిత వెటర్నరీ నెట్‌వర్క్
          </span>
          <button
            onClick={onClose}
            className="text-slate-800 font-bold hover:underline"
          >
            మూసివేయి (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
