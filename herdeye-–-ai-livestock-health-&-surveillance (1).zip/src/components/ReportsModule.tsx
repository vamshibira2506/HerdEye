import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { SymptomReport } from '../types';
import { FileText, Plus, User, MapPin, Calendar, Clock, AlertTriangle, ShieldCheck, Video, Play } from 'lucide-react';
import { EvidenceVideoModal } from './EvidenceVideoModal';

interface ReportsModuleProps {
  onOpenNewReport: () => void;
  onSelectAnimalById?: (id: string) => void;
}

export const ReportsModule: React.FC<ReportsModuleProps> = ({
  onOpenNewReport,
  onSelectAnimalById,
}) => {
  const { symptomReports, updateReportStatus, animals } = useLivestock();
  const [severityFilter, setSeverityFilter] = useState<'All' | 'Critical' | 'Severe' | 'Moderate' | 'Mild'>('All');
  const [selectedVideoReport, setSelectedVideoReport] = useState<SymptomReport | null>(null);

  const filtered = symptomReports.filter(rep => {
    if (severityFilter !== 'All' && rep.severity !== severityFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6" id="reports-module-root">
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-amber-100 text-amber-900 text-[11px] font-bold px-2 py-0.5 rounded uppercase tracking-wider border border-amber-300">
                Community Syndromic Reporting
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">
              Farmer & Field Worker Symptom Incident Reports
            </h1>
            <p className="text-xs text-slate-600 mt-0.5">
              Crowdsourced early reporting of abnormal livestock behavior, vesicles, salivation, and mortalities across dairy cooperatives.
            </p>
          </div>

          <button
            onClick={onOpenNewReport}
            className="flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold shadow-xs transition shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Submit New Symptom Report</span>
          </button>
        </div>
      </div>

      {/* Reports Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map(report => (
          <div
            key={report.id}
            className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-3 text-xs"
          >
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-slate-900 text-xs">
                    Animal ID: {report.animalId}
                  </span>
                  <span
                    className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                      report.severity === 'Critical'
                        ? 'bg-rose-600 text-white'
                        : report.severity === 'Severe'
                        ? 'bg-rose-100 text-rose-800'
                        : report.severity === 'Moderate'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {report.severity}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-slate-500 text-[11px] mt-0.5">
                  <User className="w-3.5 h-3.5" />
                  <span>{report.reportedBy}</span>
                  <span>•</span>
                  <MapPin className="w-3.5 h-3.5" />
                  <span>{report.location.village}, {report.location.district}</span>
                </div>
              </div>

              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                  report.status === 'Action Taken'
                    ? 'bg-emerald-100 text-emerald-800'
                    : report.status === 'Reviewed'
                    ? 'bg-sky-100 text-sky-800'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                {report.status}
              </span>
            </div>

            {/* Symptoms list */}
            <div>
              <span className="text-slate-400 text-[10px] uppercase font-bold block mb-1">
                Reported Symptoms:
              </span>
              <div className="flex flex-wrap gap-1">
                {report.symptoms.map((s, idx) => (
                  <span
                    key={idx}
                    className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded font-medium text-[11px]"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>

            {/* Notes */}
            <p className="text-slate-700 bg-slate-50 p-2.5 rounded-lg border border-slate-200 italic">
              "{report.notes}"
            </p>

            {/* Evidence Video or Photo */}
            <div className="space-y-2">
              {report.videoUrl && (
                <div className="flex items-center justify-between p-2.5 bg-slate-900 text-white rounded-xl border border-slate-700">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-rose-600/20 text-rose-400 flex items-center justify-center border border-rose-500/30">
                      <Video className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">
                          15s Clinical Evidence Video
                        </span>
                        <span className="bg-rose-500 text-white text-[9px] font-mono px-1.5 py-0.2 rounded font-black">
                          {report.videoDurationSeconds || 14}s
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 block truncate max-w-xs">
                        {report.videoTitle || 'Transmitted directly to attending veterinarian'}
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setSelectedVideoReport(report)}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold flex items-center gap-1 transition shadow-xs"
                  >
                    <Play className="w-3 h-3 ml-0.5" />
                    <span>Watch Clip</span>
                  </button>
                </div>
              )}

              {report.photoUrl && !report.videoUrl && (
                <div className="flex items-center gap-3">
                  <img
                    src={report.photoUrl}
                    alt="Evidence"
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 rounded-lg object-cover border border-slate-200 shrink-0"
                  />
                  <div className="text-[11px] text-slate-500">
                    <span className="font-bold text-slate-700 block">Submitted Macro Photo</span>
                    <span>Onset date: {report.onsetDate} • Logged: {report.timestamp}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Action Bar */}
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
              {onSelectAnimalById && (
                <button
                  onClick={() => onSelectAnimalById(report.animalId)}
                  className="text-emerald-800 hover:text-emerald-950 font-bold text-[11px]"
                >
                  View Animal Record →
                </button>
              )}

              {report.status === 'Submitted' && (
                <button
                  onClick={() => updateReportStatus(report.id, 'Reviewed')}
                  className="px-3 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded font-bold text-[11px]"
                >
                  Mark Under Vet Review
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
      {/* 15s Evidence Video Modal */}
      {selectedVideoReport && (
        <EvidenceVideoModal
          isOpen={true}
          onClose={() => setSelectedVideoReport(null)}
          videoUrl={selectedVideoReport.videoUrl}
          videoDurationSeconds={selectedVideoReport.videoDurationSeconds || 14}
          videoTitle={selectedVideoReport.videoTitle}
          reportedBy={selectedVideoReport.reportedBy}
          reporterPhone={selectedVideoReport.reporterPhone}
          animalId={selectedVideoReport.animalId}
          animalName={animals.find(a => a.id === selectedVideoReport.animalId)?.name || 'Livestock Patient'}
          symptoms={selectedVideoReport.symptoms}
          location={`${selectedVideoReport.location.village}, ${selectedVideoReport.location.district} (${selectedVideoReport.location.state})`}
          timestamp={selectedVideoReport.timestamp}
        />
      )}
    </div>
  );
};
