import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { HealthAlert } from '../types';
import {
  AlertOctagon,
  ShieldAlert,
  CheckCircle2,
  Filter,
  Sparkles,
  ArrowRight,
  Stethoscope,
  Eye,
} from 'lucide-react';

interface AlertsModuleProps {
  onSelectAnimalById?: (id: string) => void;
}

export const AlertsModule: React.FC<AlertsModuleProps> = ({ onSelectAnimalById }) => {
  const { alerts, dismissAlert, animals } = useLivestock();
  const [priorityFilter, setPriorityFilter] = useState<'All' | 'High' | 'Medium' | 'Low'>('All');

  const filtered = alerts.filter(al => {
    if (priorityFilter !== 'All' && al.priority !== priorityFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6" id="alerts-module-root">
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-rose-100 text-rose-800 text-[11px] font-bold px-2 py-0.5 rounded uppercase tracking-wider border border-rose-300 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-rose-600" />
                <span>AI Automated Syndromic Surveillance Engine</span>
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">
              Epidemic Early-Warning & Triage Alerts
            </h1>
            <p className="text-xs text-slate-600 mt-0.5">
              Continuous computer vision telemetry and rumination deviation detectors flagging acute contagious outbreaks before visible death.
            </p>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl text-xs font-bold">
            {(['All', 'High', 'Medium', 'Low'] as const).map(p => (
              <button
                key={p}
                onClick={() => setPriorityFilter(p)}
                className={`px-3 py-1.5 rounded-lg transition ${
                  priorityFilter === p ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Alert Feed Cards */}
      <div className="space-y-4">
        {filtered.map(alert => {
          const animal = animals.find(a => a.id === alert.animalId);
          return (
            <div
              key={alert.id}
              className={`p-5 rounded-2xl border transition shadow-2xs ${
                alert.priority === 'High'
                  ? 'bg-rose-50/40 border-rose-200'
                  : alert.priority === 'Medium'
                  ? 'bg-amber-50/40 border-amber-200'
                  : 'bg-emerald-50/30 border-emerald-200'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      alert.priority === 'High'
                        ? 'bg-rose-600 text-white'
                        : alert.priority === 'Medium'
                        ? 'bg-amber-600 text-white'
                        : 'bg-emerald-700 text-white'
                    }`}
                  >
                    <AlertOctagon className="w-5 h-5" />
                  </div>

                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono text-xs font-bold text-slate-900">
                        {alert.animalId}
                      </span>
                      {animal && (
                        <span className="text-xs font-semibold text-slate-600">
                          ({animal.name} • {animal.breed})
                        </span>
                      )}
                      <span
                        className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                          alert.priority === 'High'
                            ? 'bg-rose-600 text-white'
                            : alert.priority === 'Medium'
                            ? 'bg-amber-600 text-white'
                            : 'bg-emerald-700 text-white'
                        }`}
                      >
                        {alert.priority} Priority
                      </span>
                    </div>

                    <h3 className="text-base font-extrabold text-slate-900">
                      {alert.suspectedDisease}
                    </h3>
                    <p className="text-xs text-slate-600 mt-1 max-w-2xl">
                      {alert.aiObservations}
                    </p>
                  </div>
                </div>

                <div className="flex sm:flex-col items-end gap-1.5 shrink-0">
                  <span className="text-xs font-black text-slate-800 bg-white px-2.5 py-1 rounded-lg border border-slate-200">
                    AI Confidence: {alert.confidenceScore}%
                  </span>
                  <span className="text-[10px] text-slate-500">{alert.detectedAt}</span>
                </div>
              </div>

              {/* Recommended Action & Trigger */}
              <div className="mt-4 pt-3 border-t border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-800">Protocol:</span>
                  <span className="text-slate-700 bg-white px-2.5 py-1 rounded-md border border-slate-200">
                    {alert.recommendedAction}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => dismissAlert(alert.id)}
                    className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg font-bold"
                  >
                    Acknowledge
                  </button>
                  {onSelectAnimalById && alert.animalId && (
                    <button
                      onClick={() => onSelectAnimalById(alert.animalId)}
                      className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg font-bold flex items-center gap-1 shadow-2xs"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Inspect Animal Profile</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
