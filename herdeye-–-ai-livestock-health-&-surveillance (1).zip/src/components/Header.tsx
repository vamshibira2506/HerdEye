import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { useLanguage } from '../context/LanguageContext';
import { SUPPORTED_LANGUAGES, SupportedLanguage } from '../utils/translations';
import { HerdEyeLogo } from './HerdEyeLogo';
import {
  Wifi,
  WifiOff,
  RefreshCw,
  Bell,
  Search,
  ChevronDown,
  Globe,
  Mic,
} from 'lucide-react';
import { UserRole } from '../types';

interface HeaderProps {
  onOpenOfflineDrawer: () => void;
  onOpenVoiceAssistant?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenOfflineDrawer, onOpenVoiceAssistant }) => {
  const {
    role,
    setRole,
    isOnline,
    toggleOnlineStatus,
    offlineQueue,
    alerts,
    searchQuery,
    setSearchQuery,
    setActiveTab,
  } = useLivestock();

  const { language, setLanguage, currentLangMeta, t } = useLanguage();

  const [roleMenuOpen, setRoleMenuOpen] = useState(false);
  const [langMenuOpen, setLangMenuOpen] = useState(false);

  const pendingAlertsCount = alerts.filter(a => a.status === 'New').length;

  const roleLabels: Record<UserRole, { title: string; badge: string; color: string; desc: string }> = {
    farmer: {
      title: 'Ramesh Patel (Dairy Farmer)',
      badge: t('role_farmer', 'రైతు'),
      color: 'bg-emerald-100 text-emerald-800 border-emerald-300',
      desc: 'Shri Ram Dairy, Mogri, Anand (Gujarat)',
    },
    field_worker: {
      title: 'Anjali Patel (Pashu Sakhi / ASHA)',
      badge: t('role_field_worker', 'పశు సఖి'),
      color: 'bg-amber-100 text-amber-800 border-amber-300',
      desc: 'Anand District Block Surveillance Unit',
    },
    veterinarian: {
      title: 'Dr. V. K. Sharma (MVSc Medicine)',
      badge: t('role_veterinarian', 'పశువుల డాక్టర్'),
      color: 'bg-sky-100 text-sky-800 border-sky-300',
      desc: 'Sub-Divisional Veterinary Polyclinic & Hospital',
    },
    government: {
      title: 'Dr. P. K. Verma (Director DAH&D)',
      badge: t('role_government', 'ప్రభుత్వ అధికారి'),
      color: 'bg-indigo-100 text-indigo-800 border-indigo-300',
      desc: 'National Livestock Disease Surveillance Mission',
    },
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs" id="herdeye-main-header">
      {/* Top Government Strip */}
      <div className="bg-emerald-950 text-emerald-100 px-3 sm:px-6 py-1 text-[11px] flex items-center justify-between font-medium border-b border-emerald-900/60">
        <div className="flex items-center gap-2 overflow-hidden">
          <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-pulse"></span>
          <span className="font-semibold text-white tracking-wide truncate">
            MINISTRY OF FISHERIES, ANIMAL HUSBANDRY & DAIRYING
          </span>
          <span className="hidden md:inline text-emerald-400/60">|</span>
          <span className="hidden md:inline text-emerald-300/90 truncate">
            National Animal Disease Surveillance System (NADSS)
          </span>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <span className="text-[10px] bg-emerald-900/80 px-2 py-0.5 rounded text-emerald-200 border border-emerald-800 hidden sm:inline">
            SIH Hackathon Edition
          </span>
          <span className="text-emerald-400 text-[10px]">v2.4.0-AI</span>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="px-3 sm:px-6 py-2.5 flex items-center justify-between gap-3">
        {/* Left: Brand Logo */}
        <div className="flex items-center gap-3">
          <HerdEyeLogo size="md" />
        </div>

        {/* Center: Global Search Bar */}
        <div className="hidden lg:flex items-center flex-1 max-w-md mx-4">
          <div className="relative w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search Tag ID (e.g. IN-GJ-2024), breed, village, or disease..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-100/90 text-xs text-slate-800 pl-9 pr-4 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 transition"
              id="global-tag-search-input"
            />
          </div>
        </div>

        {/* Right Action Tools */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Offline/Online Network Indicator & Toggle */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg border border-slate-200">
            <button
              onClick={toggleOnlineStatus}
              title="Click to simulate Online / Offline field conditions"
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold transition ${
                isOnline
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-rose-600 text-white shadow-xs animate-pulse'
              }`}
              id="network-status-toggle-btn"
            >
              {isOnline ? (
                <>
                  <Wifi className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Online</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Offline</span>
                </>
              )}
            </button>

            {/* Offline Sync Outbox Drawer Trigger */}
            <button
              onClick={onOpenOfflineDrawer}
              className="relative p-1.5 text-slate-600 hover:text-emerald-800 hover:bg-slate-200/70 rounded transition"
              title="Open Offline Synchronization Outbox"
              id="offline-outbox-btn"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${offlineQueue.length > 0 ? 'text-amber-600' : 'text-slate-500'}`} />
              {offlineQueue.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-amber-500 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center border border-white">
                  {offlineQueue.length}
                </span>
              )}
            </button>
          </div>

          {/* Quick Alert Bell */}
          <button
            onClick={() => setActiveTab('alerts')}
            className="relative p-2 text-slate-600 hover:text-emerald-800 hover:bg-slate-100 rounded-lg transition"
            title="High-Priority Outbreak & Health Alerts"
            id="header-alert-bell"
          >
            <Bell className="w-4 h-4" />
            {pendingAlertsCount > 0 && (
              <span className="absolute top-1 right-1 bg-rose-600 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center animate-bounce">
                {pendingAlertsCount}
              </span>
            )}
          </button>

          {/* Quick Voice Assistant Mic */}
          {onOpenVoiceAssistant && (
            <button
              onClick={onOpenVoiceAssistant}
              className="p-2 text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-lg border border-amber-200 transition flex items-center gap-1 text-xs font-bold"
              title="Voice Assistant"
            >
              <Mic className="w-4 h-4 text-amber-600" />
              <span className="hidden xl:inline">Voice</span>
            </button>
          )}

          {/* Multilingual Selector (8 Indian Languages) */}
          <div className="relative">
            <button
              onClick={() => setLangMenuOpen(!langMenuOpen)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-100 rounded-lg border border-slate-200"
              id="lang-selector-btn"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-700" />
              <span>{currentLangMeta.flag} {currentLangMeta.nativeName}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>
            {langMenuOpen && (
              <div className="absolute right-0 mt-1.5 w-52 bg-white border border-slate-200 rounded-xl shadow-xl py-1 z-50 text-xs max-h-72 overflow-y-auto">
                <div className="px-3 py-1.5 text-[10px] font-black uppercase text-slate-400 border-b border-slate-100">
                  Select Language (భాష)
                </div>
                {SUPPORTED_LANGUAGES.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => {
                      setLanguage(l.code);
                      setLangMenuOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 hover:bg-slate-100 flex items-center justify-between ${
                      language === l.code ? 'font-black text-emerald-800 bg-emerald-50' : 'text-slate-700'
                    }`}
                  >
                    <span>{l.flag} {l.nativeName}</span>
                    <span className="text-[10px] text-slate-400">{l.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Role Switcher Pill Dropdown */}
          <div className="relative">
            <button
              onClick={() => setRoleMenuOpen(!roleMenuOpen)}
              className="flex items-center gap-2 pl-2 pr-3 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition"
              id="role-switcher-dropdown-btn"
            >
              <div className="w-7 h-7 rounded-full bg-emerald-800 text-white flex items-center justify-center font-bold text-xs">
                {role === 'farmer' ? '👨‍🌾' : role === 'field_worker' ? '🩺' : role === 'veterinarian' ? '👨‍⚕️' : '🏛️'}
              </div>
              <div className="hidden sm:flex flex-col text-left">
                <span className="text-xs font-bold text-slate-900 leading-tight">
                  {roleLabels[role].badge}
                </span>
                <span className="text-[10px] text-slate-500 truncate max-w-[120px]">
                  {roleLabels[role].title.split(' ')[0]}
                </span>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {roleMenuOpen && (
              <div className="absolute right-0 mt-2 w-72 bg-white border border-slate-200 rounded-xl shadow-xl py-2 z-50 text-xs divide-y divide-slate-100">
                <div className="px-3 py-2 bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  Switch Simulation Role (SIH Demo)
                </div>
                {(['farmer', 'field_worker', 'veterinarian', 'government'] as UserRole[]).map(r => (
                  <button
                    key={r}
                    onClick={() => {
                      setRole(r);
                      setRoleMenuOpen(false);
                      setActiveTab('dashboard');
                    }}
                    className={`w-full text-left px-3.5 py-2.5 flex items-start gap-2.5 hover:bg-slate-50 transition ${
                      role === r ? 'bg-emerald-50/70 border-l-4 border-emerald-700' : ''
                    }`}
                  >
                    <span className="text-lg shrink-0">
                      {r === 'farmer' ? '👨‍🌾' : r === 'field_worker' ? '🩺' : r === 'veterinarian' ? '👨‍⚕️' : '🏛️'}
                    </span>
                    <div className="flex flex-col">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-900">{roleLabels[r].badge}</span>
                        {role === r && (
                          <span className="text-[9px] bg-emerald-700 text-white px-1.5 py-0.2 rounded font-bold">
                            Active
                          </span>
                        )}
                      </div>
                      <span className="text-slate-600 font-medium text-[11px]">{roleLabels[r].title}</span>
                      <span className="text-[10px] text-slate-400">{roleLabels[r].desc}</span>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
