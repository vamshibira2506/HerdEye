import React, { useState, useEffect, useRef } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Mic, MicOff, Volume2, Sparkles, X, ArrowRight, CheckCircle2, AlertCircle } from 'lucide-react';

interface VoiceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAction: (action: {
    type: 'symptom_report' | 'call_doctor' | 'vaccination' | 'camera_check' | 'view_animals';
    initialSymptom?: string;
    transcript?: string;
  }) => void;
}

export const VoiceAssistantModal: React.FC<VoiceAssistantModalProps> = ({
  isOpen,
  onClose,
  onAction,
}) => {
  const { t, language, currentLangMeta, speakText, isSpeaking, stopSpeaking } = useLanguage();
  const [isListening, setIsListening] = useState<boolean>(false);
  const [transcript, setTranscript] = useState<string>('');
  const [understoodAction, setUnderstoodAction] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const recognitionRef = useRef<any>(null);

  // Quick preset voice prompts tailored to current language
  const voiceSuggestions = [
    { text: t('voice_sample_1', 'నా గేదె తినడం లేదు'), action: 'symptom_report', symptom: 'not_eating', icon: '🍚' },
    { text: t('voice_sample_2', 'పశువుకు జ్వరం ఉంది'), action: 'symptom_report', symptom: 'sick_fever', icon: '🤒' },
    { text: t('voice_sample_3', 'నా ఆవు కుంటుతోంది'), action: 'symptom_report', symptom: 'limping', icon: '🚶' },
    { text: t('voice_sample_4', 'డాక్టర్ను పిలవాలి'), action: 'call_doctor', icon: '👨‍⚕️' },
    { text: t('btn_vaccination', 'టీకాలు ఎప్పుడు?'), action: 'vaccination', icon: '💉' },
    { text: t('btn_camera_check', 'కెమెరాతో తనిఖీ చేయండి'), action: 'camera_check', icon: '📷' },
  ];

  // Initialize Speech Recognition if browser supports it
  useEffect(() => {
    if (!isOpen) {
      stopListening();
      setTranscript('');
      setUnderstoodAction(null);
      return;
    }

    // Auto announce on open
    speakText(t('voice_listening', 'వింటున్నాము... మాట్లాడండి'));

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = currentLangMeta.speechCode;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const currentText = Array.from(event.results)
          .map((result: any) => result[0].transcript)
          .join(' ');
        setTranscript(currentText);

        if (event.results[0].isFinal) {
          processVoiceInput(currentText);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      try {
        recognition.start();
      } catch (e) {
        // May already be active
      }
    } else {
      setIsListening(false);
    }

    return () => {
      stopListening();
    };
  }, [isOpen, currentLangMeta.speechCode]);

  const startListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.start();
      } catch (e) {
        console.warn('Cannot start recognition', e);
      }
    }
    setIsListening(true);
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        // ignore
      }
    }
    setIsListening(false);
  };

  const processVoiceInput = (text: string) => {
    setIsProcessing(true);
    const lower = text.toLowerCase();

    // Intent recognition for multilingual phrases
    if (
      lower.includes('తినడం లేదు') ||
      lower.includes('తింటలేదు') ||
      lower.includes('खाना') ||
      lower.includes('eating') ||
      lower.includes('ತಿನ್ನುತ್ತಿಲ್ಲ') ||
      lower.includes('சாப்பிடவில்லை') ||
      lower.includes('തീറ്റ') ||
      lower.includes('चारा') ||
      lower.includes('खात नाही')
    ) {
      setUnderstoodAction('symptom_not_eating');
      speakText(t('sym_not_eating', 'మేత తినడం లేదు - నివేదికను తెరుస్తున్నాము'));
      setTimeout(() => {
        onAction({ type: 'symptom_report', initialSymptom: 'not_eating', transcript: text });
        onClose();
      }, 1000);
    } else if (
      lower.includes('జ్వరం') ||
      lower.includes('బుఖార్') ||
      lower.includes('बुखार') ||
      lower.includes('fever') ||
      lower.includes('ಜ್ವರ') ||
      lower.includes('காய்ச்சல்') ||
      lower.includes('പനി') ||
      lower.includes('ताप')
    ) {
      setUnderstoodAction('symptom_fever');
      speakText(t('sym_sick_fever', 'జ్వరం - నివేదికను తెరుస్తున్నాము'));
      setTimeout(() => {
        onAction({ type: 'symptom_report', initialSymptom: 'sick_fever', transcript: text });
        onClose();
      }, 1000);
    } else if (
      lower.includes('కుంటు') ||
      lower.includes('నడవ') ||
      lower.includes('लंगड़ा') ||
      lower.includes('limp') ||
      lower.includes('walk') ||
      lower.includes('ಕುಂಟ') ||
      lower.includes('நொண்டி') ||
      lower.includes('മുടന്ത') ||
      lower.includes('लंगड')
    ) {
      setUnderstoodAction('symptom_limping');
      speakText(t('sym_limping', 'కుంటుతోంది - నివేదికను తెరుస్తున్నాము'));
      setTimeout(() => {
        onAction({ type: 'symptom_report', initialSymptom: 'limping', transcript: text });
        onClose();
      }, 1000);
    } else if (
      lower.includes('డాక్టర్') ||
      lower.includes('doctor') ||
      lower.includes('डॉक्टर') ||
      lower.includes('ವೈದ್ಯ') ||
      lower.includes('மருத்துவர்') ||
      lower.includes('ഡോക്ടർ')
    ) {
      setUnderstoodAction('call_doctor');
      speakText(t('btn_call_doctor', 'పశువుల డాక్టర్‌కు అనుసంధానిస్తున్నాము'));
      setTimeout(() => {
        onAction({ type: 'call_doctor', transcript: text });
        onClose();
      }, 1000);
    } else if (
      lower.includes('టీకా') ||
      lower.includes('vaccin') ||
      lower.includes('टीका') ||
      lower.includes('ಲಸಿಕೆ') ||
      lower.includes('தடுப்பூசி') ||
      lower.includes('വാക്സിൻ') ||
      lower.includes('लस')
    ) {
      setUnderstoodAction('vaccination');
      speakText(t('btn_vaccination', 'టీకాల పట్టిక'));
      setTimeout(() => {
        onAction({ type: 'vaccination', transcript: text });
        onClose();
      }, 1000);
    } else if (
      lower.includes('కెమెరా') ||
      lower.includes('camera') ||
      lower.includes('कैमरा') ||
      lower.includes('ಕ್ಯಾಮೆರಾ') ||
      lower.includes('கேமரா')
    ) {
      setUnderstoodAction('camera_check');
      speakText(t('btn_camera_check', 'కెమెరాతో తనిఖీ చేయండి'));
      setTimeout(() => {
        onAction({ type: 'camera_check', transcript: text });
        onClose();
      }, 1000);
    } else {
      // General symptom report default
      setUnderstoodAction('general_report');
      setTimeout(() => {
        onAction({ type: 'symptom_report', transcript: text });
        onClose();
      }, 1200);
    }
    setIsProcessing(false);
  };

  const handleChipClick = (item: typeof voiceSuggestions[0]) => {
    setTranscript(item.text);
    speakText(item.text);
    processVoiceInput(item.text);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border-4 border-emerald-500 overflow-hidden flex flex-col">
        {/* Header with Language indicator */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-700 px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center text-xl shadow-inner">
              🎤
            </div>
            <div>
              <h3 className="font-extrabold text-lg leading-tight flex items-center gap-2">
                <span>{t('btn_speak_problem', 'సమస్య మాట్లాడండి')}</span>
                <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full font-bold">
                  {currentLangMeta.nativeName}
                </span>
              </h3>
              <p className="text-emerald-100 text-xs">
                {t('voice_tap_prompt', 'మైక్ నొక్కి మాట్లాడండి లేదా కింద ఉన్న వాటిని తాకండి')}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              stopSpeaking();
              onClose();
            }}
            className="w-9 h-9 rounded-full bg-black/20 hover:bg-black/30 flex items-center justify-center text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Center Mic & Wave Animation */}
        <div className="p-6 flex flex-col items-center justify-center bg-radial from-emerald-50 to-white text-center">
          <div className="relative mb-4">
            {isListening && (
              <>
                <span className="absolute inset-0 rounded-full bg-emerald-400 opacity-75 animate-ping" />
                <span className="absolute -inset-3 rounded-full border-4 border-emerald-300 animate-pulse" />
              </>
            )}
            <button
              onClick={isListening ? stopListening : startListening}
              className={`relative z-10 w-24 h-24 rounded-full flex items-center justify-center shadow-xl transition-transform active:scale-95 ${
                isListening
                  ? 'bg-rose-600 text-white shadow-rose-500/50 ring-4 ring-rose-300'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/40'
              }`}
            >
              {isListening ? <Mic className="w-12 h-12 animate-pulse" /> : <Mic className="w-12 h-12" />}
            </button>
          </div>

          <div className="text-sm font-bold text-slate-800 mb-1">
            {isListening ? (
              <span className="text-rose-600 flex items-center gap-1.5 justify-center animate-pulse">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-600" />
                {t('voice_listening', 'వింటున్నాము... మాట్లాడండి')}
              </span>
            ) : (
              <span className="text-slate-600">
                {t('voice_tap_prompt', 'మాట్లాడటానికి మైక్ నొక్కండి')}
              </span>
            )}
          </div>

          {/* Transcript / Spoken Output */}
          <div className="min-h-[56px] w-full bg-slate-100 rounded-2xl p-3 my-2 border border-slate-200 flex items-center justify-center">
            {transcript ? (
              <p className="text-slate-900 font-bold text-base leading-snug">
                "{transcript}"
              </p>
            ) : (
              <p className="text-slate-400 text-xs italic">
                {t('voice_listening', 'ఉదాహరణ: "నా గేదె తినడం లేదు" లేదా "డాక్టర్ను పిలవాలి"')}
              </p>
            )}
          </div>

          {understoodAction && (
            <div className="mt-1 px-3 py-1.5 bg-emerald-100 border border-emerald-300 text-emerald-800 text-xs font-bold rounded-xl flex items-center gap-1.5 animate-bounce">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>గుర్తించబడింది • Opening screen...</span>
            </div>
          )}
        </div>

        {/* Quick Tap Voice Suggestions (One-touch for low literacy) */}
        <div className="p-5 bg-slate-50 border-t border-slate-200">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-xs font-black uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>లేదా వీటిని ఒకసారి తాకండి (One Tap)</span>
            </span>
            <button
              onClick={() => speakText(t('voice_tap_prompt', 'మీరు నేరుగా తాకవచ్చు'))}
              className="text-xs text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-1"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>{t('voice_listen', 'వినండి')}</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            {voiceSuggestions.map((item, idx) => (
              <button
                key={idx}
                onClick={() => handleChipClick(item)}
                className="flex items-center gap-2 p-3 bg-white hover:bg-emerald-50 hover:border-emerald-400 text-slate-800 rounded-2xl border-2 border-slate-200 text-left transition shadow-2xs group active:scale-95"
              >
                <span className="text-2xl shrink-0 group-hover:scale-110 transition-transform">
                  {item.icon}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-extrabold text-slate-900 group-hover:text-emerald-900 truncate">
                    {item.text}
                  </p>
                  <span className="text-[10px] text-slate-400 font-medium flex items-center gap-0.5">
                    Tap to run <ArrowRight className="w-2.5 h-2.5" />
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Footer info */}
        <div className="px-6 py-3 bg-slate-100 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>🌾 రైతు మిత్ర వాయిస్ అసిస్టెంట్</span>
          <button
            onClick={() => {
              stopSpeaking();
              onClose();
            }}
            className="text-slate-700 font-bold hover:underline"
          >
            మూసివేయి (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
