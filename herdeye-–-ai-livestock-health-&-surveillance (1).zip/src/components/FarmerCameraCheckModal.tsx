import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { useLanguage } from '../context/LanguageContext';
import { Animal } from '../types';
import { EvidenceVideoRecorder } from './EvidenceVideoRecorder';
import {
  Camera,
  Video,
  Upload,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  Volume2,
  PhoneCall,
  X,
  Eye,
  RefreshCw,
} from 'lucide-react';

interface FarmerCameraCheckModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedAnimal?: Animal | null;
  onOpenTalkToDoctor: () => void;
}

export const FarmerCameraCheckModal: React.FC<FarmerCameraCheckModalProps> = ({
  isOpen,
  onClose,
  selectedAnimal,
  onOpenTalkToDoctor,
}) => {
  const { animals } = useLivestock();
  const { t, speakText } = useLanguage();

  const animal = selectedAnimal || animals[0];
  const [mode, setMode] = useState<'scan' | 'result' | 'record_video'>('scan');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [photoUrl, setPhotoUrl] = useState<string>(
    'https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?auto=format&fit=crop&w=1000&q=80'
  );

  const startAnalysis = () => {
    setIsAnalyzing(true);
    setTimeout(() => {
      setIsAnalyzing(false);
      setMode('result');
    }, 1800);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/75 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border-4 border-emerald-500 overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-700 via-teal-700 to-emerald-800 p-5 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/20 flex items-center justify-center text-xl shadow-inner">
              📷
            </div>
            <div>
              <h3 className="font-extrabold text-lg sm:text-xl tracking-tight leading-tight">
                {t('cam_title', 'కెమెరాతో పశువును తనిఖీ చేయండి')}
              </h3>
              <p className="text-emerald-100 text-xs font-semibold">
                {animal?.name || 'Animal'} ({animal?.species}) • Visual Health Check
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                if (mode === 'result') {
                  speakText(
                    `${t('cam_possible_concern')}. ${t('cam_notice_movement')}. ${t('cam_step_1')}. ${t('cam_step_2')}. ${t('cam_step_3')}`
                  );
                } else {
                  speakText(t('cam_title'));
                }
              }}
              className="p-2 rounded-xl bg-white/20 hover:bg-white/30 text-white transition flex items-center gap-1 text-xs font-bold"
              title="Listen"
            >
              <Volume2 className="w-4 h-4" />
              <span className="hidden sm:inline">{t('voice_listen', 'వినండి')}</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-black/20 hover:bg-black/30 text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4">
          {mode === 'scan' && (
            <div className="space-y-4">
              {/* Camera Preview Area */}
              <div className="relative rounded-2xl overflow-hidden bg-slate-950 aspect-video max-h-56 flex items-center justify-center border-2 border-slate-700">
                <img
                  src={photoUrl}
                  alt="Animal Check"
                  className="w-full h-full object-cover"
                />

                {isAnalyzing ? (
                  <div className="absolute inset-0 bg-emerald-950/60 backdrop-blur-xs flex flex-col items-center justify-center text-white p-4">
                    <RefreshCw className="w-10 h-10 animate-spin text-emerald-400 mb-2" />
                    <p className="font-extrabold text-sm text-center">
                      కెమెరా పరిశీలిస్తోంది... (AI Analyzing Movement & Posture)
                    </p>
                    <p className="text-xs text-emerald-200 mt-1">
                      నడక, నిలబడే తీరు, వాపు మరియు కంటి స్థితిని తనిఖీ చేస్తున్నాము...
                    </p>
                  </div>
                ) : (
                  <div className="absolute bottom-3 left-3 right-3 bg-slate-900/80 backdrop-blur-md rounded-xl p-2 text-white flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1.5 font-bold">
                      <Eye className="w-4 h-4 text-emerald-400" />
                      లైవ్ కెమెరా దృష్టిలో ఉంది (In Frame)
                    </span>
                    <span className="text-[10px] text-slate-300">Barn Camera 1</span>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  disabled={isAnalyzing}
                  onClick={startAnalysis}
                  className="py-3.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-2xl font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-700/20 active:scale-95"
                >
                  <Sparkles className="w-5 h-5 text-amber-300" />
                  <span>తనిఖీ చేయండి (Start Check)</span>
                </button>

                <button
                  onClick={() => setMode('record_video')}
                  className="py-3.5 bg-rose-600 hover:bg-rose-500 text-white rounded-2xl font-black text-xs flex items-center justify-center gap-2 shadow-md active:scale-95"
                >
                  <Video className="w-4 h-4" />
                  <span>{t('cam_record_video', '15 సెకన్ల వీడియో తీయండి')}</span>
                </button>
              </div>

              {/* Guidance note */}
              <div className="bg-emerald-50 p-3.5 rounded-2xl border border-emerald-100 text-xs text-emerald-900">
                <span className="font-bold">చిట్కా:</span> పశువు పూర్తి శరీరం, ముఖ్యంగా కాళ్లు మరియు ముఖం స్పష్టంగా వెలుతురులో కనిపించేలా కెమెరా ఉంచండి.
              </div>
            </div>
          )}

          {/* Mode: Result Display (Non-diagnostic, farmer friendly) */}
          {mode === 'result' && (
            <div className="space-y-4 animate-fade-in">
              {/* Alert Badge: Non-diagnostic per guidelines */}
              <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-300 flex items-start gap-3">
                <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-black text-amber-950 text-sm sm:text-base leading-tight">
                    {t('cam_possible_concern', 'సాధ్యమయ్యే ఆరోగ్య సమస్య (Possible Health Concern)')}
                  </h4>
                  <p className="text-xs text-amber-800 mt-1 font-medium leading-relaxed">
                    ⚠️ {t('cam_notice_movement', 'కెమెరా పశువు నడక లేదా కదలికలో మార్పును గుర్తించింది.')}
                  </p>
                </div>
              </div>

              {/* "What you can do" Box */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <h5 className="font-extrabold text-xs uppercase tracking-wider text-slate-700 mb-2">
                  {t('cam_what_to_do', 'మీరు చేయవలసిన పనులు:')}
                </h5>
                <div className="space-y-2 text-xs text-slate-700 font-semibold">
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold shrink-0 text-[11px]">
                      1
                    </span>
                    <span>{t('cam_step_1', '1. పశువును దగ్గరగా గమనించండి.')}</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold shrink-0 text-[11px]">
                      2
                    </span>
                    <span>{t('cam_step_2', '2. 15 సెకన్ల చిన్న వీడియో తీయండి.')}</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold shrink-0 text-[11px]">
                      3
                    </span>
                    <span>{t('cam_step_3', '3. సమస్య తగ్గకపోతే పశువుల డాక్టర్‌కు చూపించండి.')}</span>
                  </div>
                </div>
              </div>

              {/* Direct Actions: Listen, Call Doctor, Send Video */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={() => {
                    onClose();
                    onOpenTalkToDoctor();
                  }}
                  className="py-3.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-2xl font-black text-xs flex items-center justify-center gap-2 shadow-md active:scale-95"
                >
                  <PhoneCall className="w-4 h-4" />
                  <span>డాక్టర్‌ను సంప్రదించండి</span>
                </button>

                <button
                  onClick={() => setMode('record_video')}
                  className="py-3.5 bg-rose-600 hover:bg-rose-500 text-white rounded-2xl font-black text-xs flex items-center justify-center gap-2 shadow-md active:scale-95"
                >
                  <Video className="w-4 h-4" />
                  <span>{t('cam_contact_vet', '15 సెకన్ల వీడియో పంపండి')}</span>
                </button>
              </div>

              <div className="text-center pt-1">
                <button
                  onClick={() => setMode('scan')}
                  className="text-xs text-slate-500 hover:text-slate-800 font-bold underline"
                >
                  మళ్లీ తనిఖీ చేయండి (Re-scan)
                </button>
              </div>
            </div>
          )}

          {/* Mode: 15s Video Recorder */}
          {mode === 'record_video' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
                  <Video className="w-4 h-4 text-rose-600" />
                  <span>15 సెకన్ల వీడియో రికార్డింగ్</span>
                </h4>
                <button
                  onClick={() => setMode('scan')}
                  className="text-xs text-emerald-700 font-bold hover:underline"
                >
                  వెనుకకు
                </button>
              </div>

              <EvidenceVideoRecorder
                onVideoSelected={(data) => {
                  onClose();
                  onOpenTalkToDoctor();
                }}
                onClearVideo={() => setMode('scan')}
              />
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <span className="text-[11px] text-slate-400">
            * AI గుర్తింపు కేవలం ప్రాథమిక పరిశీలన మాత్రమే. తుది నిర్ణయం డాక్టర్‌దే.
          </span>
          <button
            onClick={onClose}
            className="text-slate-700 font-bold hover:underline"
          >
            పూర్తయింది
          </button>
        </div>
      </div>
    </div>
  );
};
