import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { FlaskConical, CheckCircle2, Clock, Plus, Filter, Search } from 'lucide-react';

export const LabReferralModule: React.FC = () => {
  const { animals } = useLivestock();
  const [searchTerm, setSearchTerm] = useState('');

  // Collect all lab referrals
  const allLabs = animals.flatMap(a =>
    a.labReferrals.map(lab => ({
      ...lab,
      animalName: a.name,
      animalId: a.id,
      breed: a.breed,
      owner: a.ownerName,
    }))
  );

  return (
    <div className="space-y-6" id="lab-referral-module-root">
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-indigo-100 text-indigo-800 text-[11px] font-bold px-2 py-0.5 rounded uppercase tracking-wider border border-indigo-300">
                Diagnostic Laboratory Network
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">
              Laboratory Samples & Confirmatory Testing
            </h1>
            <p className="text-xs text-slate-600 mt-0.5">
              Live specimen chain-of-custody tracking across State Animal Disease Diagnostic Labs, NIHSAD, and IVRI.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {allLabs.map(lab => (
          <div
            key={lab.id}
            className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs space-y-2.5 text-xs"
          >
            <div className="flex items-center justify-between">
              <span className="font-mono font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                {lab.sampleId}
              </span>
              <span
                className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                  lab.status === 'Completed'
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                {lab.status}
              </span>
            </div>

            <div>
              <h3 className="font-extrabold text-sm text-slate-900">{lab.testRequested}</h3>
              <p className="text-slate-500 text-[11px]">
                Animal: {lab.animalName} ({lab.animalId})
              </p>
            </div>

            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 space-y-1 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-500">Specimen:</span>
                <span className="font-bold text-slate-800">{lab.sampleType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Lab:</span>
                <span className="font-bold text-slate-800">{lab.labName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Urgency:</span>
                <span className="font-bold text-rose-600">{lab.urgency}</span>
              </div>
            </div>

            {lab.resultSummary ? (
              <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-900">
                <span className="font-bold text-[10px] uppercase block mb-0.5">Laboratory Result:</span>
                <p className="font-medium text-[11px]">{lab.resultSummary}</p>
              </div>
            ) : (
              <div className="p-2 bg-slate-100 rounded text-slate-500 text-[11px] text-center">
                Sample undergoing RT-PCR / Serology analysis.
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
