import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { AlertTriangle, X, Upload, Camera, Send, Check, Video, Image as ImageIcon } from 'lucide-react';
import { EvidenceVideoRecorder, RecordedVideoData } from './EvidenceVideoRecorder';

interface SymptomReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  preSelectedAnimalId?: string;
  defaultToVideo?: boolean;
}

export const SymptomReportModal: React.FC<SymptomReportModalProps> = ({
  isOpen,
  onClose,
  preSelectedAnimalId,
  defaultToVideo = true,
}) => {
  const { animals, reportSymptoms, role, isOnline } = useLivestock();

  const [targetAnimalId, setTargetAnimalId] = useState(preSelectedAnimalId || animals[0]?.id || '');
  const [severity, setSeverity] = useState<'Mild' | 'Moderate' | 'Severe' | 'Critical'>('Severe');
  const [onsetDate, setOnsetDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');
  const [selectedPhoto, setSelectedPhoto] = useState<string>(
    'https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?auto=format&fit=crop&w=800&q=80'
  );
  const [evidenceTab, setEvidenceTab] = useState<'video' | 'photo'>(defaultToVideo ? 'video' : 'photo');
  const [recordedVideo, setRecordedVideo] = useState<RecordedVideoData | null>({
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    durationSeconds: 14,
    title: 'Oral Frothing & Stringy Salivation (14s)',
    source: 'preset',
  });

  const symptomChecklist = [
    'High Fever (>39.5°C)',
    'Excessive stringy salivation & oral froth',
    'Vesicles / blisters on dental pad or tongue',
    'Lameness & interdigital hoof erosions',
    'Sudden drop in daily milk yield (>40%)',
    'Firm nodular skin lesions on neck/body (LSD)',
    'Rapid breathing / panting in shade',
    'Submandibular neck edema (Throat swelling)',
    'Swollen painful udder quarter (Mastitis)',
    'Off-feed & cessation of rumination',
  ];

  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([
    'High Fever (>39.5°C)',
    'Excessive stringy salivation & oral froth',
  ]);

  if (!isOpen) return null;

  const targetAnimal = animals.find(a => a.id === targetAnimalId) || animals[0];

  const toggleSymptom = (sym: string) => {
    if (selectedSymptoms.includes(sym)) {
      setSelectedSymptoms(selectedSymptoms.filter(s => s !== sym));
    } else {
      setSelectedSymptoms([...selectedSymptoms, sym]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedSymptoms.length === 0) return;

    reportSymptoms({
      animalId: targetAnimalId,
      reportedBy:
        role === 'farmer'
          ? 'Ramesh Patel (Farmer)'
          : role === 'field_worker'
          ? 'Anjali Patel (Field Worker / Pashu Sakhi)'
          : 'Dr. V. K. Sharma (Veterinarian)',
      reporterRole: role,
      reporterPhone: '+91 98251 44102',
      symptoms: selectedSymptoms,
      severity,
      onsetDate,
      notes: notes.trim() || 'Urgent visual and behavioral anomaly reported via mobile portal with 15s video clip.',
      photoUrl: selectedPhoto,
      videoUrl: recordedVideo?.videoUrl,
      videoDurationSeconds: recordedVideo?.durationSeconds,
      videoTitle: recordedVideo?.title,
      location: targetAnimal ? targetAnimal.location : {
        farmName: 'Local Dairy',
        village: 'Mogri',
        block: 'Anand',
        district: 'Anand',
        state: 'Gujarat',
        lat: 22.5645,
        lng: 72.9289,
      },
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-3 sm:p-4 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden my-auto">
        {/* Header */}
        <div className="bg-amber-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-amber-800 text-amber-200 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">
                Report Clinical Symptoms & Syndromic Event
              </h3>
              <p className="text-xs text-amber-200">
                {isOnline ? 'Direct Broadcast to District Vet Desk' : 'Offline Queue Mode Active'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-300 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 text-xs">
          {/* Target Animal */}
          <div>
            <label className="block font-bold text-slate-700 mb-1">Select Affected Livestock *</label>
            <select
              value={targetAnimalId}
              onChange={e => setTargetAnimalId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900 font-semibold"
            >
              {animals.map(a => (
                <option key={a.id} value={a.id}>
                  {a.id} — {a.name} ({a.breed}) — {a.healthStatus}
                </option>
              ))}
            </select>
          </div>

          {/* Severity & Onset */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Clinical Severity Level *</label>
              <select
                value={severity}
                onChange={e => setSeverity(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900 font-bold"
              >
                <option value="Mild">Mild (Slight reduction in activity)</option>
                <option value="Moderate">Moderate (Mild fever, feed drop)</option>
                <option value="Severe">Severe (Acute fever, lesions, salivation)</option>
                <option value="Critical">Critical (Recumbency, collapse risk)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Date of First Symptom Onset</label>
              <input
                type="date"
                value={onsetDate}
                onChange={e => setOnsetDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900"
              />
            </div>
          </div>

          {/* Symptoms Multi-Checklist */}
          <div>
            <label className="block font-bold text-slate-700 mb-1.5">
              Observed Symptoms Checklist (Select all that apply) *
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {symptomChecklist.map((sym, idx) => {
                const checked = selectedSymptoms.includes(sym);
                return (
                  <div
                    key={idx}
                    onClick={() => toggleSymptom(sym)}
                    className={`p-2.5 rounded-lg border cursor-pointer flex items-center gap-2 transition ${
                      checked
                        ? 'bg-amber-50 border-amber-400 text-amber-950 font-bold shadow-2xs'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded flex items-center justify-center text-white text-[10px] shrink-0 ${
                        checked ? 'bg-amber-600' : 'border border-slate-300 bg-white'
                      }`}
                    >
                      {checked && <Check className="w-3 h-3" />}
                    </div>
                    <span className="text-[11px] leading-tight">{sym}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Observations & Farmer Notes */}
          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Field Notes / Additional Observations
            </label>
            <textarea
              rows={3}
              placeholder="Describe feed refusal, behavioral changes, herd contact history, or sudden milk slump..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500/30"
            />
          </div>

          {/* Evidence Attachment Section: 15s Video Clip to Doctor & Photo */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="block font-bold text-slate-800">
                Clinical Evidence for Attending Veterinarian *
              </label>
              <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs">
                <button
                  type="button"
                  onClick={() => setEvidenceTab('video')}
                  className={`px-3 py-1 rounded-md font-bold flex items-center gap-1.5 transition ${
                    evidenceTab === 'video'
                      ? 'bg-rose-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Video className="w-3.5 h-3.5" />
                  <span>15s Video Clip</span>
                </button>
                <button
                  type="button"
                  onClick={() => setEvidenceTab('photo')}
                  className={`px-3 py-1 rounded-md font-bold flex items-center gap-1.5 transition ${
                    evidenceTab === 'photo'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>Macro Still Photo</span>
                </button>
              </div>
            </div>

            {evidenceTab === 'video' ? (
              <EvidenceVideoRecorder
                onVideoSelected={data => setRecordedVideo(data)}
                initialVideoUrl={recordedVideo?.videoUrl}
                initialDuration={recordedVideo?.durationSeconds || 14}
                initialTitle={recordedVideo?.title}
                onClearVideo={() => setRecordedVideo(null)}
              />
            ) : (
              <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <img
                  src={selectedPhoto}
                  alt="evidence preview"
                  referrerPolicy="no-referrer"
                  className="w-16 h-16 rounded-lg object-cover border border-slate-300 shrink-0"
                />
                <div className="flex-1 text-[11px] text-slate-500">
                  <span className="font-bold text-slate-800 block text-xs">
                    Macro Oral & Skin Lesion Still Frame
                  </span>
                  <span>
                    High-resolution diagnostic photo attached for AI syndromic analysis and Dr. Sharma's inspection.
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={selectedSymptoms.length === 0}
              className="px-5 py-2.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-bold shadow-md flex items-center gap-1.5 transition disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              <span>Submit Report to Veterinary Hub</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
