import React, { useState } from 'react';
import { Animal } from '../types';
import { useLivestock } from '../context/LivestockContext';
import {
  X,
  HeartPulse,
  Syringe,
  Stethoscope,
  FlaskConical,
  AlertTriangle,
  Clock,
  MapPin,
  Calendar,
  CheckCircle2,
  FileText,
  User,
  Video,
  ShieldAlert,
  Play,
} from 'lucide-react';
import { EvidenceVideoModal } from './EvidenceVideoModal';

interface AnimalDetailModalProps {
  animal: Animal | null;
  onClose: () => void;
  onOpenReportSymptom: (animalId: string) => void;
}

export const AnimalDetailModal: React.FC<AnimalDetailModalProps> = ({
  animal,
  onClose,
  onOpenReportSymptom,
}) => {
  if (!animal) return null;

  const { symptomReports } = useLivestock();
  const [activeSubTab, setActiveSubTab] = useState<'vitals' | 'vaccinations' | 'treatments' | 'labs'>('vitals');
  const [showVideoModal, setShowVideoModal] = useState(false);

  // Check if any report has video
  const reportWithVideo = symptomReports.find(r => r.animalId === animal.id && r.videoUrl) ||
    (animal.id === 'IN-GJ-2024-9182' ? {
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      videoDurationSeconds: 14,
      videoTitle: 'Excessive mouth froth & salivation evidence clip (14s)',
      reportedBy: 'Ramesh Patel (Farmer)',
      reporterPhone: '+91 98251 44102',
      symptoms: animal.currentSymptoms,
    } : null);

  return (
    <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-3 sm:p-4 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden my-auto">
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-5 flex items-start justify-between">
          <div className="flex gap-4 items-start">
            <img
              src={animal.photoUrl}
              alt={animal.name}
              referrerPolicy="no-referrer"
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl object-cover border-2 border-slate-700 shrink-0"
            />
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <span className="font-mono text-xs font-black bg-emerald-700 text-white px-2 py-0.5 rounded">
                  {animal.id}
                </span>
                <span
                  className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${
                    animal.healthStatus === 'Healthy'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : animal.healthStatus === 'Under Observation'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      : animal.healthStatus === 'Deceased'
                      ? 'bg-slate-700 text-slate-300'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  }`}
                >
                  {animal.healthStatus}
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-black text-white">{animal.name}</h2>
              <p className="text-xs text-slate-300">
                {animal.species} • {animal.breed} • {animal.ageYears}y {animal.ageMonths}m • {animal.sex} • {animal.weightKg} kg
              </p>
              <p className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
                <MapPin className="w-3 h-3 text-emerald-400" />
                {animal.location.farmName}, {animal.location.village}, {animal.location.district} ({animal.location.state})
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sub-tab Navigation */}
        <div className="flex items-center gap-2 px-5 py-2.5 bg-slate-100 border-b border-slate-200 text-xs font-bold overflow-x-auto">
          <button
            onClick={() => setActiveSubTab('vitals')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
              activeSubTab === 'vitals' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <HeartPulse className="w-4 h-4 text-rose-600" />
            <span>Health & AI Vitals</span>
          </button>

          <button
            onClick={() => setActiveSubTab('vaccinations')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
              activeSubTab === 'vaccinations' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Syringe className="w-4 h-4 text-emerald-600" />
            <span>Vaccinations ({animal.vaccinationRecords.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('treatments')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
              activeSubTab === 'treatments' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Stethoscope className="w-4 h-4 text-sky-600" />
            <span>Vet Treatments ({animal.treatmentHistory.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('labs')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
              activeSubTab === 'labs' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FlaskConical className="w-4 h-4 text-indigo-600" />
            <span>Lab Samples ({animal.labReferrals.length})</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4 text-xs">
          {activeSubTab === 'vitals' && (
            <>
              {/* Primary Vitals Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-400 block font-semibold uppercase">Body Temperature</span>
                  <span className={`text-base font-black ${animal.bodyTemperatureC > 39.5 ? 'text-rose-600' : 'text-slate-800'}`}>
                    {animal.bodyTemperatureC} °C
                  </span>
                  <span className="text-[10px] text-slate-400 block">Normal: 38.5 - 39.2°C</span>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-400 block font-semibold uppercase">Daily Rumination</span>
                  <span className={`text-base font-black ${animal.ruminationMinutesPerDay < 250 ? 'text-rose-600' : 'text-slate-800'}`}>
                    {animal.ruminationMinutesPerDay} min/d
                  </span>
                  <span className="text-[10px] text-slate-400 block">Normal: 420-500 min</span>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-400 block font-semibold uppercase">Feed Intake</span>
                  <span className="text-base font-black text-slate-800">{animal.feedIntakeKg} kg</span>
                  <span className="text-[10px] text-slate-400 block">Normal: ~20-22 kg</span>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-400 block font-semibold uppercase">AI Risk Index</span>
                  <span className={`text-base font-black ${animal.riskScore > 70 ? 'text-rose-600' : animal.riskScore > 40 ? 'text-amber-600' : 'text-emerald-700'}`}>
                    {animal.riskScore}/100
                  </span>
                  <span className="text-[10px] text-slate-400 block">{animal.riskPriority} Priority</span>
                </div>
              </div>

              {/* Behavior & Posture Status */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <span className="text-xs font-bold text-slate-800 uppercase block mb-1">
                  Observed Posture & Gait:
                </span>
                <p className="text-slate-700 font-medium">{animal.postureStatus}</p>
                <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Last Automated Telemetry Check: {animal.lastChecked}</span>
                </div>
              </div>

              {/* Detected Symptoms */}
              <div>
                <h4 className="font-bold text-slate-900 uppercase text-xs mb-2">Detected Clinical Symptoms</h4>
                {animal.currentSymptoms.length > 0 ? (
                  <div className="flex flex-wrap gap-1.5">
                    {animal.currentSymptoms.map((sym, i) => (
                      <span
                        key={i}
                        className="bg-rose-50 text-rose-800 border border-rose-200 px-2.5 py-1 rounded-lg font-semibold"
                      >
                        ⚠️ {sym}
                      </span>
                    ))}
                  </div>
                ) : (
                  <p className="text-emerald-700 font-medium">No acute symptoms reported or detected.</p>
                )}
              </div>

              {/* Farmer 15-Second Clinical Evidence Video */}
              {reportWithVideo && (
                <div className="p-3.5 bg-slate-900 text-white rounded-xl border border-slate-700 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="bg-rose-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded-full flex items-center gap-1 shadow-xs">
                      <Video className="w-3 h-3" />
                      <span>Farmer Evidence Video (15s Clip)</span>
                    </span>
                    <span className="text-[11px] font-mono text-emerald-400 font-bold">
                      {reportWithVideo.videoDurationSeconds || 14}s Video
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-3">
                    <p className="text-xs text-slate-300">
                      {reportWithVideo.videoTitle || '15-second clinical diagnostic video specimen.'}
                    </p>
                    <button
                      type="button"
                      onClick={() => setShowVideoModal(true)}
                      className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shrink-0 transition shadow-xs"
                    >
                      <Play className="w-3.5 h-3.5 ml-0.5" />
                      <span>Play 15s Clip</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Visible Abnormalities */}
              {animal.visibleAbnormalities.length > 0 && (
                <div>
                  <h4 className="font-bold text-slate-900 uppercase text-xs mb-2">
                    Computer Vision Flagged Abnormalities
                  </h4>
                  <ul className="space-y-1.5">
                    {animal.visibleAbnormalities.map((abn, i) => (
                      <li key={i} className="p-2 bg-amber-50 text-amber-900 rounded border border-amber-200">
                        • {abn}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Mortality Record if Deceased */}
              {animal.mortalityRecord && (
                <div className="p-4 bg-rose-50 border border-rose-300 rounded-xl">
                  <div className="flex items-center gap-2 text-rose-900 font-bold mb-1">
                    <ShieldAlert className="w-4 h-4 text-rose-700" />
                    <span>Official Mortality Record</span>
                  </div>
                  <p className="text-slate-800">
                    <strong>Suspected Cause:</strong> {animal.mortalityRecord.suspectedCause}
                  </p>
                  <p className="text-slate-700 mt-1">
                    <strong>Date of Event:</strong> {animal.mortalityRecord.date}
                  </p>
                  <p className="text-slate-700 mt-1">
                    <strong>Carcass Disposal Protocol:</strong> {animal.mortalityRecord.carcassDisposalStatus}
                  </p>
                </div>
              )}
            </>
          )}

          {activeSubTab === 'vaccinations' && (
            <div className="space-y-2.5">
              {animal.vaccinationRecords.length > 0 ? (
                animal.vaccinationRecords.map(vac => (
                  <div key={vac.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-xs">{vac.vaccineName}</span>
                        <span
                          className={`text-[9px] font-black uppercase px-1.5 py-0.2 rounded ${
                            vac.status === 'Done'
                              ? 'bg-emerald-100 text-emerald-800'
                              : vac.status === 'Due Soon'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {vac.status}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-0.5">
                        Target: <strong>{vac.targetDisease}</strong> • Batch: <span className="font-mono">{vac.batchNumber}</span>
                      </p>
                      <p className="text-[11px] text-slate-500">
                        Administered: {vac.administeredDate} • Due Date: {vac.nextDueDate}
                      </p>
                      <span className="text-[10px] text-slate-400">By: {vac.administeredBy}</span>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-slate-500 py-6 text-center">No vaccination history logged for this animal.</p>
              )}
            </div>
          )}

          {activeSubTab === 'treatments' && (
            <div className="space-y-3">
              {animal.treatmentHistory.length > 0 ? (
                animal.treatmentHistory.map(trt => (
                  <div key={trt.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                    <div className="flex justify-between items-center text-[11px] text-slate-500 mb-1">
                      <span className="font-bold text-slate-800">{trt.date}</span>
                      <span>{trt.veterinarianName}</span>
                    </div>
                    <h5 className="font-bold text-slate-900">{trt.diagnosis}</h5>
                    <p className="text-slate-700 mt-1">
                      <strong>Rx Prescribed:</strong> {trt.medications}
                    </p>
                    <p className="text-slate-600 italic mt-1">Notes: "{trt.notes}"</p>
                    {trt.followUpDate && (
                      <span className="inline-block mt-2 text-[10px] bg-sky-100 text-sky-800 px-2 py-0.5 rounded font-bold">
                        Follow-up: {trt.followUpDate}
                      </span>
                    )}
                  </div>
                ))
              ) : (
                <p className="text-slate-500 py-6 text-center">No previous veterinary interventions recorded.</p>
              )}
            </div>
          )}

          {activeSubTab === 'labs' && (
            <div className="space-y-3">
              {animal.labReferrals.length > 0 ? (
                animal.labReferrals.map(lab => (
                  <div key={lab.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                    <div className="flex justify-between items-center text-[11px] text-slate-500 mb-1">
                      <span className="font-mono font-bold text-indigo-700">{lab.sampleId}</span>
                      <span
                        className={`text-[9px] font-black uppercase px-1.5 py-0.2 rounded ${
                          lab.status === 'Completed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {lab.status}
                      </span>
                    </div>
                    <h5 className="font-bold text-slate-900">{lab.testRequested}</h5>
                    <p className="text-slate-600 mt-0.5">
                      Specimen: <strong>{lab.sampleType}</strong> • Lab: {lab.labName}
                    </p>
                    {lab.resultSummary && (
                      <div className="mt-2 p-2 bg-emerald-50 border border-emerald-200 rounded text-emerald-900 font-semibold text-[11px]">
                        Result: {lab.resultSummary}
                      </div>
                    )}
                  </div>
                ))
              ) : (
                <p className="text-slate-500 py-6 text-center">No laboratory diagnostic referrals active.</p>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold transition"
          >
            Close Profile
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onOpenReportSymptom(animal.id);
              }}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-1.5"
            >
              <Video className="w-4 h-4 text-white" />
              <span>Send 15s Video to Doctor</span>
            </button>
            <button
              onClick={() => {
                onClose();
                onOpenReportSymptom(animal.id);
              }}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-1.5"
            >
              <AlertTriangle className="w-4 h-4" />
              <span>Report Symptom</span>
            </button>
          </div>
        </div>
      </div>

      {/* 15s Evidence Video Modal */}
      {showVideoModal && reportWithVideo && (
        <EvidenceVideoModal
          isOpen={true}
          onClose={() => setShowVideoModal(false)}
          videoUrl={reportWithVideo.videoUrl}
          videoDurationSeconds={reportWithVideo.videoDurationSeconds || 14}
          videoTitle={reportWithVideo.videoTitle}
          reportedBy={reportWithVideo.reportedBy || animal.ownerName}
          reporterPhone={reportWithVideo.reporterPhone || animal.ownerContact}
          animalId={animal.id}
          animalName={animal.name}
          symptoms={reportWithVideo.symptoms || animal.currentSymptoms}
          location={`${animal.location.village}, ${animal.location.district} (${animal.location.state})`}
        />
      )}
    </div>
  );
};
