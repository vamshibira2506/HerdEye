import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { AnimalSpecies } from '../types';
import { PlusCircle, X, Camera, MapPin, Tag } from 'lucide-react';

interface AnimalRegisterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AnimalRegisterModal: React.FC<AnimalRegisterModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { registerAnimal, isOnline } = useLivestock();

  const [name, setName] = useState('');
  const [species, setSpecies] = useState<AnimalSpecies>('Buffalo');
  const [breed, setBreed] = useState('Murrah Buffalo');
  const [ageYears, setAgeYears] = useState(4);
  const [ageMonths, setAgeMonths] = useState(2);
  const [sex, setSex] = useState<'Female' | 'Male'>('Female');
  const [weightKg, setWeightKg] = useState(480);
  const [lactationStatus, setLactationStatus] = useState<'Lactating' | 'Dry' | 'Heifer' | 'Bull'>('Lactating');
  const [shedNumber, setShedNumber] = useState('Shed A-05');
  const [state, setState] = useState('Gujarat');
  const [district, setDistrict] = useState('Anand');
  const [block, setBlock] = useState('Anand');
  const [village, setVillage] = useState('Mogri');
  const [farmName, setFarmName] = useState('Shri Ram Dairy Farm');
  const [ownerName, setOwnerName] = useState('Ramesh Patel');
  const [ownerContact, setOwnerContact] = useState('+91 98251 44102');

  const photoPresets = [
    'https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1527153857715-3908f2ae5e81?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1596733430284-f7437764b1a9?auto=format&fit=crop&w=800&q=80',
  ];

  const [selectedPhoto, setSelectedPhoto] = useState(photoPresets[0]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    registerAnimal({
      name: name.trim() || `${breed} #${Math.floor(100 + Math.random() * 900)}`,
      species,
      breed,
      ageYears: Number(ageYears),
      ageMonths: Number(ageMonths),
      sex,
      weightKg: Number(weightKg),
      lactationStatus,
      shedNumber,
      location: {
        farmName,
        village,
        block,
        district,
        state,
        lat: 22.5645,
        lng: 72.9289,
      },
      ownerName,
      ownerContact,
      photoUrl: selectedPhoto,
      healthStatus: 'Healthy',
      riskScore: 10,
      riskPriority: 'Low',
      currentSymptoms: [],
      activityScore: 90,
      ruminationMinutesPerDay: 460,
      feedIntakeKg: 20,
      bodyTemperatureC: 38.6,
      postureStatus: 'Standing Alert & Grazing Normally',
      visibleAbnormalities: [],
      vaccinationRecords: [],
      treatmentHistory: [],
      labReferrals: [],
      lastChecked: 'Just registered',
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-3 sm:p-4 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden my-auto">
        {/* Header */}
        <div className="bg-emerald-950 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-emerald-800 text-emerald-300 flex items-center justify-center">
              <Tag className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">
                Register New Bovine (NDLM / Ear-Tag)
              </h3>
              <p className="text-xs text-emerald-300">
                {isOnline ? 'Online Cloud Enrollment' : 'Offline Registration (Queued in Local Cache)'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Animal Identifier / Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Kaveri / Gir-04"
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Species Type *</label>
              <select
                value={species}
                onChange={e => {
                  const val = e.target.value as AnimalSpecies;
                  setSpecies(val);
                  setBreed(val === 'Buffalo' ? 'Murrah Buffalo' : 'Gir Cow');
                }}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900 font-semibold"
              >
                <option value="Buffalo">Buffalo (Bubalus bubalis)</option>
                <option value="Cattle">Cattle / Cow (Bos indicus)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Indigenous Breed *</label>
              <select
                value={breed}
                onChange={e => setBreed(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900"
              >
                {species === 'Buffalo' ? (
                  <>
                    <option value="Murrah Buffalo">Murrah Buffalo</option>
                    <option value="Jaffarabadi Buffalo">Jaffarabadi Buffalo</option>
                    <option value="Mehsana Buffalo">Mehsana Buffalo</option>
                    <option value="Surti Buffalo">Surti Buffalo</option>
                    <option value="Nili-Ravi Buffalo">Nili-Ravi Buffalo</option>
                  </>
                ) : (
                  <>
                    <option value="Gir Cow">Gir Cow</option>
                    <option value="Sahiwal Cattle">Sahiwal Cattle</option>
                    <option value="Kankrej Cattle">Kankrej Cattle</option>
                    <option value="Red Sindhi">Red Sindhi</option>
                    <option value="Crossbred HF/Jersey">Crossbred HF/Jersey</option>
                  </>
                )}
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Age (Years & Months)</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  min="0"
                  max="20"
                  value={ageYears}
                  onChange={e => setAgeYears(Number(e.target.value))}
                  className="w-1/2 bg-slate-50 border border-slate-200 rounded-lg px-2 py-2 text-slate-900"
                  placeholder="Yrs"
                />
                <input
                  type="number"
                  min="0"
                  max="11"
                  value={ageMonths}
                  onChange={e => setAgeMonths(Number(e.target.value))}
                  className="w-1/2 bg-slate-50 border border-slate-200 rounded-lg px-2 py-2 text-slate-900"
                  placeholder="Mths"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Live Weight (kg)</label>
              <input
                type="number"
                min="50"
                max="1000"
                value={weightKg}
                onChange={e => setWeightKg(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Sex</label>
              <select
                value={sex}
                onChange={e => setSex(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900"
              >
                <option value="Female">Female</option>
                <option value="Male">Male</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Lactation Stage</label>
              <select
                value={lactationStatus}
                onChange={e => setLactationStatus(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900"
              >
                <option value="Lactating">Lactating</option>
                <option value="Dry">Dry</option>
                <option value="Heifer">Heifer</option>
                <option value="Bull">Bull</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Shed / Pen ID</label>
              <input
                type="text"
                value={shedNumber}
                onChange={e => setShedNumber(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900"
              />
            </div>
          </div>

          {/* Location & Ownership */}
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
            <span className="font-bold text-slate-800 uppercase text-[11px] block">
              Farm Location & Owner Coordinates
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div>
                <label className="block text-slate-500 text-[10px]">State</label>
                <input
                  type="text"
                  value={state}
                  onChange={e => setState(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded px-2 py-1"
                />
              </div>
              <div>
                <label className="block text-slate-500 text-[10px]">District</label>
                <input
                  type="text"
                  value={district}
                  onChange={e => setDistrict(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded px-2 py-1"
                />
              </div>
              <div>
                <label className="block text-slate-500 text-[10px]">Block</label>
                <input
                  type="text"
                  value={block}
                  onChange={e => setBlock(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded px-2 py-1"
                />
              </div>
              <div>
                <label className="block text-slate-500 text-[10px]">Village</label>
                <input
                  type="text"
                  value={village}
                  onChange={e => setVillage(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded px-2 py-1"
                />
              </div>
            </div>
          </div>

          {/* Photo Selection */}
          <div>
            <label className="block font-bold text-slate-700 mb-2">Select Live Photo Asset</label>
            <div className="grid grid-cols-4 gap-2">
              {photoPresets.map((p, idx) => (
                <div
                  key={idx}
                  onClick={() => setSelectedPhoto(p)}
                  className={`aspect-square rounded-xl overflow-hidden cursor-pointer border-2 transition ${
                    selectedPhoto === p ? 'border-emerald-600 ring-2 ring-emerald-600/30' : 'border-slate-200 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={p} alt="bovine option" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl font-bold shadow-md flex items-center gap-1.5 transition"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Register & Generate Tag</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
