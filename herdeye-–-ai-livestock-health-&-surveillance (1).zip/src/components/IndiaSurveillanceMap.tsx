import React, { useState } from 'react';
import { OutbreakCluster } from '../types';
import { MapPin, AlertTriangle, ShieldCheck, Layers, ZoomIn } from 'lucide-react';

interface IndiaSurveillanceMapProps {
  clusters: OutbreakCluster[];
  selectedState: string;
  onSelectCluster: (cluster: OutbreakCluster) => void;
}

export const IndiaSurveillanceMap: React.FC<IndiaSurveillanceMapProps> = ({
  clusters,
  selectedState,
  onSelectCluster,
}) => {
  const [activeLayer, setActiveLayer] = useState<'all' | 'high_risk' | 'vaccination'>('all');
  const [hoveredCluster, setHoveredCluster] = useState<OutbreakCluster | null>(null);

  // States with approximate SVG polygons or visual nodes for clean, fast rendering of India
  // Map points mapped to realistic coordinates within the 600x600 SVG viewBox
  const stateRegions = [
    { name: 'Gujarat', x: 120, y: 310, code: 'GJ', risk: 'High', cases: 42, color: '#fca5a5' },
    { name: 'Haryana', x: 235, y: 195, code: 'HR', risk: 'Medium', cases: 11, color: '#fed7aa' },
    { name: 'Uttar Pradesh', x: 300, y: 230, code: 'UP', risk: 'Critical', cases: 87, color: '#f87171' },
    { name: 'Punjab', x: 200, y: 160, code: 'PB', risk: 'Low', cases: 5, color: '#bbf7d0' },
    { name: 'Rajasthan', x: 170, y: 240, code: 'RJ', risk: 'Medium', cases: 9, color: '#fed7aa' },
    { name: 'Maharashtra', x: 210, y: 380, code: 'MH', risk: 'Low', cases: 3, color: '#bbf7d0' },
    { name: 'Madhya Pradesh', x: 260, y: 300, code: 'MP', risk: 'Low', cases: 2, color: '#bbf7d0' },
    { name: 'Karnataka', x: 205, y: 460, code: 'KA', risk: 'Low', cases: 1, color: '#bbf7d0' },
    { name: 'Bihar', x: 400, y: 260, code: 'BR', risk: 'Medium', cases: 8, color: '#fed7aa' },
    { name: 'Tamil Nadu', x: 240, y: 520, code: 'TN', risk: 'Low', cases: 0, color: '#dcfce7' },
  ];

  // Specific Hotspots mapped on the canvas
  const clusterPins = [
    {
      id: 'CLS-GJ-01',
      cluster: clusters.find(c => c.id === 'CLS-GJ-01') || clusters[0],
      x: 135,
      y: 320,
      label: 'Anand (FMD Outbreak)',
      district: 'Anand',
      state: 'Gujarat',
      color: '#dc2626',
    },
    {
      id: 'CLS-UP-02',
      cluster: clusters.find(c => c.id === 'CLS-UP-02') || clusters[1],
      x: 275,
      y: 195,
      label: 'Meerut (LSD Cluster)',
      district: 'Meerut',
      state: 'Uttar Pradesh',
      color: '#991b1b',
    },
    {
      id: 'CLS-HR-03',
      cluster: clusters.find(c => c.id === 'CLS-HR-03') || clusters[2],
      x: 220,
      y: 190,
      label: 'Hisar (HS Cases)',
      district: 'Hisar',
      state: 'Haryana',
      color: '#ea580c',
    },
    {
      id: 'CLS-PB-04',
      cluster: clusters.find(c => c.id === 'CLS-PB-04') || clusters[3],
      x: 200,
      y: 165,
      label: 'Ludhiana (Brucellosis)',
      district: 'Ludhiana',
      state: 'Punjab',
      color: '#16a34a',
    },
    {
      id: 'CLS-RJ-05',
      cluster: clusters.find(c => c.id === 'CLS-RJ-05') || clusters[4],
      x: 160,
      y: 255,
      label: 'Jodhpur (BQ)',
      district: 'Jodhpur',
      state: 'Rajasthan',
      color: '#d97706',
    },
  ];

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-2xs relative flex flex-col justify-between">
      {/* Map Header & Filter Chips */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
        <div>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-rose-600" />
            <h3 className="text-sm font-extrabold text-slate-900">
              India Geospatial Livestock Epidemic Surveillance Map
            </h3>
          </div>
          <p className="text-[11px] text-slate-500">
            Real-time disease density mapping across State, District, Block and Farm clusters.
          </p>
        </div>

        {/* Layer Switcher */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs font-bold">
          <button
            onClick={() => setActiveLayer('all')}
            className={`px-2.5 py-1 rounded transition ${
              activeLayer === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            All Clusters
          </button>
          <button
            onClick={() => setActiveLayer('high_risk')}
            className={`px-2.5 py-1 rounded transition ${
              activeLayer === 'high_risk' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600'
            }`}
          >
            High/Critical Risk
          </button>
          <button
            onClick={() => setActiveLayer('vaccination')}
            className={`px-2.5 py-1 rounded transition ${
              activeLayer === 'vaccination' ? 'bg-emerald-700 text-white shadow-xs' : 'text-slate-600'
            }`}
          >
            Vaccination Gaps
          </button>
        </div>
      </div>

      {/* SVG Map Container */}
      <div className="relative w-full aspect-[4/3] max-h-[460px] bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 flex items-center justify-center p-2">
        {/* Subtle Radar Background Grid */}
        <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:24px_24px] opacity-60 pointer-events-none" />

        <svg
          viewBox="0 0 540 560"
          className="w-full h-full max-h-[450px]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Stylized National Boundary Contour for India */}
          <path
            d="M185 80 
               C215 65 245 80 255 110 
               C275 110 320 120 330 145 
               C335 155 350 160 365 170 
               C390 195 440 210 460 215 
               C475 220 480 240 465 250 
               C445 260 410 260 395 280 
               C380 295 385 320 365 345 
               C340 375 325 410 300 450 
               C275 490 250 535 240 545 
               C230 535 210 480 195 435 
               C180 390 170 360 145 340 
               C110 325 90 310 95 290 
               C100 270 140 270 150 250 
               C155 235 145 200 160 170 
               C170 150 165 110 185 80 Z"
            fill="#064e3b"
            fillOpacity="0.4"
            stroke="#10b981"
            strokeWidth="1.8"
            strokeDasharray="4 2"
          />

          {/* Regional Territory Shapes */}
          {stateRegions.map((state, i) => (
            <g key={i} className="cursor-pointer group">
              <circle
                cx={state.x}
                cy={state.y}
                r="24"
                fill={state.risk === 'Critical' ? '#ef4444' : state.risk === 'High' ? '#f97316' : '#10b981'}
                fillOpacity="0.25"
                stroke={state.risk === 'Critical' ? '#ef4444' : state.risk === 'High' ? '#f97316' : '#10b981'}
                strokeWidth="1.2"
              />
              <text
                x={state.x}
                y={state.y - 2}
                fill="#ffffff"
                fontSize="10"
                fontWeight="800"
                textAnchor="middle"
                fontFamily="system-ui"
              >
                {state.code}
              </text>
              <text
                x={state.x}
                y={state.y + 10}
                fill="#cbd5e1"
                fontSize="8"
                fontWeight="600"
                textAnchor="middle"
                fontFamily="system-ui"
              >
                {state.cases} cases
              </text>
            </g>
          ))}

          {/* Active Epidemic Hotspot Pins */}
          {clusterPins.map(pin => {
            const isHigh = pin.cluster?.riskLevel === 'High' || pin.cluster?.riskLevel === 'Critical';
            if (activeLayer === 'high_risk' && !isHigh) return null;

            return (
              <g
                key={pin.id}
                className="cursor-pointer"
                onClick={() => onSelectCluster(pin.cluster)}
                onMouseEnter={() => setHoveredCluster(pin.cluster)}
                onMouseLeave={() => setHoveredCluster(null)}
              >
                {/* Outer pinging radar circle */}
                <circle
                  cx={pin.x}
                  cy={pin.y}
                  r="16"
                  fill={pin.color}
                  fillOpacity="0.3"
                  className="animate-ping origin-center"
                />
                <circle
                  cx={pin.x}
                  cy={pin.y}
                  r="7"
                  fill={pin.color}
                  stroke="#ffffff"
                  strokeWidth="2"
                />
                <circle cx={pin.x} cy={pin.y} r="2.5" fill="#ffffff" />

                {/* Pin label */}
                <rect
                  x={pin.x + 10}
                  y={pin.y - 12}
                  width={pin.label.length * 5.8 + 12}
                  height="18"
                  rx="4"
                  fill="#020617"
                  fillOpacity="0.9"
                  stroke={pin.color}
                  strokeWidth="1"
                />
                <text
                  x={pin.x + 16}
                  y={pin.y}
                  fill="#ffffff"
                  fontSize="8.5"
                  fontWeight="700"
                  fontFamily="system-ui"
                >
                  {pin.label}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Floating Tooltip if hovering a cluster */}
        {hoveredCluster && (
          <div className="absolute bottom-3 left-3 right-3 sm:right-auto sm:max-w-xs bg-slate-900/95 text-white p-3 rounded-xl border border-slate-700 shadow-xl backdrop-blur-md text-xs z-20">
            <div className="flex items-center justify-between gap-2 mb-1">
              <span className="font-extrabold text-rose-400">{hoveredCluster.diseaseName}</span>
              <span className="text-[9px] bg-rose-600 px-1.5 py-0.2 rounded font-black uppercase">
                {hoveredCluster.riskLevel} Risk
              </span>
            </div>
            <p className="text-[11px] text-slate-300">
              {hoveredCluster.block}, {hoveredCluster.district} ({hoveredCluster.state})
            </p>
            <div className="grid grid-cols-3 gap-1.5 mt-2 pt-1.5 border-t border-slate-800 text-[10px]">
              <div>
                <span className="text-slate-400 block">Active Cases</span>
                <strong className="text-white text-xs">{hoveredCluster.activeCases}</strong>
              </div>
              <div>
                <span className="text-slate-400 block">Mortality</span>
                <strong className="text-rose-400 text-xs">{hoveredCluster.mortalities}</strong>
              </div>
              <div>
                <span className="text-slate-400 block">Vaccine Cov.</span>
                <strong className="text-emerald-400 text-xs">
                  {hoveredCluster.vaccinationCoveragePercent}%
                </strong>
              </div>
            </div>
          </div>
        )}

        {/* Legend in corner */}
        <div className="absolute top-3 right-3 bg-slate-900/90 text-white p-2.5 rounded-xl border border-slate-800 text-[10px] space-y-1 backdrop-blur-xs">
          <span className="font-bold text-slate-300 block text-[9px] uppercase tracking-wider mb-1">
            Surveillance Legend
          </span>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-600"></span>
            <span>Critical / Active Outbreak</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            <span>High Risk Cluster</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            <span>Monitored / High Vaccine Cov.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
