import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { Skull, X, AlertOctagon, CheckCircle2, ShieldAlert } from 'lucide-react';

interface MortalityReportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MortalityReportModal: React.FC<MortalityReportModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { animals, reportMortality } = useLivestock();

  // Filter living animals
  const livingAnimals = animals.filter(a => a.healthStatus !== 'Deceased');
  const [animalId, setAnimalId] = useState(livingAnimals[0]?.id || animals[0]?.id || '');
  const [suspectedCause, setSuspectedCause] = useState('Acute Hemorrhagic Septicemia (Gal Ghotu)');
  const [postMortem, setPostMortem] = useState(true);
  const [disposal, setDisposal] = useState<'Buried with Lime' | 'Incinerated' | 'Pending Verification'>('Buried with Lime');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!animalId) return;

    reportMortality({
      animalId,
      cause: suspectedCause,
      postMortem,
      disposal,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-3 sm:p-4 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 my-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
          <div className="flex items-center gap-2 text-rose-700">
            <Skull className="w-6 h-6" />
            <h3 className="text-base font-extrabold text-slate-900">
              Report Bovine Mortality & Bio-Disposal
            </h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700 font-bold">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">Deceased Animal *</label>
            <select
              value={animalId}
              onChange={e => setAnimalId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900 font-bold"
            >
              {livingAnimals.map(a => (
                <option key={a.id} value={a.id}>
                  {a.id} — {a.name} ({a.breed})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Suspected Cause of Death *</label>
            <select
              value={suspectedCause}
              onChange={e => setSuspectedCause(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900"
            >
              <option value="Acute Hemorrhagic Septicemia (Gal Ghotu)">
                Acute Hemorrhagic Septicemia (HS - Gal Ghotu)
              </option>
              <option value="Anthrax (Suspected Spore Outbreak - Do Not Open Carcass)">
                Anthrax (Suspected - Strict No Incision Bio-safety)
              </option>
              <option value="Black Quarter (BQ - Jaharbaad)">Black Quarter (BQ - Jaharbaad)</option>
              <option value="Peracute Bloat / Acidosis">Peracute Bloat / Ruminal Acidosis</option>
              <option value="Severe Secondary Infection post-LSD">Secondary Infection post-LSD</option>
              <option value="Unknown / Sudden Unwitnessed Death">Unknown / Sudden Unwitnessed Death</option>
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">
              National Bio-Security Carcass Disposal Method *
            </label>
            <select
              value={disposal}
              onChange={e => setDisposal(e.target.value as any)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900"
            >
              <option value="Buried with Lime">
                Deep Burial (6ft Pit + Quicklime Layered Protocol)
              </option>
              <option value="Incinerated">High-Temperature Incineration</option>
              <option value="Pending Verification">
                Pending District Veterinary Officer Inspection
              </option>
            </select>
          </div>

          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5">
            <input
              type="checkbox"
              id="postMortemCheck"
              checked={postMortem}
              onChange={e => setPostMortem(e.target.checked)}
              className="mt-0.5 rounded text-rose-600 focus:ring-rose-500"
            />
            <label htmlFor="postMortemCheck" className="text-rose-950 font-semibold cursor-pointer">
              Request Veterinary Post-Mortem & Diagnostic Sample Collection (Recommended for outbreak monitoring).
            </label>
          </div>

          <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-rose-700 hover:bg-rose-600 text-white rounded-xl font-bold shadow-md flex items-center gap-1.5"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Record Mortality Event</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
