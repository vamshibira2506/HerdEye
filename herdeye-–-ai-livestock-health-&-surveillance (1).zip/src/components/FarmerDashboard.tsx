import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { useLanguage } from '../context/LanguageContext';
import { Animal } from '../types';
import {
  Mic,
  Volume2,
  Video,
  Camera,
  PhoneCall,
  Syringe,
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  Sparkles,
  Calendar,
  Clock,
  HeartPulse,
  Eye,
  Plus,
} from 'lucide-react';

interface FarmerDashboardProps {
  onOpenRegister: () => void;
  onOpenReport: (animal?: Animal, symptomKey?: string) => void;
  onOpenMortality: () => void;
  onSelectAnimal: (animal: Animal) => void;
  onOpenTalkToDoctor: (animal?: Animal) => void;
  onOpenCameraCheck: (animal?: Animal) => void;
  onOpenVoiceAssistant: () => void;
  onOpenVaccination: () => void;
}

export const FarmerDashboard: React.FC<FarmerDashboardProps> = ({
  onOpenRegister,
  onOpenReport,
  onOpenMortality,
  onSelectAnimal,
  onOpenTalkToDoctor,
  onOpenCameraCheck,
  onOpenVoiceAssistant,
  onOpenVaccination,
}) => {
  const { animals, alerts, isOnline } = useLivestock();
  const { t, speakText, language } = useLanguage();

  const farmerAnimals = animals;
  const totalCount = farmerAnimals.length;
  const healthyCount = farmerAnimals.filter(a => a.healthStatus === 'Healthy').length;
  const attentionCount = farmerAnimals.filter(a => a.healthStatus !== 'Healthy').length;
  const vaccineDueCount = 1; // 1 due soon per schedules

  // Smart Banner State per Requirement 28
  let bannerMessage = t('status_good', '✅ మీ పశువులు ఈరోజు ఆరోగ్యంగా ఉన్నాయి.');
  let bannerBg = 'bg-emerald-50 border-emerald-200 text-emerald-950';

  if (!isOnline) {
    bannerMessage = t('status_offline', '📴 ఇంటర్నెట్ లేదు. మీ సమాచారం సురక్షితంగా ఫోన్‌లోనే ఉంది.');
    bannerBg = 'bg-amber-50 border-amber-200 text-amber-950';
  } else if (attentionCount > 0) {
    bannerMessage = t('status_ai_concern', '⚠️ ఒక పశువులో మార్పు కనిపించింది. దయచేసి పరిశీలించండి.');
    bannerBg = 'bg-amber-50 border-amber-200 text-amber-950';
  } else if (vaccineDueCount > 0) {
    bannerMessage = t('status_vaccine_due', '💉 1 పశువుకు టీకా వేయించాల్సిన సమయం వచ్చింది.');
    bannerBg = 'bg-sky-50 border-sky-200 text-sky-950';
  }

  // Voice quick chips
  const quickVoiceChips = [
    { text: t('voice_sample_1', 'నా గేదె తినడం లేదు'), symptom: 'not_eating', icon: '🍚' },
    { text: t('voice_sample_2', 'పశువుకు జ్వరం ఉంది'), symptom: 'sick_fever', icon: '🤒' },
    { text: t('voice_sample_3', 'నా ఆవు కుంటుతోంది'), symptom: 'limping', icon: '🚶' },
    { text: t('voice_sample_4', 'డాక్టర్ను పిలవాలి'), isDoctor: true, icon: '👨‍⚕️' },
  ];

  return (
    <div className="space-y-5 animate-fade-in max-w-5xl mx-auto pb-16" id="farmer-dashboard-root">
      {/* Top Greeting Header (Requirement 4) */}
      <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-slate-900 text-white p-5 sm:p-6 rounded-3xl shadow-sm border border-emerald-700/40 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[11px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                రైతు మిత్ర (Farmer Mode)
              </span>
              <span className="text-slate-300 text-xs">మోగ్రి, ఆనంద్ (గుజరాత్)</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black tracking-tight flex items-center gap-2">
              <span>{t('greeting', 'నమస్కారం 👋')}</span>
              <span className="text-emerald-300">రమేష్ పటేల్</span>
            </h1>

            <p className="text-slate-200 text-xs sm:text-sm mt-1">
              {t('greeting_sub', 'మీ పశువుల ఆరోగ్యం')} • నిరంతర నిఘా మరియు వైద్య రక్షణ
            </p>
          </div>

          {/* Voice Mic Trigger on banner */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={onOpenVoiceAssistant}
              className="flex items-center gap-2 px-4 py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-2xl text-xs shadow-lg shadow-amber-950/30 transition active:scale-95 ring-2 ring-amber-300"
              id="farmer-btn-voice-assistant"
            >
              <Mic className="w-5 h-5 animate-pulse text-slate-950" />
              <span>{t('btn_speak_problem', 'సమస్య మాట్లాడండి')}</span>
            </button>

            <button
              onClick={() => onOpenReport()}
              className="flex items-center gap-1.5 px-3.5 py-3 bg-rose-600 hover:bg-rose-500 text-white rounded-2xl text-xs font-black shadow-md shadow-rose-950/20 transition active:scale-95"
            >
              <Video className="w-4 h-4" />
              <span>15s వీడియో</span>
            </button>
          </div>
        </div>
      </div>

      {/* Smart Home Screen Banner (Requirement 28) */}
      <div className={`p-4 rounded-3xl border-2 flex items-center justify-between gap-3 shadow-2xs ${bannerBg}`}>
        <div className="flex items-center gap-3">
          <p className="text-xs sm:text-sm font-black tracking-tight leading-snug">
            {bannerMessage}
          </p>
        </div>

        <button
          onClick={() => speakText(bannerMessage)}
          className="p-2 rounded-xl bg-black/5 hover:bg-black/10 text-current transition flex items-center gap-1 text-xs font-bold shrink-0"
          title="Audio read aloud"
        >
          <Volume2 className="w-4 h-4" />
          <span className="hidden sm:inline">{t('voice_listen', 'వినండి')}</span>
        </button>
      </div>

      {/* 4 Essential Metric Cards (Requirement 4) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Total Animals */}
        <div className="bg-white p-4 sm:p-5 rounded-3xl border-2 border-slate-200 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-black text-slate-500">
              {t('total_animals', 'మొత్తం పశువులు')}
            </span>
            <span className="text-2xl">🐄</span>
          </div>
          <div>
            <span className="text-2xl sm:text-3xl font-black text-slate-900">{totalCount}</span>
            <span className="text-[11px] font-bold text-emerald-700 block mt-0.5">రిజిస్టర్ అయినవి</span>
          </div>
        </div>

        {/* Healthy Animals */}
        <div className="bg-white p-4 sm:p-5 rounded-3xl border-2 border-slate-200 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-black text-slate-500">
              {t('healthy_animals', 'ఆరోగ్యంగా ఉన్నవి')}
            </span>
            <span className="text-2xl">🟢</span>
          </div>
          <div>
            <span className="text-2xl sm:text-3xl font-black text-emerald-700">{healthyCount}</span>
            <span className="text-[11px] font-bold text-emerald-600 block mt-0.5">సమస్యలు లేవు</span>
          </div>
        </div>

        {/* Attention Needed */}
        <div className="bg-white p-4 sm:p-5 rounded-3xl border-2 border-slate-200 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-black text-slate-500">
              {t('attention_needed', 'శ్రద్ధ అవసరం')}
            </span>
            <span className="text-2xl">⚠️</span>
          </div>
          <div>
            <span className="text-2xl sm:text-3xl font-black text-amber-600">{attentionCount}</span>
            <span className="text-[11px] font-bold text-amber-700 block mt-0.5">పరిశీలించాల్సినవి</span>
          </div>
        </div>

        {/* Vaccination Due */}
        <div
          onClick={onOpenVaccination}
          className="bg-white p-4 sm:p-5 rounded-3xl border-2 border-slate-200 hover:border-emerald-400 cursor-pointer shadow-2xs flex flex-col justify-between transition"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-black text-slate-500">
              {t('vaccination_due', 'టీకా సమయం')}
            </span>
            <span className="text-2xl">💉</span>
          </div>
          <div>
            <span className="text-2xl sm:text-3xl font-black text-sky-700">1</span>
            <span className="text-[11px] font-bold text-sky-600 block mt-0.5">5 రోజుల్లో టీకా</span>
          </div>
        </div>
      </div>

      {/* Main Large Visual Action Buttons (Requirement 4) */}
      <div className="space-y-2.5">
        <h2 className="text-xs font-black uppercase tracking-wider text-slate-500 px-1">
          ప్రధాన సేవలు (Quick Actions):
        </h2>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {/* 1. CHECK MY ANIMAL */}
          <button
            onClick={() => onOpenCameraCheck(farmerAnimals[0])}
            className="p-4 sm:p-5 rounded-3xl bg-emerald-700 hover:bg-emerald-600 text-white font-black text-xs sm:text-sm flex flex-col items-center justify-center text-center gap-2 shadow-md shadow-emerald-900/10 active:scale-95 transition"
            id="farmer-btn-check-animal"
          >
            <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-2xl">
              🟢
            </div>
            <span>{t('btn_check_animal', 'నా పశువును తనిఖీ చేయండి')}</span>
          </button>

          {/* 2. REPORT A PROBLEM */}
          <button
            onClick={() => onOpenReport()}
            className="p-4 sm:p-5 rounded-3xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs sm:text-sm flex flex-col items-center justify-center text-center gap-2 shadow-md shadow-rose-900/10 active:scale-95 transition"
            id="farmer-btn-report-problem"
          >
            <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-2xl">
              🔴
            </div>
            <span>{t('btn_report_problem', 'పశువుకు సమస్య ఉందా?')}</span>
          </button>

          {/* 3. VACCINATION */}
          <button
            onClick={onOpenVaccination}
            className="p-4 sm:p-5 rounded-3xl bg-sky-700 hover:bg-sky-600 text-white font-black text-xs sm:text-sm flex flex-col items-center justify-center text-center gap-2 shadow-md shadow-sky-900/10 active:scale-95 transition"
            id="farmer-btn-vaccination"
          >
            <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-2xl">
              💉
            </div>
            <span>{t('btn_vaccination', 'టీకాలు')}</span>
          </button>

          {/* 4. CALL VETERINARIAN */}
          <button
            onClick={() => onOpenTalkToDoctor()}
            className="p-4 sm:p-5 rounded-3xl bg-slate-900 hover:bg-slate-800 text-white font-black text-xs sm:text-sm flex flex-col items-center justify-center text-center gap-2 shadow-md active:scale-95 transition"
            id="farmer-btn-call-doctor"
          >
            <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-2xl">
              👨‍⚕️
            </div>
            <span>{t('btn_call_doctor', 'పశువుల డాక్టర్')}</span>
          </button>
        </div>

        {/* Secondary row: Camera, Speak, Add Animal */}
        <div className="grid grid-cols-3 gap-2.5 pt-1">
          <button
            onClick={() => onOpenCameraCheck()}
            className="p-3 bg-white hover:bg-emerald-50 border-2 border-slate-200 text-slate-800 font-extrabold text-xs rounded-2xl flex items-center justify-center gap-2 transition"
          >
            <Camera className="w-4 h-4 text-emerald-700" />
            <span className="truncate">{t('btn_camera_check', 'కెమెరాతో తనిఖీ')}</span>
          </button>

          <button
            onClick={onOpenVoiceAssistant}
            className="p-3 bg-white hover:bg-amber-50 border-2 border-slate-200 text-slate-800 font-extrabold text-xs rounded-2xl flex items-center justify-center gap-2 transition"
          >
            <Mic className="w-4 h-4 text-amber-600" />
            <span className="truncate">{t('btn_speak_problem', 'మాట్లాడి చెప్పండి')}</span>
          </button>

          <button
            onClick={onOpenRegister}
            className="p-3 bg-white hover:bg-sky-50 border-2 border-slate-200 text-slate-800 font-extrabold text-xs rounded-2xl flex items-center justify-center gap-2 transition"
          >
            <Plus className="w-4 h-4 text-sky-600" />
            <span className="truncate">కొత్త పశువు నమోదు</span>
          </button>
        </div>
      </div>

      {/* Voice Prompts Bar (Requirement 3) */}
      <div className="p-4 bg-slate-100 rounded-3xl border border-slate-200">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-black text-slate-700 flex items-center gap-1.5">
            <Mic className="w-4 h-4 text-emerald-600" />
            <span>త్వరిత వాయిస్ తాకిడి (Tap to speak in {language.toUpperCase()}):</span>
          </span>
          <button
            onClick={onOpenVoiceAssistant}
            className="text-[11px] text-emerald-800 font-black hover:underline"
          >
            పూర్తి వాయిస్ అసిస్టెంట్ ➔
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {quickVoiceChips.map((chip, idx) => (
            <button
              key={idx}
              onClick={() => {
                if (chip.isDoctor) {
                  onOpenTalkToDoctor();
                } else {
                  onOpenReport(undefined, chip.symptom);
                }
              }}
              className="flex items-center gap-2 p-2.5 bg-white hover:bg-emerald-50 rounded-2xl border border-slate-200 text-left transition text-xs font-extrabold text-slate-800 active:scale-95"
            >
              <span className="text-lg">{chip.icon}</span>
              <span className="truncate">{chip.text}</span>
            </button>
          ))}
        </div>
      </div>

      {/* My Animals Section (Requirement 5) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-base font-black text-slate-900 tracking-tight flex items-center gap-2">
            <span>{t('btn_my_animals', 'నా పశువులు (My Animals)')}</span>
            <span className="text-xs bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full font-bold">
              {farmerAnimals.length}
            </span>
          </h2>

          <button
            onClick={onOpenRegister}
            className="text-xs font-black text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>పశువును జోడించండి</span>
          </button>
        </div>

        {/* Animal Cards list */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {farmerAnimals.map(animal => {
            const isHealthy = animal.healthStatus === 'Healthy';
            const isCritical = animal.healthStatus === 'High Risk / Critical';

            const statusIndicator = isHealthy ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-black bg-emerald-50 text-emerald-800 border border-emerald-200">
                🟢 {t('status_healthy', 'ఆరోగ్యంగా ఉంది')}
              </span>
            ) : isCritical ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-black bg-rose-50 text-rose-800 border border-rose-200 animate-pulse">
                🔴 {t('status_urgent', 'వెంటనే డాక్టర్ వద్దకు')}
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-black bg-amber-50 text-amber-800 border border-amber-200">
                🟡 {t('status_needs_attention', 'శ్రద్ధ అవసరం')}
              </span>
            );

            return (
              <div
                key={animal.id}
                onClick={() => onSelectAnimal(animal)}
                className="bg-white rounded-3xl p-4 border-2 border-slate-200 hover:border-emerald-400 cursor-pointer transition shadow-2xs hover:shadow-md flex items-center justify-between gap-3 group"
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className="w-16 h-16 rounded-2xl overflow-hidden border-2 border-slate-200 shrink-0 relative">
                    <img
                      src={animal.photoUrl}
                      alt={animal.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <span className="absolute bottom-0 right-0 text-sm bg-black/40 rounded-tl-lg px-1 text-white">
                      {animal.species === 'Buffalo' ? '🐃' : '🐄'}
                    </span>
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <h3 className="font-black text-base text-slate-900 truncate">
                        {animal.name}
                      </h3>
                      <span className="text-[11px] font-mono text-slate-400">
                        ({animal.id.split('-').pop()})
                      </span>
                    </div>

                    <p className="text-xs text-slate-500 mt-0.5">
                      {animal.breed} • {animal.ageYears} {t('years', 'సంవత్సరాలు')}
                    </p>

                    <div className="mt-1.5">{statusIndicator}</div>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-2 shrink-0">
                  <span className="text-[11px] font-bold text-slate-400">
                    {animal.lastChecked}
                  </span>
                  <div className="w-8 h-8 rounded-full bg-slate-100 group-hover:bg-emerald-100 group-hover:text-emerald-800 flex items-center justify-center text-slate-400 transition">
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
