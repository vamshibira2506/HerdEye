import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { useLanguage } from '../context/LanguageContext';
import { Animal } from '../types';
import {
  Syringe,
  Bell,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Volume2,
  Calendar,
  Sparkles,
} from 'lucide-react';

interface FarmerVaccinationViewProps {
  onSelectAnimal: (animal: Animal) => void;
}

export const FarmerVaccinationView: React.FC<FarmerVaccinationViewProps> = ({
  onSelectAnimal,
}) => {
  const { animals, setToastMessage } = useLivestock();
  const { t, speakText } = useLanguage();
  const [filter, setFilter] = useState<'due_soon' | 'completed' | 'overdue'>('due_soon');
  const [remindedAnimals, setRemindedAnimals] = useState<string[]>([]);

  // Simple vaccine categorization for farmer
  const dueSoonAnimals = animals.filter(a => a.healthStatus === 'Under Observation' || a.id.includes('9182'));
  const completedAnimals = animals.filter(a => (a.vaccinationRecords?.length || 0) > 0 && !dueSoonAnimals.includes(a));
  const overdueAnimals = animals.filter(a => a.id.includes('5501'));

  const handleRemindMe = (animalId: string, animalName: string) => {
    setRemindedAnimals([...remindedAnimals, animalId]);
    speakText(`${animalName} టీకా సమయానికి మీకు మొబైల్ అలర్ట్ పంపబడుతుంది`);
    setToastMessage({
      title: 'రిమైండర్ సెట్ చేయబడింది! 🔔',
      desc: `${animalName} టీకా తేదీ దగ్గరపడినప్పుడు మీకు SMS & నోటిఫికేషన్ వస్తుంది.`,
      type: 'success',
    });
  };

  const listToShow =
    filter === 'due_soon'
      ? dueSoonAnimals
      : filter === 'completed'
      ? completedAnimals
      : overdueAnimals;

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-12 animate-fade-in">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-teal-800 via-emerald-800 to-slate-900 text-white p-5 sm:p-6 rounded-3xl shadow-sm border border-emerald-700/40 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4 text-center sm:text-left">
          <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center text-3xl shrink-0 shadow-inner">
            💉
          </div>
          <div>
            <div className="flex items-center justify-center sm:justify-start gap-2 mb-1">
              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[11px] font-bold px-2.5 py-0.5 rounded-full uppercase">
                {t('btn_vaccination', 'టీకాల రక్షణ')}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black">
              {t('vaccine_due_badge', 'టీకాల పట్టిక (Vaccination Status)')}
            </h1>
            <p className="text-emerald-100 text-xs sm:text-sm mt-1">
              2 టీకాలు త్వరలో వేయించాల్సి ఉంది. వ్యాధుల నుండి పశువులకు సంపూర్ణ రక్షణ.
            </p>
          </div>
        </div>

        <button
          onClick={() =>
            speakText(
              'లక్ష్మి మరియు ఇతర పశువులకు గాలికుంటు టీకా 5 రోజుల్లో వేయించాల్సి ఉంది. రిమైండర్ బటన్ నొక్కండి.'
            )
          }
          className="flex items-center gap-1.5 px-4 py-2 bg-white/20 hover:bg-white/30 text-white rounded-xl text-xs font-bold transition shrink-0"
        >
          <Volume2 className="w-4 h-4" />
          <span>{t('voice_listen', 'వినండి')}</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 p-1.5 bg-slate-100 rounded-2xl border border-slate-200">
        <button
          onClick={() => setFilter('due_soon')}
          className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-black transition flex items-center justify-center gap-2 ${
            filter === 'due_soon'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>{t('vaccine_due_soon', 'త్వరలో వేయవలసినవి')} ({dueSoonAnimals.length})</span>
        </button>

        <button
          onClick={() => setFilter('completed')}
          className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-black transition flex items-center justify-center gap-2 ${
            filter === 'completed'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>{t('vaccine_completed', 'పూర్తయినవి')} ({completedAnimals.length})</span>
        </button>

        <button
          onClick={() => setFilter('overdue')}
          className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-black transition flex items-center justify-center gap-2 ${
            filter === 'overdue'
              ? 'bg-rose-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
          <span>{t('vaccine_overdue', 'సమయం మించినవి')} ({overdueAnimals.length})</span>
        </button>
      </div>

      {/* Animal Cards list per Requirement 11 */}
      <div className="space-y-3.5">
        {listToShow.map(animal => {
          const isReminded = remindedAnimals.includes(animal.id);
          return (
            <div
              key={animal.id}
              className="bg-white rounded-3xl p-4 sm:p-5 border-2 border-slate-200 hover:border-emerald-300 transition shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-4"
            >
              <div className="flex items-center gap-4 w-full sm:w-auto">
                <div className="w-16 h-16 rounded-2xl overflow-hidden border-2 border-slate-200 shrink-0">
                  <img
                    src={animal.photoUrl}
                    alt={animal.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base">{animal.species === 'Buffalo' ? '🐃' : '🐄'}</span>
                    <h3 className="font-black text-base text-slate-900">{animal.name}</h3>
                    <span className="text-[11px] font-mono text-slate-400">({animal.id})</span>
                  </div>

                  <p className="text-xs font-extrabold text-amber-700 mt-1 flex items-center gap-1">
                    <Syringe className="w-3.5 h-3.5" />
                    <span>గాలికుంటు (FMD) బూస్టర్ డోస్ • 5 రోజుల్లో వేయించాలి</span>
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    ప్రభుత్వ ఉచిత టీకా డ్రైవ్ • గ్రామ పశువైద్యశాల
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  onClick={() => handleRemindMe(animal.id, animal.name)}
                  className={`px-4 py-2.5 rounded-xl font-black text-xs transition flex items-center gap-1.5 shadow-2xs ${
                    isReminded
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : 'bg-emerald-700 hover:bg-emerald-600 text-white shadow-emerald-800/20 active:scale-95'
                  }`}
                >
                  <Bell className="w-4 h-4" />
                  <span>{isReminded ? 'గుర్తు చేయబడుతుంది ✅' : t('btn_remind_me', 'గుర్తు చేయండి (REMIND ME)')}</span>
                </button>

                <button
                  onClick={() => onSelectAnimal(animal)}
                  className="px-3 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
                >
                  వివరాలు
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
