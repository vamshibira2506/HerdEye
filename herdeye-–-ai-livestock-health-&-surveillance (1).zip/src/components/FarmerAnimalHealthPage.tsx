import React, { useState } from 'react';
import { useLivestock } from '../context/LivestockContext';
import { useLanguage } from '../context/LanguageContext';
import { Animal } from '../types';
import {
  Heart,
  Activity,
  Milk,
  Thermometer,
  Syringe,
  Camera,
  FileText,
  Volume2,
  PhoneCall,
  Video,
  AlertTriangle,
  CheckCircle2,
  ArrowLeft,
  Calendar,
  Sparkles,
  MapPin,
  Clock,
} from 'lucide-react';

interface FarmerAnimalHealthPageProps {
  animal: Animal;
  onBack: () => void;
  onOpenReport: (animal: Animal) => void;
  onOpenTalkToDoctor: (animal: Animal) => void;
  onOpenCameraCheck: (animal: Animal) => void;
}

export const FarmerAnimalHealthPage: React.FC<FarmerAnimalHealthPageProps> = ({
  animal,
  onBack,
  onOpenReport,
  onOpenTalkToDoctor,
  onOpenCameraCheck,
}) => {
  const { t, speakText } = useLanguage();
  const { animals } = useLivestock();
  const [checkedToday, setCheckedToday] = useState<boolean | null>(null);

  // Status mapping
  const statusLabel =
    animal.healthStatus === 'Healthy'
      ? t('status_healthy', 'ఆరోగ్యంగా ఉంది (HEALTHY)')
      : animal.healthStatus === 'Under Observation'
      ? t('status_needs_attention', 'శ్రద్ధ అవసరం (NEEDS ATTENTION)')
      : t('status_urgent', 'వెంటనే డాక్టర్‌ను కలవండి (CONTACT VETERINARIAN)');

  const statusColor =
    animal.healthStatus === 'Healthy'
      ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
      : animal.healthStatus === 'Under Observation'
      ? 'bg-amber-100 text-amber-900 border-amber-300'
      : 'bg-rose-100 text-rose-900 border-rose-300';

  const readStatusAloud = () => {
    speakText(
      `${animal.name}, ${animal.species}. ${statusLabel}. ${animal.confidenceAlert || 'Regular monitoring'}`
    );
  };

  return (
    <div className="space-y-5 animate-fade-in max-w-4xl mx-auto pb-12">
      {/* Top Back & Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-4 py-2 bg-white rounded-2xl border border-slate-200 text-slate-700 font-extrabold text-xs hover:bg-slate-50 transition shadow-2xs"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t('nav_animals', 'అన్ని పశువులు')}</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={readStatusAloud}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl text-xs font-black shadow-2xs hover:bg-emerald-100 transition"
          >
            <Volume2 className="w-4 h-4 text-emerald-600" />
            <span>{t('voice_listen', 'వినండి (Audio)')}</span>
          </button>
        </div>
      </div>

      {/* Main Profile & Status Header */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border-2 border-slate-200 shadow-sm relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
          {/* Photo */}
          <div className="relative w-28 h-28 sm:w-36 sm:h-36 rounded-2xl overflow-hidden border-3 border-slate-200 shadow-md shrink-0">
            <img
              src={animal.photoUrl || 'https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?auto=format&fit=crop&w=400&q=80'}
              alt={animal.name}
              className="w-full h-full object-cover"
            />
            <span className="absolute bottom-1 right-1 text-2xl">
              {animal.species === 'Buffalo' ? '🐃' : '🐄'}
            </span>
          </div>

          {/* Details */}
          <div className="flex-1 text-center sm:text-left">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-1.5">
              <span className="text-xs font-mono font-bold bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded-lg border border-slate-200">
                {animal.id}
              </span>
              <span className="text-xs font-bold text-slate-500">
                {animal.species} • {animal.breed}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              {animal.name}
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              {t('age', 'వయస్సు')}: {animal.ageYears} {t('years', 'సంవత్సరాలు')} • {animal.location?.village || 'Mogri'}, {animal.location?.district || 'Anand'}
            </p>

            {/* Large Health Status Pill */}
            <div className="mt-3 flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <div className={`px-4 py-1.5 rounded-2xl border-2 font-black text-xs sm:text-sm flex items-center gap-2 ${statusColor}`}>
                <span className="w-2.5 h-2.5 rounded-full bg-current animate-pulse" />
                <span>{statusLabel}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Check Prompt: "Is your animal okay today?" */}
        <div className="mt-5 p-4 rounded-2xl bg-emerald-50/80 border border-emerald-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 text-center sm:text-left">
            <span className="text-2xl">🧐</span>
            <div>
              <p className="text-xs sm:text-sm font-black text-emerald-950">
                {t('is_animal_ok', 'మీ పశువు ఈరోజు బాగుందా?')}
              </p>
              <p className="text-[11px] text-emerald-700">
                రోజువారీ గమనింపును నమోదు చేయండి
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => {
                setCheckedToday(true);
                speakText('పశువు బాగున్నట్లు నమోదైంది');
              }}
              className={`flex-1 sm:flex-initial px-4 py-2 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 ${
                checkedToday === true
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300'
              }`}
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{t('ans_yes_healthy', 'అవును, బాగుంది 👍')}</span>
            </button>

            <button
              onClick={() => onOpenReport(animal)}
              className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black transition flex items-center justify-center gap-1.5 shadow-xs"
            >
              <AlertTriangle className="w-4 h-4 text-white" />
              <span>{t('ans_no_problem', 'సమస్య ఉంది ⚠️')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Action Buttons Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <button
          onClick={() => onOpenTalkToDoctor(animal)}
          className="p-4 bg-sky-700 hover:bg-sky-600 text-white rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2.5 shadow-md active:scale-95 transition"
        >
          <PhoneCall className="w-5 h-5" />
          <span>{t('btn_call_doctor', 'పశువుల డాక్టర్')}</span>
        </button>

        <button
          onClick={() => onOpenCameraCheck(animal)}
          className="p-4 bg-emerald-700 hover:bg-emerald-600 text-white rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2.5 shadow-md active:scale-95 transition"
        >
          <Camera className="w-5 h-5" />
          <span>{t('btn_camera_check', 'కెమెరాతో తనిఖీ')}</span>
        </button>

        <button
          onClick={() => onOpenReport(animal)}
          className="p-4 bg-rose-600 hover:bg-rose-500 text-white rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2.5 shadow-md active:scale-95 transition"
        >
          <Video className="w-5 h-5" />
          <span>{t('btn_report_problem', 'సమస్యను నివేదించండి')}</span>
        </button>
      </div>

      {/* 9 Simple Visual Health Sections per Requirement 6 */}
      <div className="space-y-3">
        <h3 className="font-extrabold text-sm uppercase tracking-wider text-slate-500 px-1">
          ఆరోగ్య సూచికలు (Daily Health Indicators):
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
          {/* 1. Health */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-500 flex items-center gap-1.5">
                <Heart className="w-4 h-4 text-rose-500" />
                {t('sec_health', 'సాధారణ ఆరోగ్యం')}
              </span>
              <span className="text-xs font-black text-emerald-700">సాధారణం</span>
            </div>
            <p className="text-sm font-black text-slate-900">{animal.healthStatus}</p>
            <p className="text-[11px] text-slate-400 mt-1">చలాకీగా ఉంది • కళ్లు ప్రకాశవంతంగా ఉన్నాయి</p>
          </div>

          {/* 2. Eating */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-500 flex items-center gap-1.5">
                <span className="text-sm">🍚</span>
                {t('sec_eating', 'మేత తినడం')}
              </span>
              <span className="text-xs font-black text-emerald-700">బాగుంది</span>
            </div>
            <p className="text-sm font-black text-slate-900">నెమరు వేస్తోంది (Rumination Active)</p>
            <p className="text-[11px] text-slate-400 mt-1">రోజూ 450-480 నిమిషాలు నెమరు వేస్తుంది</p>
          </div>

          {/* 3. Drinking */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-500 flex items-center gap-1.5">
                <span className="text-sm">💧</span>
                {t('sec_drinking', 'నీరు తాగడం')}
              </span>
              <span className="text-xs font-black text-emerald-700">సాధారణం</span>
            </div>
            <p className="text-sm font-black text-slate-900">45-55 లీటర్లు / రోజు</p>
            <p className="text-[11px] text-slate-400 mt-1">తగినంత నీరు తాగుతోంది</p>
          </div>

          {/* 4. Movement */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-500 flex items-center gap-1.5">
                <span className="text-sm">🚶</span>
                {t('sec_movement', 'నడక / కదలిక')}
              </span>
              <span className="text-xs font-black text-emerald-700">చురుకుగా ఉంది</span>
            </div>
            <p className="text-sm font-black text-slate-900">కుంటి నడక లేదు (No Limping)</p>
            <p className="text-[11px] text-slate-400 mt-1">సహజమైన కదలికలు</p>
          </div>

          {/* 5. Milk Production */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-500 flex items-center gap-1.5">
                <Milk className="w-4 h-4 text-sky-600" />
                {t('sec_milk', 'పాల దిగుబడి')}
              </span>
              <span className="text-xs font-black text-slate-700">14.2 L / రోజు</span>
            </div>
            <p className="text-sm font-black text-slate-900">ఉదయం 7.5L • సాయంత్రం 6.7L</p>
            <p className="text-[11px] text-slate-400 mt-1">గత వారంతో పోలిస్తే స్థిరంగా ఉంది</p>
          </div>

          {/* 6. Temperature */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-500 flex items-center gap-1.5">
                <Thermometer className="w-4 h-4 text-amber-500" />
                {t('sec_temperature', 'ఉష్ణోగ్రత')}
              </span>
              <span className="text-xs font-black text-emerald-700">38.6 °C</span>
            </div>
            <p className="text-sm font-black text-slate-900">సాధారణ శరీర ఉష్ణోగ్రత</p>
            <p className="text-[11px] text-slate-400 mt-1">జ్వరం లక్షణాలు లేవు</p>
          </div>
        </div>

        {/* 7. Vaccination Timeline */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-extrabold text-slate-700 flex items-center gap-2">
              <Syringe className="w-4 h-4 text-emerald-600" />
              <span>{t('btn_vaccination', 'టీకాల వివరాలు (Vaccination Records)')}</span>
            </span>
            <span className="text-xs bg-emerald-50 text-emerald-800 font-bold px-2 py-0.5 rounded-md">
              రక్షించబడింది
            </span>
          </div>

          <div className="space-y-2">
            {animal.vaccinationRecords && animal.vaccinationRecords.length > 0 ? (
              animal.vaccinationRecords.map(v => (
                <div key={v.id} className="flex items-center justify-between p-3 rounded-xl bg-slate-50 text-xs">
                  <div>
                    <p className="font-extrabold text-slate-900">{v.vaccineName}</p>
                    <p className="text-slate-400 text-[11px]">బ్యాచ్: {v.batchNumber} • అధికారి: {v.administeredBy}</p>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-emerald-700 block">వేసిన తేది: {v.administeredDate}</span>
                    <span className="text-slate-400 text-[10px]">తదుపరి: {v.nextDueDate}</span>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-xs text-slate-400">టీకా రికార్డు నమోదు చేయబడింది.</p>
            )}
          </div>
        </div>

        {/* 8. Camera Observations */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-extrabold text-slate-700 flex items-center gap-2">
              <Camera className="w-4 h-4 text-sky-600" />
              <span>{t('sec_camera_obs', 'కెమెరా పరిశీలనలు (Camera Observations)')}</span>
            </span>
            <span className="text-xs text-slate-400">గత 24 గంటలు</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            బాన్ కెమెరా 1 ద్వారా నిరంతరం పర్యవేక్షించబడుతోంది. పశువు నిలబడే తీరు, మేత తినే వేగం మరియు నడక సాధారణ పరిధిలోనే ఉన్నాయి.
          </p>
        </div>

        {/* 9. Previous Reports */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-extrabold text-slate-700 flex items-center gap-2">
              <FileText className="w-4 h-4 text-indigo-600" />
              <span>{t('sec_previous_reports', 'మునుపటి నివేదికలు')}</span>
            </span>
          </div>
          <div className="p-3 bg-slate-50 rounded-xl text-xs flex items-center justify-between">
            <div>
              <p className="font-bold text-slate-800">చివరి సాధారణ పరీక్ష</p>
              <p className="text-slate-400 text-[11px]">{animal.lastChecked} • డాక్టర్ వి. కే. శర్మ</p>
            </div>
            <span className="text-emerald-700 font-black">క్లియర్ 👍</span>
          </div>
        </div>
      </div>
    </div>
  );
};
